package arbolBin;


public class Nodo {
	
	private int info;
    private Nodo izq;
    private Nodo der;
	
    public Nodo() {
		this.izq = null;
		this.der = null;
	}
	public int getInfo() {
		return info;
	}
	public void setInfo(int info) {
		this.info = info;
	}
	public Nodo getIzq() {
		return izq;
	}
	public void setIzq(Nodo izq) {
		this.izq = izq;
	}
	public Nodo getDer() {
		return der;
	}
	public void setDer(Nodo der) {
		this.der = der;
	}
    
    

}
