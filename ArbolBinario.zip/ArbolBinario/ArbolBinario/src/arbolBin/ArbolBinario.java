package arbolBin;

public class ArbolBinario {
	
	private Nodo raiz;
	
    public ArbolBinario() {
        raiz=null;
    }
    
    public void insertar (int info)
    {
        Nodo nuevo = new Nodo();   		
        		
        nuevo.setInfo(info);
        if (raiz == null)
            raiz = nuevo;
        else
        {
            Nodo anterior = null, reco;
            reco = raiz;
            while (reco != null)
            {
                anterior = reco;
                if (info < reco.getInfo())
                    reco = reco.getIzq();
                else
                    reco = reco.getDer();
            }
            if (info < anterior.getInfo())
                anterior.setIzq(nuevo);
            else
                anterior.setDer(nuevo);
        }
    }
    


    private void imprimirPre (Nodo reco)
    {
        if (reco != null)
        {
            System.out.print(reco.getInfo() + " ");
            imprimirPre (reco.getIzq());
            imprimirPre (reco.getDer());
        }
    }

    public void imprimirPre ()
    {
        imprimirPre (raiz);
        System.out.println();
    }

    private void imprimirEntre (Nodo reco)
    {
        if (reco != null)
        {    
            imprimirEntre (reco.getIzq());
            System.out.print(reco.getInfo() + " ");
            imprimirEntre (reco.getDer());
        }
    }

    public void imprimirEntre ()
    {
        imprimirEntre (raiz);
        System.out.println();
    }


    private void imprimirPost (Nodo reco)
    {
        if (reco != null)
        {
            imprimirPost (reco.getIzq());
            imprimirPost (reco.getDer());
            System.out.print(reco.getInfo() + " ");
        }
    }


    public void imprimirPost ()
    {
        imprimirPost (raiz);
        System.out.println();
    }

    public static void main (String [] ar)
    {
        ArbolBinario abo = new ArbolBinario ();
        abo.insertar (10);
        abo.insertar (6);
        abo.insertar (18);
        abo.insertar (-6);
        abo.insertar (7);
        abo.insertar (15);
        abo.insertar (25);          
        
        System.out.println ("Impresion preorden: ");
        abo.imprimirPre ();
        System.out.println ("Impresion entreorden: ");
        abo.imprimirEntre ();
        System.out.println ("Impresion postorden: ");
        abo.imprimirPost ();        
    } 

}
