package hilos;

import java.util.ArrayList;

import org.omg.CORBA.VersionSpecHelper;

import interfaz.InterfazPrincipal;
import modelo.Balon;

public class HiloBalon extends Thread {
	
	
	private InterfazPrincipal ven;
	private ArrayList<Balon> balones;
	
	public HiloBalon(ArrayList<Balon> balones, InterfazPrincipal ven) {
		this.balones = balones;
		this.ven = ven;
	}
	
	public void run() {
		
		while(true) {
			for(int i=0; i<balones.size();i++) {
				
			balones.get(i).mover(5);	
				
			}
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ven.repaint();
		}
		
	}

}
