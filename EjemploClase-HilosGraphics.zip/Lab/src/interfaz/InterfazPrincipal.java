package interfaz;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.JFrame;

import org.omg.CORBA.VersionSpecHelper;

import hilos.HiloBalon;
import modelo.Balon;

public class InterfazPrincipal extends JFrame {
	
	private PanelCanvas miPanel;
	private ArrayList<Balon> balones;
	
	public InterfazPrincipal() {
		
		setSize(490, 350);
		setResizable(false);
		
		setLayout(new BorderLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		miPanel = new PanelCanvas(this);		
		add(miPanel, BorderLayout.CENTER);
		balones = new ArrayList<Balon>();
			
		balones.add(new Balon(40,60));
		balones.add(new Balon(80,100));
	}
	
	public void moverBalon() {
		HiloBalon hiloB = new HiloBalon(balones, this);
		hiloB.start();
	}
	
	public static void main(String[] args) {
		InterfazPrincipal ven = new InterfazPrincipal();
		ven.setVisible(true);
		ven.moverBalon();
	}

	
	
	public ArrayList<Balon> getBalones(){
		
	return balones;	
		
	}

}
