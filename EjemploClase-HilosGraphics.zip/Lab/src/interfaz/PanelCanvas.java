package interfaz;

import java.awt.Graphics;

import javax.swing.JPanel;

import modelo.Balon;

public class PanelCanvas extends JPanel{
	
	InterfazPrincipal ven;
	
	public PanelCanvas(InterfazPrincipal ven) {
		this.ven = ven;
	}
	
	public void paintComponent(Graphics g) {
		
		for(int i=0; i<ven.getBalones().size();i++) {
		Balon mib = ven.getBalones().get(i);
		g.fillOval(mib.getPosX(), mib.getPosY(), 40, 40);
		
		if(mib.getPosX()==490) {
			
			mib.seguir();
		}
		}
		
		
	}

}
