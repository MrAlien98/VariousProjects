package application;

import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.CheckBox;
import javafx.scene.paint.Color;

public class SampleController {
	
	@FXML private CheckBox pts1;
	@FXML private CheckBox pts2;
	@FXML private CheckBox pts3;
	@FXML private CheckBox pts4;
	
	@FXML private Canvas canvas;
	
	@FXML private GraphicsContext g;
	
	public void initialize() {
		g=canvas.getGraphicsContext2D();
		pts1.setOnAction(e->{
			verifyPts1();
		});
		pts2.setOnAction(e->{
			verifyPts2();
		});
		pts3.setOnAction(e->{
			verifyPts3();
		});
		pts4.setOnAction(e->{
			verifyPts4();
		});
	}
	
	public void verifyPts1(){
		if(pts1.isSelected()) {
			g.setStroke(Color.BLACK);
			for(int i=0;i<Main.getPrincipal().getPuntos1().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos1().get(i).getX(), Main.getPrincipal().getPuntos1().get(i).getY(), Main.getPrincipal().getPuntos1().get(i+1).getX(), Main.getPrincipal().getPuntos1().get(i+1).getY());
			}
		}else {
			g.setStroke(Color.WHITE);
			for(int i=0;i<Main.getPrincipal().getPuntos1().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos1().get(i).getX(), Main.getPrincipal().getPuntos1().get(i).getY(), Main.getPrincipal().getPuntos1().get(i+1).getX(), Main.getPrincipal().getPuntos1().get(i+1).getY());
			}
		}
	}
	
	public void verifyPts2(){
		if(pts1.isSelected()) {
			g.setStroke(Color.BLACK);
			for(int i=0;i<Main.getPrincipal().getPuntos2().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos2().get(i).getX(), Main.getPrincipal().getPuntos2().get(i).getY(), Main.getPrincipal().getPuntos2().get(i+1).getX(), Main.getPrincipal().getPuntos2().get(i+1).getY());
			}
		}else {
			g.setStroke(Color.WHITE);
			for(int i=0;i<Main.getPrincipal().getPuntos2().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos2().get(i).getX(), Main.getPrincipal().getPuntos2().get(i).getY(), Main.getPrincipal().getPuntos2().get(i+1).getX(), Main.getPrincipal().getPuntos2().get(i+1).getY());
			}
		}
	}

	public void verifyPts3(){
		if(pts1.isSelected()) {
			g.setStroke(Color.BLACK);
			for(int i=0;i<Main.getPrincipal().getPuntos3().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos3().get(i).getX(), Main.getPrincipal().getPuntos3().get(i).getY(), Main.getPrincipal().getPuntos3().get(i+1).getX(), Main.getPrincipal().getPuntos3().get(i+1).getY());
			}
		}else {
			g.setStroke(Color.WHITE);
			for(int i=0;i<Main.getPrincipal().getPuntos3().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos3().get(i).getX(), Main.getPrincipal().getPuntos3().get(i).getY(), Main.getPrincipal().getPuntos3().get(i+1).getX(), Main.getPrincipal().getPuntos3().get(i+1).getY());
			}
		}
	}

	public void verifyPts4(){
		if(pts4.isSelected()) {
			g.setStroke(Color.BLACK);
			for(int i=0;i<Main.getPrincipal().getPuntos4().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos4().get(i).getX(), Main.getPrincipal().getPuntos4().get(i).getY(), Main.getPrincipal().getPuntos4().get(i+1).getX(), Main.getPrincipal().getPuntos4().get(i+1).getY());
			}
		}else {
			g.setStroke(Color.WHITE);
			for(int i=0;i<Main.getPrincipal().getPuntos4().size()-1;i++) {
				g.strokeLine(Main.getPrincipal().getPuntos4().get(i).getX(), Main.getPrincipal().getPuntos4().get(i).getY(), Main.getPrincipal().getPuntos4().get(i+1).getX(), Main.getPrincipal().getPuntos4().get(i+1).getY());
			}
		}
	}
	
}
