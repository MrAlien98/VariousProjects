package model;

import java.util.ArrayList;

public class Principal {

	private ArrayList<Punto> puntos1;
	private ArrayList<Punto> puntos2;
	private ArrayList<Punto> puntos3;
	private ArrayList<Punto> puntos4;
	
	public Principal() {
		puntos1=new ArrayList<>();
		puntos2=new ArrayList<>();
		puntos3=new ArrayList<>();
		puntos4=new ArrayList<>();
		generate();
	}

	public void generate(){
		int i=10;
		while(i>0) {
			int x=(int) ((int) 1+Math.random()*300);
			int y=(int) ((int) 1+Math.random()*300);
			puntos1.add(new Punto(x , y));
			i--;
		}
		i=10;
		while(i>0) {
			int x=(int) ((int) 1+Math.random()*300);
			int y=(int) ((int) 1+Math.random()*300);
			puntos2.add(new Punto(x , y));
			i--;
		}
		i=10;
		while(i>0) {
			int x=(int) ((int) 1+Math.random()*300);
			int y=(int) ((int) 1+Math.random()*300);
			puntos3.add(new Punto(x , y));
			i--;
		}
		i=10;
		while(i>0) {
			int x=(int) ((int) 1+Math.random()*300);
			int y=(int) ((int) 1+Math.random()*300);
			puntos4.add(new Punto(x , y));
			i--;
		}
	}
	
	/**
	 * @return the puntos1
	 */
	public ArrayList<Punto> getPuntos1() {
		return puntos1;
	}

	/**
	 * @return the puntos2
	 */
	public ArrayList<Punto> getPuntos2() {
		return puntos2;
	}

	/**
	 * @return the puntos3
	 */
	public ArrayList<Punto> getPuntos3() {
		return puntos3;
	}

	/**
	 * @return the puntos4
	 */
	public ArrayList<Punto> getPuntos4() {
		return puntos4;
	}
	
}
