import javax.swing.JComponent;

	import javax.swing.JComponent;

	import javax.swing.BorderFactory;

	import java.util.ArrayList;

	import java.util.Random;

	import java.awt.Dimension;

	import java.awt.Graphics;

	import java.awt.Color;


public class Contenedora_Bolas extends JComponent{
	    int anchura = 515;
	    int altura = 420;
	     
	    ArrayList <Bola>  conjunto_bolas = new ArrayList<>();	     
	     
	  public Contenedora_Bolas(){
	        setPreferredSize(new Dimension(anchura, altura));    
	        setBorder(BorderFactory.createEtchedBorder());
	    }
	     
	    public void paintComponent(Graphics g) {
	        super.paintComponent(g); 
	        g.setColor(new Color( 245, 245, 220 ));  
	        g.fillRect(0,0,getWidth(),getHeight());
	        
	        try
	        {
	          for(int i=0; i < conjunto_bolas.size(); i++){
	                 conjunto_bolas.get(i).pintar_bola(g);
	            }
	            Thread.sleep(5);
	        }catch(InterruptedException e){
	            System.out.println("Error al intentar pintar la bola");
	        }
	        repaint();
	    }
	     
	   
	    void a�adir_bola(int diametro){
	       conjunto_bolas.add(new Bola(diametro));
	    }
 
	 //CLASE BOLA.
	public class Bola{
	        int columna = 0;   
	        int fila = 0;     
	        int direccion_columna = 1;         
	        int direccion_fila = 1;   
	        int diametro;
	        
	  public Bola(int diametro){
	      this.diametro = diametro;
	    }
	  
	        void calcular_direccion_bola(){
	          columna = columna - direccion_columna;   
	          fila = fila - direccion_fila;
	             
	            if(columna < 0){
	                columna = 0;
	                
	                direccion_columna = -1;
	            }
	            else if(columna + diametro > getWidth()){
	                direccion_columna = 1;
	            }
	            if(fila < 0){
	                fila = 0; 
	                direccion_fila = -1;
	            }
	            else if(fila + diametro > getHeight()){
	                direccion_fila = 1;
	            }
	        }
	        
	   void pintar_bola(Graphics g)
	    {
	      calcular_direccion_bola();
	      g.setColor(Color.RED);
	      g.fillOval(columna, fila, diametro, diametro);
	     }
	   }
	}

