import javax.swing.JFrame;

import javax.swing.JLabel;

import javax.swing.JButton;

import javax.swing.JTextField;

import javax.swing.JPanel;

import javax.swing.BorderFactory;

import javax.swing.JOptionPane;

import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;

import java.awt.FlowLayout;

import java.awt.Color;

	public class App {
    JFrame ventana = new JFrame();
    JPanel panel = new JPanel(); 
    JButton boton_a�adir = new JButton("A�adir");         
    JTextField campo_medida = new JTextField(2);
    Contenedora_Bolas  contenedor_bolas = new Contenedora_Bolas();
    
    public App() {
        ventana.setSize(650,550);     
        ventana.getContentPane().setLayout(new FlowLayout());
        boton_a�adir.addActionListener(new Acciones());    
        panel.add(campo_medida);     
        panel.add(boton_a�adir);      
        ventana.add(contenedor_bolas);        
        ventana.add(panel);       
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
        ventana.setLocationRelativeTo(null);       
        ventana.setVisible(true);
   }
    
  class Acciones implements ActionListener {
        public void actionPerformed(ActionEvent ae) {
           if(ae.getSource() == boton_a�adir){
                if(!campo_medida.getText().equals("")){
                  try{
                        contenedor_bolas.a�adir_bola(Integer.parseInt(campo_medida.getText()));      
                        
                     }catch(NumberFormatException e){
                                                     System.out.println(e);
                                                     JOptionPane.showMessageDialog(null,"INTRODUZCA UN VALOR V�LIDO","Error",JOptionPane.ERROR_MESSAGE);
                                                    }
                     }else{
                            JOptionPane.showMessageDialog(null," INDIQUE LA MEDIDA DEL DI�METRO","Error",JOptionPane.ERROR_MESSAGE);
                          }
            }

        }
    }
    
  public static void main(String[] args)
    {  new App();  }
}
