package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class SampleController {
	
    @FXML private Button butIniciar;

    @FXML private ImageView imgMapa;
    @FXML private ImageView imgAvion;
    @FXML private ImageView imgP1;
    @FXML private ImageView imgP2;

    double dx;
    double dy;
    
    private Timeline animation;
    
	public void initialize() {
		imgAvion.setImage(new Image("imgs/plane.png"));
		imgAvion.setFitWidth(36);
		imgAvion.setFitHeight(48);
		imgAvion.setLayoutX(imgP1.getLayoutX());
		imgAvion.setLayoutY(imgP1.getLayoutY());
		imgAvion.setVisible(false);
		butIniciar.setOnAction(e->{
			hacer();
		});
	}
	
	public double MCD(double dx, double dy) {
		double res=0;
		do{
			res=dy;
			dy=dx%dy;
			dx=res;
		}while(dy!=0);
		return res;
	}
	
	public void hacer() {
		imgAvion.setVisible(true);
		dx=(imgP2.getLayoutX()-imgP1.getLayoutX());
		dy=(imgP2.getLayoutY()-imgP1.getLayoutY());
		double cambio=MCD(dx,dy);
		dx=dx/cambio;
		dy=dy/cambio;
		animation = new Timeline(new KeyFrame(Duration.millis(300), f-> {
			if(imgAvion.getLayoutX()<imgP2.getLayoutX()) {
				imgAvion.setLayoutX(imgAvion.getLayoutX()+dx);
			}
			if(imgAvion.getLayoutY()>imgP2.getLayoutY()) {
				imgAvion.setLayoutY(imgAvion.getLayoutY()+dy);
			}
			if(imgAvion.getLayoutY()<imgP2.getLayoutY() && imgAvion.getLayoutX()>imgP2.getLayoutX()) {
				animation.pause();
			}
		}));
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
	}
}

