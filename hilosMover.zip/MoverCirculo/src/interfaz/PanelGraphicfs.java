package interfaz;

import java.awt.Graphics;

import javax.swing.JPanel;

public class PanelGraphicfs extends JPanel{

	private VentanaPrincipal inter;
	
	public PanelGraphicfs(VentanaPrincipal ven) {
		inter = ven;
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		g.fillOval(inter.getCir().getX(), inter.getCir().getY(), 50, 50);
	}
}
