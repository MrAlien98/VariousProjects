package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;

import hilos.HiloCirculo;
import modelo.Circulo;

public class VentanaPrincipal extends JFrame {
	
	private PanelGraphicfs grafico;
	private Circulo cir;

	public VentanaPrincipal() {
		grafico = new PanelGraphicfs(this);
		cir = new Circulo();
		setLayout(new BorderLayout());
		setPreferredSize(new Dimension(700, 500));
		
		add(grafico, BorderLayout.CENTER);
		pack();
		
		HiloCirculo epa = new HiloCirculo(cir, this);
		epa.start();
		
		
	}
	
	public Circulo getCir() {
		return cir;
	}

	public void setCir(Circulo cir) {
		this.cir = cir;
	}
	
	public static void main(String[] args) {
		VentanaPrincipal inter = new VentanaPrincipal();
		inter.setVisible(true);
	}
	
}
