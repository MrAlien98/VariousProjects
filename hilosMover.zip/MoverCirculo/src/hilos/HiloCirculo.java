package hilos;

import interfaz.VentanaPrincipal;
import modelo.Circulo;

public class HiloCirculo extends Thread{

	private Circulo cir;
	private VentanaPrincipal v;
	
	public HiloCirculo(Circulo circ, VentanaPrincipal ve) {
		super();
		cir = circ;
		v = ve;
		
		
	}
	
	public void run() {
		
		try {
			while(!cir.isMover()) {
			cir.cambiarPos();
			sleep(100);
			v.repaint();
			}
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
	
}
