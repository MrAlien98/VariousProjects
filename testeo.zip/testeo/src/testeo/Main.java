package testeo;

import java.awt.*;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class Main extends JFrame implements KeyListener{

	private int x;

	public Main() {
		x=20;
		addKeyListener(this);
		setSize(500,500);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("wea");
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			x+=10;
			System.out.println(x);
		}else if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			x-=10;
			System.out.println(x);
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public void paintComponent(Graphics g) {
		g.drawOval(x, 50, 70, 70);
	}
	
	public static void main(String[] args) {
		Main main=new Main();
		main.setVisible(true);
	}
	

}