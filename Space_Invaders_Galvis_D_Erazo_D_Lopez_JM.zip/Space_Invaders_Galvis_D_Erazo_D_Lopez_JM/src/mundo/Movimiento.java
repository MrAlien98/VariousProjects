package mundo;

public interface Movimiento {
	public void mover (int x, int y, int altoPanel, int anchoPanel);
}
