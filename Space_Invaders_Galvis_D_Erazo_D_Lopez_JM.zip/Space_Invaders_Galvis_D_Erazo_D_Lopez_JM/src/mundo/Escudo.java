package mundo;

public interface Escudo {
	public boolean escudoActivo();
}
