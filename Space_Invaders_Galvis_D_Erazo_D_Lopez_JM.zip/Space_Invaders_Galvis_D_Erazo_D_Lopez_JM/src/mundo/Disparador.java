package mundo;

public interface Disparador {
	public void disparar ();
	
}
