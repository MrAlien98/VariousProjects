package vista;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;

import hilos.HiloMoverDisparo;
import hilos.HiloMoverNaveUsuario;
import hilos.HiloMoverNavesEnemigas;
import mundo.Nave;
import mundo.Partida;

public class VentanaJuego extends JFrame implements KeyListener{

	private Partida partida;
	private PanelPartida panel;
	public VentanaJuego (){
		panel = new PanelPartida(this);
		add (panel, BorderLayout.CENTER);
		setLayout (new GridLayout());
		refrescarPanel();
		pack();
		partida = new Partida(panel.getWidth(), panel.getHeight());
		inicializarHiloNaves();
		addKeyListener (this);
	}
	
	public static void main (String [] args){
		VentanaJuego v = new VentanaJuego ();
		v.setVisible(true);
	}
	
	public void inicializarHiloNaves (){
		Thread hilo = new Thread(new HiloMoverNavesEnemigas(partida, this));
		hilo.start();
	}
	
	public Partida getPartida() {
		return partida;
	}
	public void setPartida(Partida partida) {
		this.partida = partida;
	}
	public PanelPartida getPanel() {
		return panel;
	}
	public void setPanel(PanelPartida panel) {
		this.panel = panel;
	}
	
	public void refrescarPanel(){
		panel.repaint();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int tecla = e.getKeyCode();
		if (!partida.getNave().isEnMovimiento()){
			if (tecla == 39){
				partida.empezarMovimientoNave();
				Thread hilo = new Thread (new HiloMoverNaveUsuario(partida, this, Nave.DERECHA));
				hilo.start();
			} else if (tecla == 37){
				partida.empezarMovimientoNave();
				Thread hilo = new Thread (new HiloMoverNaveUsuario(partida, this, Nave.IZQUIERDA));
				hilo.start();
			}
		}
		if (!partida.getNave().isDisparando()){
			if (tecla == 32){
				partida.dispararNaveAliada();
				Thread hilo = new Thread(new HiloMoverDisparo(this, partida));
				hilo.start();
			}
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		int tecla = e.getKeyCode();
		if (tecla == 39 || tecla == 37){
			partida.detenerNave();
		}
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
