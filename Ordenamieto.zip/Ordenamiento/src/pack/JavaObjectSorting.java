package pack;

import java.util.Arrays;

public class JavaObjectSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Empleado[] empArr = new Empleado[4];
        empArr[0] = new Empleado(10, "Frodo", 29, 10000);
        empArr[1] = new Empleado(20, "Arwin", 26, 20000);
        empArr[2] = new Empleado(5, "Lisa", 35, 5000);
        empArr[3] = new Empleado(1, "Gandalf", 32, 50000);		

        //Ordenar el arreglo de empleados usando la implementaci�n de la interfaz Comparable
        Arrays.sort(empArr);
        System.out.println("Lista ordenada de empleados (Comparable):\n");
        for(int i = 0; i<empArr.length; i++) {
        	System.out.println("Nombre: " + empArr[i].getNombre() + ", Edad: " + empArr[i].getEdad());
        }
        
//        System.out.println("\n");
//        
//        //Ordenar el arreglo de empleados usando la implementaci�n de la interfaz Comparator
//        Arrays.sort(empArr, new ComparadorSalario());
//        System.out.println("Lista de empleados ordenada por Salario:\n");        
//        for(int i = 0; i<empArr.length; i++) {
//        	System.out.println("Nombre: " + empArr[i].getNombre() + ", Salario: " + empArr[i].getSalario());
//        }
        
//        System.out.println("\n");
//        
//        Arrays.sort(empArr, new ComparadorNombre());
//        System.out.println("Lista de empleados ordenada por Nombre:\n");        
//        for(int i = 0; i<empArr.length; i++) {
//        	System.out.println("Nombre: " + empArr[i].getNombre());
//        }

	}

}
