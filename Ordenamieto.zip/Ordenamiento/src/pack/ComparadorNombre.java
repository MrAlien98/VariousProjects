package pack;

import java.util.Comparator;

public class ComparadorNombre implements Comparator<Empleado>{

	@Override
	public int compare(Empleado arg0, Empleado arg1) {
		// TODO Auto-generated method stub
		return arg0.getNombre().compareTo(arg1.getNombre());
	}

}
