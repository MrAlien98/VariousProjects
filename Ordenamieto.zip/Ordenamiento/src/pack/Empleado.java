package pack;

public class Empleado implements Comparable<Empleado>{
	
	private int id;
	private String nombre;
	private int edad;
	private double salario;	

	public Empleado(int id, String nombre, int edad, double salario) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.edad = edad;
		this.salario = salario;
	}
	public int getId() {
		return id;
	}
	public String getNombre() {
		return nombre;
	}
	public int getEdad() {
		return edad;
	}
	public double getSalario() {
		return salario;
	}
	@Override
	public int compareTo(Empleado arg0) {
		
		int ret = 0;		
		if(this.edad > arg0.getEdad()) {
			ret = 1;
		}else {
			ret = -1;
		}
		return ret;
	}
	
	

}
