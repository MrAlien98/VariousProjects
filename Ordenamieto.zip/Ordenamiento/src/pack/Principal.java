package pack;

public class Principal {


	public static void main(String[] args) {
		//int arreglo[] = {5, 6, 3, 8, 1, 9, 4, 7, 2};
		int arreglo[] = CreaArregloAleatorios(10000);
		pintar(arreglo);
		System.out.println("");
		long t1 = System.currentTimeMillis();
		System.out.println("Tiempo 0: " + t1/1000);
		pintar(ordenarSeleccion(arreglo));
		System.out.println("");
		long t2 = System.currentTimeMillis();
		System.out.println("Tiempo total: " + (t2-t1)/1000);
		t1 = System.currentTimeMillis();
		System.out.println("Tiempo 0: " + t1);
		pintar(OrdenarBurbuja(arreglo));
		System.out.println("");
		t2 = System.currentTimeMillis();
		System.out.println("Tiempo total: " + (t2-t1)/10000);
		t1 = System.currentTimeMillis();
		System.out.println("Tiempo 0: " + t1);
		pintar(OrdenarInsercion(arreglo));
		System.out.println("");
		t2 = System.currentTimeMillis();
		System.out.println("Tiempo total: " + (t2-t1));
		pintar(arreglo);
		System.out.println("");
		System.out.println("");
		
		t1 = System.nanoTime();
		System.out.println("Tiempo 0: " + t1);
		System.out.println("EL valor esta: " + buscarValor (arreglo, 10));
		t2 = System.nanoTime();
		System.out.println("Tiempo total: " + (t2-t1));
		
		t1 = System.nanoTime();
		System.out.println("EL valor esta: " + busquedaBinaria (arreglo, 10));
		t2 = System.nanoTime();
		System.out.println("Tiempo total: " + (t2-t1));
	}
		
	static int [] ordenarSeleccion(int arreglo[]) {
		int [] resultadoArreglo = arreglo.clone();
		for (int i = 0; i < resultadoArreglo.length -1; i++) {
			int menor = resultadoArreglo[i];
			int cual = i;
			for (int j = i + 1; j < resultadoArreglo.length; j++  ) {
				if (resultadoArreglo[ j ] < menor ) {
					menor = resultadoArreglo [ j ];
					cual = j;
				}
			}
			int temp = resultadoArreglo [ i ];
			resultadoArreglo[ i ] = menor;
			resultadoArreglo[ cual ] = temp;
		}
		return resultadoArreglo;
	}
	
	static int [] OrdenarBurbuja(int arreglo[]) {
		int [] resultadoArreglo = arreglo.clone();
		for (int i = resultadoArreglo.length; i > 0; i-- ) {
			for (int j=0; j<i-1; j++) {
				if (resultadoArreglo[j] > resultadoArreglo[j+1] ) {
					int tmp=resultadoArreglo[j];
					resultadoArreglo[j]=resultadoArreglo[j+1];
					resultadoArreglo[j+1]=tmp;
				}
			}
		}
		return resultadoArreglo;
	}
	
	static int [] OrdenarInsercion(int arreglo[]) {
		int [] resultadoArreglo = arreglo.clone();
		for (int i=1; i < resultadoArreglo.length; i++ ) {
			for (int j=i; j>0 && resultadoArreglo[j-1] > resultadoArreglo[j]; j--) {
				int tmp=resultadoArreglo[j];
				resultadoArreglo[j]=resultadoArreglo[j-1];
				resultadoArreglo[j-1]=tmp;
			}
		}
		return resultadoArreglo;
	}
	
	static void pintar(int arreglo[] ) {
		for (int i=0; i<arreglo.length; i++) {
			System.out.print(arreglo[i] + ", ");
		}
	}
	
	static boolean busquedaBinaria(int arreglo[], int valor) {
		boolean resultado = false;
		int inicio = 0;
		int fin = arreglo.length - 1;
		while (inicio <= fin && !resultado ) {
			int medio = (inicio + fin ) / 2 ;
			if (arreglo[medio] == valor ) {
				resultado = true;
			} else if (arreglo [medio] > valor) {
				fin = medio -1 ;
			} else {
				inicio = medio + 1;
			}
		}
		return resultado;
	}
	
	static int[] CreaArregloAleatorios(int cantidad) {
		int limiteSuperior = 10;
		int arreglo[] = new int[cantidad];
		for (int i=0; i<arreglo.length; i++) {
			arreglo[i] = (int) (Math.random() * limiteSuperior);
		}
		return arreglo;
	}
	
	static boolean buscarValor(int arreglo[], int valor) {
		boolean resultado = false;
		for (int i = 0; i < arreglo.length; i++) {
			if (arreglo[i]==valor) {
				return true;
			}
		}
		return resultado;
	}
}
