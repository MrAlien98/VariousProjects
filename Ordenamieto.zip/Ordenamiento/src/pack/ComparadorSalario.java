package pack;

import java.util.Comparator;

public class ComparadorSalario implements Comparator<Empleado>{

	@Override
	public int compare(Empleado arg0, Empleado arg1) {
		// TODO Auto-generated method stub
		return (int) (arg0.getSalario() - arg1.getSalario());
	}



}
