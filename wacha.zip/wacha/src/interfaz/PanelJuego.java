package interfaz;

import java.awt.*;
import javax.swing.*;

import modelo.Juego;
import modelo.Personaje;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

@SuppressWarnings("serial")
public class PanelJuego extends JPanel implements KeyListener{

	private VentanaPrincipal ventana;
	private ImageIcon logo;
	
	public PanelJuego(VentanaPrincipal ventana) {
		this.ventana=ventana;
		addKeyListener(this);
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		paintBackground(g);
		paintTxt(g);
		paintUser(g);
	}
	
	public void paintBackground(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2=(Graphics2D) g;
		
		logo=new ImageIcon("src/data/background.gif");
		logo.setImageObserver(this);
		g2.drawImage(logo.getImage(), 0, 0, Juego.LARGO_VENTANA, Juego.ALTO_VENTANA, logo.getImageObserver());
	}
	
	public void paintTxt(Graphics g) {
		g.setColor(Color.LIGHT_GRAY);
		g.setFont(new Font("ARCADECLASSIC", 0, 30));
		g.drawString( "1UP", 1, 20);
		g.drawString("HIGH SCORE", 90, 20);
//		try {
//			g.drawString(Integer.toString(ventana.getGame().getUsuarios().get(0).getPuntos()), 60, 60);
//			g.drawString(Integer.toString(ventana.getGame().buscarUsuarioMayorPuntaje()), 600, 60);
//		//}catch(Exception e) {
			//e.printStackTrace();
			g.drawString("0", 30, 40);
			g.drawString("5000", 90, 40);
		//}
	}
	
	public void paintUser(Graphics g) {
		super.paintComponents(g);
		Graphics2D g2=(Graphics2D) g;
		
		ImageIcon usuario=new ImageIcon(ventana.getGame().getUsuario().getAvatar().getImagen());
		g2.drawImage(usuario.getImage(), ventana.getGame().getUsuario().getAvatar().getPosX(), ventana.getGame().getUsuario().getAvatar().getPosY(), ventana.getGame().getUsuario().getAvatar().getAncho(), ventana.getGame().getUsuario().getAvatar().getLargo(), null);
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			ventana.getGame().getUsuario().getAvatar().setImagen(Personaje.DER);
			ventana.moverDerecha();
		}else if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			ventana.getGame().getUsuario().getAvatar().setImagen(Personaje.IZQ);
			ventana.moverIzquierda();
		}else if(e.getKeyCode()==KeyEvent.VK_SPACE) {
			System.out.println("xd");
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_RIGHT) {
			ventana.pararMovimientoUsuario();
		}else if(e.getKeyCode()==KeyEvent.VK_LEFT) {
			ventana.pararMovimientoUsuario();
		}else if(e.getKeyCode()==KeyEvent.VK_SPACE) {
			ventana.getGame().getUsuario().getAvatar().setDisparando(false);
		}
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}