package interfaz;

import java.awt.*;
import javax.swing.*;

import modelo.Calculador;

public class VentanaPrincipal extends JFrame{
	
	private PanelGrado panelG;
	private PanelResultado panelR;
	
	private Calculador calculador;
	
	public VentanaPrincipal() {
		
		calculador= new Calculador();
		panelG = new PanelGrado(this);
		panelR = new PanelResultado();
		
		setSize(300, 400);
		setResizable(true);
		setTitle("Calculador de grados");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		setLayout(new GridLayout(2,1));
		
		add(panelG);
		add(panelR);
	}
	
	public void pasarKelvin(double g) {
		panelR.setTxtKelvin("" + calculador.pasarAKelvin(g));
	}
	
	public void pasarCelsius(double g) {
		panelR.setTxtCelsius("" + calculador.pasarACelsius(g));
	}

	public static void main (String[] args) {
		VentanaPrincipal ventana =new VentanaPrincipal();
	}
}
