package interfaz;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

public class PanelResultado extends JPanel {
		
	private JLabel labCelsius;
	private JLabel labKelvin;
	
	private JTextField txtCelsius;
	private JTextField txtKelvin;
	
	public PanelResultado() {
		
		TitledBorder border= BorderFactory.createTitledBorder("Resultados");
		setBorder(border);
		
		labCelsius=new JLabel("Celsius");
		labKelvin=new JLabel("Kelvin");
		
		txtCelsius=new JTextField("");
		txtCelsius.setEditable(false);
		
		txtKelvin=new JTextField("");
		txtKelvin.setEditable(false);
		
		setLayout(new GridLayout(2,2));
		
		add(labCelsius);
		add(labKelvin);
		add(txtKelvin);
		add(txtCelsius);
		
	}

	public void setTxtCelsius(String txtCelsius) {
		this.txtCelsius.setText(txtCelsius);
	}

	public void setTxtKelvin(String txtKelvin) {
		this.txtKelvin.setText(txtKelvin);
	}
	
	

}