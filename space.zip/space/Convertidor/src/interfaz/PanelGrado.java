package interfaz;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class PanelGrado extends JPanel implements ActionListener{

	public static final String CALCULAR = "Calcular";
	
	private VentanaPrincipal ventana;
	
	private JLabel labGrados;
	private JLabel labImagen;
		
	private JTextField txtCampo;
	private JButton butCalcular;

	public PanelGrado (VentanaPrincipal ventana) {
		
		this.ventana=ventana;
		
		setLayout(new BorderLayout());
		
		TitledBorder border= BorderFactory.createTitledBorder("Datos");
		setBorder(border);
		
		labGrados=new JLabel("Grados Fahrenheit");
		labImagen=new JLabel();
		ImageIcon logo=new ImageIcon ("src/imagen/24176742_1633046050081414_2421006349366785444_n.jpg");
		labImagen.setIcon(logo);
		
		txtCampo=new JTextField("");
		butCalcular=new JButton("Calcular");
		
		butCalcular.setActionCommand(CALCULAR);
		
		JPanel miPanel=new JPanel(new GridLayout(3,1));
		miPanel.add(labGrados);
		miPanel.add(txtCampo);
		miPanel.add(butCalcular);
		
		add(labImagen, BorderLayout.EAST);
		add(miPanel, BorderLayout.WEST);
	}
	
	public JTextField getTxtCampo() {
		return txtCampo;
	}

	public void setTxtCampo(JTextField txtCampo) {
		this.txtCampo = txtCampo;
	}
	
	public void actionPerformed(ActionEvent evento) {
		String comando=evento.getActionCommand();
		double y;
		double x;
		if(comando.equals(CALCULAR)) {
			ventana.pasarKelvin(y = Double.parseDouble(txtCampo.getText()));
			ventana.pasarCelsius(x = Double.parseDouble(txtCampo.getText()));
		}
	}
}
