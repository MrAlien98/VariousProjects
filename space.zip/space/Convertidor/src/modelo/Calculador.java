package modelo;

public class Calculador {

	public Calculador() {
		
	}
	
	public double pasarAKelvin(double y) {
		return (y + 459.67)*(5/9);
	}
	
	public double pasarACelsius(double m) {
		return (m - 32)*(5/9);
	}
}
