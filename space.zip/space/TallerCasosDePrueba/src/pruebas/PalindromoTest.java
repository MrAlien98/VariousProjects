package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import modelo.Palindromo;

import org.junit.jupiter.api.Test;

class PalindromoTest {
	
	private Palindromo pali;
	
	private void setUpEscenario() {
		pali=new Palindromo();
	}

	@Test
	void testVerPali1() {
		setUpEscenario();
		assertTrue(pali.verPali("oso"));
	}
	
	@Test
	void testVerPali2() {
		setUpEscenario();
		assertTrue(pali.verPali("ana"));
	}
	
	@Test
	void testVerPali3() {
		setUpEscenario();
		assertTrue(pali.verPali("reconocer"));
	}
	
	@Test
	void testVerPali4() {
		setUpEscenario();
		assertTrue(pali.verPali("somos"));
	}
	
	@Test
	void testVerPali5() {
		setUpEscenario();
		assertTrue(pali.verPali("erre"));
	}
	
	@Test
	void testVerPali6() {
		setUpEscenario();
		assertTrue(pali.verPali("radar"));
	}
	
	@Test
	void testVerPali7() {
		setUpEscenario();
		assertFalse(pali.verPali("perro"));
	}
	
	@Test
	void testVerPali8() {
		setUpEscenario();
		assertFalse(pali.verPali("abeja"));
	}

}
