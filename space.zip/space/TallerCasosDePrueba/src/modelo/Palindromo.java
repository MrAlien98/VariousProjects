package modelo;

public class Palindromo {

	public Palindromo() {
	}
	
	public boolean verPali(String palabra) {
		String invertida="";
		for (int x=palabra.length()-1;x>=0;x--) {
			invertida+=palabra.charAt(x);
		}if(invertida.equals(palabra)) {
			return true;
		}else {
			return false;
		}
	}
}
