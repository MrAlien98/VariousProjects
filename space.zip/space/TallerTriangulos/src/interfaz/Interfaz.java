package interfaz;

public class Interfaz {

}
