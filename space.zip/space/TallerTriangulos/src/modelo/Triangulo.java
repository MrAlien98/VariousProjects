package modelo;

public class Triangulo {

}
