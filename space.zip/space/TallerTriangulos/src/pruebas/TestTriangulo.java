package pruebas;

public class TestTriangulo {

}
