package modelo;

public class Paquete {

	public Lista lista;
	
	public Paquete() {
		lista=new Lista();
	}
	
	public Lista darImpares() {
		Lista list=new Lista();
		int contador=0;
		while(contador<lista.size()-1) {
			Nodo actual=lista.obtener(contador);
			if(actual.obtenerValor()%2!=0) {
				list.addPrimero(actual.obtenerValor());
			}
			contador++;
			list.setSize(contador);
		}
		return list;
	}
	
}
