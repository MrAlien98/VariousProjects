package modelo;

public class Principal {
	
//	//private Lista lista;
//	private Paquete paquete;
//	
//	public Principal() {
//		//lista=new Lista();
//		paquete=new Paquete();
//	
//		imprimir();
//	}
//	
//	public void imprimir() {
//		System.out.println("Numeros impares en la lista: "+lista.imPares(paquete.darImpares()));
//	}
	
	public static void main(String[] args) {
		Principal principal=new Principal();
	}
}
