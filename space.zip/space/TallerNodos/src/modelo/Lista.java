package modelo;

public class Lista {

	private Nodo cabeza;
	private int size;
	
	public Lista() {
		cabeza=null;
		size=0;
		
		addPrimero(6);
		addPrimero(5);
		addPrimero(4);
		addPrimero(3);
		addPrimero(2);
		addPrimero(1);
	}
	
	public void addPrimero(int obj) {
		if(cabeza==null) {
			cabeza=new Nodo(obj);
		}else {
			Nodo temp=cabeza;
			Nodo nuevo=new Nodo(obj);
			nuevo.enlazarSiguiente(temp);
			cabeza=nuevo;
		}
		size++;
	}
	
	public Nodo darCabeza() {
		return cabeza;
	}
	
	public void setCabeza(Nodo cabeza) {
		this.cabeza=cabeza;
	}
	
	public void eliminarPrimero() {
		cabeza=cabeza.obtenerSiguiente();
		size--;
	}
	
	public void eliminar(int index) { 
//		1->2->3->4->5->6
//		1->2->4
//		1->2->4->5->6
		if(index==0) {
			cabeza=cabeza.obtenerSiguiente();
		}else {
			int contador=0;
			Nodo temporal=cabeza;
			while(contador<index-1) {
				temporal=temporal.obtenerSiguiente();
				contador++;
			}
			temporal.enlazarSiguiente(temporal.obtenerSiguiente().obtenerSiguiente());
		}
		size--;
	}
	
	public Nodo obtener(int index) {
		int contador=0;
		Nodo temporal=cabeza;
		while(contador<index) {
			temporal=temporal.obtenerSiguiente();
			contador++;
		}
		return temporal;
	}
	
	public int size() {
		return size;
	}
	
	public void setSize(int size) {
		this.size=size;
	}
	
	public boolean estaVacia() {
		return (cabeza==null)?true:false;
	}
	
	public String imPares(Lista lista) {
		int contador=0;
		String imPares="";
		Nodo temporal=lista.darCabeza();
		while(contador<lista.size()) {
			if(temporal.obtenerValor() %2 != 0) {
				imPares+=Integer.toString((int)temporal.obtenerValor())+" ";
			}
			temporal=temporal.obtenerSiguiente();
			contador++;
		}
		return imPares;
	}
	
	
	
}
