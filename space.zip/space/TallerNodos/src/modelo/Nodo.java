package modelo;

public class Nodo {

	private int valor;
	private Nodo siguiente;
	private Nodo anterior;
	
	public Nodo(int valor) {
		this.valor=valor;
		siguiente=null;
	}
	
	public int obtenerValor() {
		return valor;
	}
	
	public void setValor(int valor) {
		this.valor=valor;
	}
	
	public void enlazarSiguiente(Nodo n) {
		siguiente=n;
	}
	
	public Nodo obtenerSiguiente() {
		return siguiente;
	}
	
	public void setSiguiente(Nodo siguiente) {
		this.siguiente=siguiente;
	}
}
