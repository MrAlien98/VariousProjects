package hilos;

import interfaz.VentanaPrincipal;
import modelo.Circulo;

public class HiloCirculo extends Thread{
	
	private Circulo circulo;
	private VentanaPrincipal ventana;
	
	public HiloCirculo(Circulo circulo, VentanaPrincipal ventana) {
		super();
		this.circulo = circulo;
		this.ventana = ventana;
	}
	
	public void run() {
		int n=0;
		boolean we=false;
		try {
			while(!we) {
				while(n<=ventana.darAncho()-30) {
					circulo.moverX();
					sleep(1);
					ventana.repaint();
					n++;
				}while(n>0) {
					circulo.moverX2();
					sleep(1);
					ventana.repaint();
					n--;
				}
			}
		}catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
}
