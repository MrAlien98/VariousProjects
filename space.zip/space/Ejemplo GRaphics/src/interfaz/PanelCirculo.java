package interfaz;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class PanelCirculo extends JPanel{

	VentanaPrincipal ventana;
	
	public PanelCirculo(VentanaPrincipal ventana) {
		this.ventana=ventana;
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2=(Graphics2D) g;
		//INSTRUCCIONES DE DIBUJO
		g2.setColor(Color.GREEN);
		//coordenada x
		//coordenada y
		//ancho de la figura que lo contiene
		//alto de la figura que lo contiene
		Ellipse2D.Double circulo=new Ellipse2D.Double(ventana.darXCirculo(), ventana.darYCirculo(), ventana.darAnchoCirculo(), ventana.darAltoCirculo());
		g2.fill(circulo);
		repaint();
	}
}
