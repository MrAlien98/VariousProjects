package interfaz;

import java.awt.*;
import javax.swing.*;

import hilos.HiloCirculo;
import modelo.Circulo;

public class VentanaPrincipal extends JFrame{
	
	private PanelCirculo pCirculo;
	private Circulo circulo;
	private HiloCirculo hilo;
	
	private int ancho;
	private int alto;
	
	public VentanaPrincipal() {
		
		circulo=new Circulo();
		hilo=new HiloCirculo(circulo, this);
		
		ancho=300;
		alto=300;
		
		pCirculo=new PanelCirculo(this);
		
		setSize(ancho, alto);
		setResizable(false); 
		setTitle("Ejemplo del circulo");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		setLayout(new BorderLayout());
		add(pCirculo, BorderLayout.CENTER);
		hilo.start();
	}

	public int darAncho() {
		return ancho;
	}
	
	public int darAlto() {
		return alto;
	}
	
	public int darXCirculo() {
		return circulo.getX();
	}
	
	public int darYCirculo() {
		return circulo.getY();
	}
	
	public int darAltoCirculo() {
		return circulo.getAlto();
	}
	
	public int darAnchoCirculo() {
		return circulo.getAncho();
	}
	
	public static void main(String[] args) {
		VentanaPrincipal ventana=new VentanaPrincipal();
	}
}
