package modelo;

public class Circulo {

	private int x;
	private int y;
	private int alto;
	private int ancho;
	
	public Circulo() {
		x=1;
		y=1;
		alto=30;
		ancho=30;
	}

	public void moverX() {
		x++;
	}
	
	public void moverX2() {
		x--;
	}
	
	public void moverY() {
		y++;
	}
	
	public xvoid moverY2() {
		y--;
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getAlto() {
		return alto;
	}

	public int getAncho() {
		return ancho;
	}
	
	
}

