package excepciones;

public class OutLimitException extends Exception{
	
	public OutLimitException() {
		super("La posicion no es valida");
	}
	
}
