package clase;

import excepciones.OutLimitException;

public class Metodo {

	public Metodo() {
	}
	
	public String ejemplo(String palabra, int pos) throws OutLimitException {
		String t ="";
		pos-=1;
		if(pos>=palabra.length()) {
			throw new OutLimitException();
		}else {
			char n=palabra.charAt(pos);
			t+=n;
		}
		return t;
	}
	
}
