package plabras;

import excepciones.OutLimitException;
import clase.Metodo;

import javax.swing.*;

public class Palabra {
	
	private Metodo m;

	public Palabra() {
		m=new Metodo();
		vainaRara();
		imprimir();
	}		
	
	String palabra=JOptionPane.showInputDialog("Ingrese una palabra");
	int pos= Integer.parseInt(JOptionPane.showInputDialog("Ingrese un n�mero"));
	
	public String vainaRara() {
		String e="";
		try{
			e+=m.ejemplo(palabra, pos);
		}
		catch(OutLimitException oE){
			System.out.println(oE.getMessage());
		}
		return e;
	}
	
	public void imprimir() {
		System.out.println(vainaRara());
	}
	
	public static void main(String[] args) {
		Palabra palabra=new Palabra();
	}
	
}
