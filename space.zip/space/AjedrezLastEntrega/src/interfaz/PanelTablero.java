package interfaz;

import java.awt.Panel;
import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;

public class PanelTablero extends JPanel {

	private JButton[][] matriz;
	
	public PanelTablero() {
	}
	
	public void refrescar(String[][] tablero) {
		int alto=tablero.length;
		int ancho=tablero[0].length;
		removeAll();
		setLayout(new GridLayout(alto, ancho));
		matriz = new JButton[alto][ancho];
		
		for (int i=0;i<matriz.length;i++) {
			for (int j=0;j<matriz[i].length;j++) {
				String nombreFicha=tablero[i][j];
				String nombreArchivo="imgs/"+nombreFicha+".png";
				ImageIcon imagen=new ImageIcon(nombreArchivo);
				matriz[i][j] = new JButton("");
				matriz[i][j].setIcon(imagen);
				if((i+j)%2==0) {
					matriz[i][j].setBackground(Color.BLACK);
				}else {
					matriz[i][j].setBackground(Color.WHITE);
				}
				add(matriz[i][j]);
			}
		}
	}
	
	
}
