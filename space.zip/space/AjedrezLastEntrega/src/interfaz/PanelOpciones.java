package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelOpciones extends JPanel implements ActionListener{

	public static final String JUGAR="Jugar";
	public static final String GIRAR="Girar 90�";
	
	private JLabel labCordInicial;
	private JLabel labCorFinal;
	
	private JTextField txtCorInicial;
	private JTextField txtCorFinal;
	
	private JButton butJugar;
	private JButton butGirar;
	
	private VentanaPrincipal ventana;
		
	public PanelOpciones(VentanaPrincipal ventana) {
		setLayout(new GridLayout(1,1));
		
		this.ventana=ventana;
		
		butJugar=new JButton("Jugar");
		butGirar=new JButton("Girar 90�");

		butJugar.setActionCommand(JUGAR);
		butGirar.setActionCommand(GIRAR);
		
		labCordInicial=new JLabel("Coordenada Inicial");
		labCorFinal=new JLabel("Coordenada Final");
		
		txtCorFinal=new JTextField("");
		txtCorInicial=new JTextField("");
		
		JPanel pCoordenadas=new JPanel();
		pCoordenadas.setLayout(new GridLayout (3,3));
		pCoordenadas.add(labCordInicial);
		pCoordenadas.add(txtCorInicial);
		pCoordenadas.add(labCorFinal);
		pCoordenadas.add(txtCorFinal);
		pCoordenadas.add(butJugar);
		pCoordenadas.add(butGirar);

		add(pCoordenadas);
	}
}
