package interfaz;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import modelo.Tablero;

public class VentanaPrincipal extends JFrame{
	
	private Tablero tablero;
	private PanelTablero pTablero;
	private PanelOpciones pOps;
	
	public VentanaPrincipal() {
		tablero=new Tablero();
		pTablero=new PanelTablero();
		pOps=new PanelOpciones(this);
		
		setTitle("Por fin se acabo el ajedrez");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		add(pTablero, BorderLayout.CENTER);
		add(pOps, BorderLayout.SOUTH);
	}
	
	private void actualizarPanelTablero() {
		String[][] celdas = tablero.darCeldas();
		pTablero.refrescar(celdas);
		pTablero.revalidate();
	}

	public static void main(String[] args) {
		VentanaPrincipal ventana=new VentanaPrincipal();
	}
}
