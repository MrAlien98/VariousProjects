package modelo;

public class Tablero {

	public static final int LARGO=9;
	public static final int ANCHO=9;
	
	private Celda[][] tablero;
	
	public Tablero() {
		montarTablero();
	}
	
	public void montarTablero() {
		crearCeldas();
		ponerFichas();
	}
	
	public String colorCelda(int i, int j) {
		if((i+j)%2==0) {
			return "Negro";
		}else {
			return "Blanco";
		}
	}
	
	public void crearCeldas() {
		tablero=new Celda[LARGO][ANCHO];
		for(int i=0;i<tablero.length;i++) {
			tablero[i][0]=new Celda("Gris", (tablero.length-1-i)+"");
			for(int j=1;j<tablero[i].length;j++) {
				String colorCelda=colorCelda(i,j);
				tablero[i][j]=new Celda(colorCelda);
			}
		}
		tablero[tablero.length-1][0]=new Celda("Gris");
		for(int j=1;j<tablero[tablero.length-1].length;j++) {
			String lel="a";
			tablero[tablero.length-1][j] = new Celda("Gris", (lel+=String.valueOf(j-1)));
		}
	}
	
	public void ponerFichas() {
		tablero[0][1].setFicha(new Ficha("Torre","Negro"));
		tablero[0][2].setFicha(new Ficha("Caballo", "Negro"));
		tablero[0][3].setFicha(new Ficha("Alfil", "Negro"));
		tablero[0][4].setFicha(new Ficha("Dama", "Negro"));
		tablero[0][5].setFicha(new Ficha("Rey", "Negro"));
		tablero[0][6].setFicha(new Ficha("Alfil", "Negro"));
		tablero[0][7].setFicha(new Ficha("Caballo", "Negro"));
		tablero[0][8].setFicha(new Ficha("Torre", "Negro"));
		
		tablero[7][1].setFicha(new Ficha("Torre","Blanco"));
		tablero[7][2].setFicha(new Ficha("Caballo", "Blanco"));
		tablero[7][3].setFicha(new Ficha("Alfil", "Blanco"));
		tablero[7][4].setFicha(new Ficha("Dama", "Blanco"));
		tablero[7][5].setFicha(new Ficha("Dama", "Blanco"));
		tablero[7][6].setFicha(new Ficha("Alfil", "Blanco"));
		tablero[7][7].setFicha(new Ficha("Caballo", "Blanco"));
		tablero[7][8].setFicha(new Ficha("Torre", "Blanco"));
		
		for (int i=1;i<tablero.length;i++) {
			tablero[1][i].setFicha(new Ficha("Peon", "Negro"));
			tablero[6][i].setFicha(new Ficha("Peon", "Blanco"));
		}
	}
	
	private String darNombreFicha(Celda c) {
		String nombre;
		if(c.getColor().equalsIgnoreCase("Gris")) {
			nombre=c.getPosicion();
		}else {
			nombre=""+c.getColor();
			Ficha f=c.getFicha();
			if(f!=null) {
				nombre=f.getNombre()+"_"+f.getColor()+"_"+nombre;
			}
		}
		return nombre;
	}
	
	public String[][] darCeldas(){
		String[][] celdas=new String[tablero.length][tablero[0].length];
		for (int i=0;i<celdas.length;i++) {
			for (int j=0;j<celdas[i].length;j++) {
				String nombreFicha=darNombreFicha(tablero[i][j]);
				celdas[i][j]=nombreFicha;
			}
		}
		return celdas;
	}
	
	
}
