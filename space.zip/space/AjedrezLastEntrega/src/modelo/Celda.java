package modelo;

public class Celda {

	private String color;
	private String posicion;
	
	private Ficha ficha;
	
	public Celda(String color) {
		this.color=color;
		posicion="";
		ficha=null;
	}
	
	public Celda(String color, Ficha ficha) {
		this.color=color;
		posicion="";
		this.ficha=ficha;
	}
	
	public Celda(String color, String posicion) {
		this.color=color;
		this.posicion=posicion;
		ficha=null;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getPosicion() {
		return posicion;
	}

	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	public Ficha getFicha() {
		return ficha;
	}

	public void setFicha(Ficha ficha) {
		this.ficha = ficha;
	}
	
	
}
