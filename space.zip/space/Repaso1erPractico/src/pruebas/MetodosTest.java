package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import modelo.Carretera;

class MetodosTest {

	private Carretera carretera;
	
	private void setUpEscenario() {
		carretera=new Carretera();
	}
	
	@Test
	void testFunciona() {
		setUpEscenario();
		int tipo=1;
		int fila=2;
		int columna=4;
		assertTrue();(carretera.agregarVehiculo(tipo, fila, columna));
	}

}
