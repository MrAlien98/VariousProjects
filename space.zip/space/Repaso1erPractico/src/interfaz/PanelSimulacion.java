package interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.*;
import javax.swing.*;

import javax.swing.border.TitledBorder;

public class PanelSimulacion extends JPanel implements ActionListener{
	
	public static final String GENERAR_TRAFICO="Generar Trafico";
	public static final String CAMBIAR_VELOCIDAD="Cambiar Velocidad";
	
	private VentanaPrincipal ventana;
	
	private JButton butGT;
	private JButton butCV;
	
	private JLabel LabVel;
	
	private JTextField txtVel;
	
	public PanelSimulacion(VentanaPrincipal ventana) {
		this.ventana=ventana;
		
		setLayout(new GridLayout(1,4));
		
		TitledBorder border= BorderFactory.createTitledBorder("Simulacion");
		setBorder(border);
		
		butGT=new JButton("Generar Trafico");
		butGT.setActionCommand(GENERAR_TRAFICO);
		butGT.addActionListener(this);
		
		butCV=new JButton("Cambiar Velocidad");
		butCV.setActionCommand(CAMBIAR_VELOCIDAD);
		butCV.addActionListener(this);
		
		LabVel=new JLabel("Velocidad");
		
		txtVel=new JTextField("");
		txtVel.setEditable(false);
		
		add(butGT);
		add(LabVel);
		add(txtVel);
		add(butCV);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String comando=e.getActionCommand();
		if(comando.equals(CAMBIAR_VELOCIDAD)) {
			System.out.println("xd");
		}else if(comando.equals(GENERAR_TRAFICO)) {
			ventana.pedirDatos();
		}
	}
}
