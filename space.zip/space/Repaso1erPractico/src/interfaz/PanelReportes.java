package interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.awt.*;
import javax.swing.*;

import javax.swing.border.TitledBorder;

public class PanelReportes extends JPanel implements ActionListener{

	public static final String VELOCIDAD_P="Velocidad Promedio Horas";
	public static final String VELOCIDAD_S="Velocidad Semaforo vs Puente";
	
	private VentanaPrincipal ventana;
	
	private JButton butVP;
	private JButton butVS;
	
	public PanelReportes(VentanaPrincipal ventana) {
		this.ventana=ventana;
		
		setLayout(new GridLayout(1,2));
		
		TitledBorder border= BorderFactory.createTitledBorder("Reportes");
		setBorder(border);
		
		butVP=new JButton("Velocidad Promedio Horas");
		butVP.setActionCommand(VELOCIDAD_P);
		butVP.addActionListener(this);
		
		butVS=new JButton("Velocidad Semaforo vs Puente");
		butVS.setActionCommand(VELOCIDAD_S);
		butVS.addActionListener(this);
		
		add(butVP);
		add(butVS);
	}
	
	public void actionPerformed(ActionEvent e) {
		String comando=e.getActionCommand();
		if(comando.equals(VELOCIDAD_P)) {
			
		}else if(comando.equals(VELOCIDAD_S)) {
			
		}
	}
}
