package interfaz;

import java.awt.*;
import javax.swing.*;

public class PanelAutopista extends JPanel{
	
	private VentanaPrincipal ventana;
	private JLabel[][] matriz;
	
	public PanelAutopista(VentanaPrincipal ventana) {
		this.ventana=ventana;
	}
	
	public void actualizar(String[][] epa) {
		int filas=epa.length;
		int columnas=epa[0].length;
		removeAll();
		setLayout(new GridLayout(filas, columnas));
		matriz=new JLabel[filas][columnas];
		for(int i=0;i<matriz.length;i++) {
			for(int j=0;j<matriz[i].length;j++) {
				String ocupada=epa[i][j];
				matriz[i][j]=new JLabel(""+ocupada);
				add(matriz[i][j]);
			}
		}
	}
	

}
