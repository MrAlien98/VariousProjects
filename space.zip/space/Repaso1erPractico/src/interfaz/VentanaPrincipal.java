package interfaz;

import java.awt.*;
import javax.swing.*;

import modelo.Carretera;

public class VentanaPrincipal extends JFrame{

	private Carretera carretera;
	private PanelSimulacion pS;
	private PanelReportes pR;
	private PanelAutopista pA;
	
	private ImageIcon banner;
	private JLabel img;
	
	public VentanaPrincipal() {
		pS=new PanelSimulacion(this);
		pR=new PanelReportes(this);
		pA=new PanelAutopista(this);
		carretera=new Carretera();
		
		setLayout(new BorderLayout());
		setTitle("Trafico sobre una autopista");
		setSize(700, 700);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
		
		JPanel panel=new JPanel();
		panel.setLayout(new GridLayout(2,1));
		panel.add(pS);
		panel.add(pR);
		
		banner=new ImageIcon("");
		img=new JLabel("");
		img.setIcon(banner);
		
		actualizarMatriz();
		
		add(img, BorderLayout.NORTH);
		add(pA, BorderLayout.CENTER);
		add(panel, BorderLayout.SOUTH);
	}
	
	public void pedirDatos() {
		int tipo=Integer.parseInt(JOptionPane.showInputDialog("Quiere ingresar una moto(1) o un carro(2)"));
		int fila=Integer.parseInt(JOptionPane.showInputDialog("En que calle(Vertical) lo quiere ubicar? (1-4)"));
		int columna=Integer.parseInt(JOptionPane.showInputDialog("En que carrera(Horizontal) lo quiere ubicar? (1-6)"));
		carretera.agregarVehiculo(tipo, fila, columna);
		actualizarMatriz();
	}
	
	public void actualizarMatriz() {
		pA.actualizar(carretera.darVehiculos());
	}
	
	
	public static void main(String[]args) {
		VentanaPrincipal ventana=new VentanaPrincipal();
	}
}
