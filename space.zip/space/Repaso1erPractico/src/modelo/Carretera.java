package modelo;

import java.util.*;

public class Carretera {
	
	public static final int FILA=4;
	public static final int COLUMNA=6;

	private Vehiculo[][] vehiculos;
	
	public Carretera() {
		vehiculos=new Vehiculo[FILA][COLUMNA];
	}
	
	public void agregarVehiculo(int tipo, int fila, int columna) {
		fila-=1;
		columna-=1;
		vehiculos[fila][columna]=new Vehiculo(tipo, fila, columna);
	}
	
	public String[][] darVehiculos(){
		String[][] copia=new String[vehiculos.length][vehiculos[0].length];
		for(int i=0;i<vehiculos.length;i++) {
			for(int j=0;j<vehiculos[i].length;j++) {
				if(vehiculos[i][j]!=null) {
					if(vehiculos[i][j].getTipo()==1) {
						copia[i][j]="MOTO";
					}else {
						copia[i][j]="CARRO";
					}
				}
			}
		}
		return copia;
	}
	
}
