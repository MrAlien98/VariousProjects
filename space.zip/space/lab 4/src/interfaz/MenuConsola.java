package interfaz;

import java.util.Scanner;

import modelo.Persona;
import modelo.Vehiculo;
import modelo.Fecha;
import modelo.Licencia;

public class MenuConsola{
	
	private Persona firstPersona;
	
	public MenuConsola(){
		Scanner leer = new Scanner(System.in);
		
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//ATRIBUTOS
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		Vehiculo v1, v2;
		String cedulaP;
		String nombreP;
		String apellidoP;
		String numero;
		int categoria;
		Fecha exp;
		Fecha actual;
		int diaE;
		int mesE;
		int anioE;
		int diaA;
		int mesA;
		int anioA;
		String placa;
		int modelo;
		int tipo;
		int kilometraje;
		int cilindraje;
		double aval;
		double alineacion;
		double suspension;
		double frenos;
		double ruido;
		double co2;
		double hidrocarburos;
		double valorTm;
		
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//INICIA EL PROGRAMA
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		System.out.println("BIENVENIDO AL SISTEMA DE LA SECRETARIA DE TRANSITO");
		
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//PIDE FECHA ACTUAL
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		System.out.println("DATOS GENERALES");
		
		System.out.println("Ingrese el dia actual : ");
		diaA = leer.nextInt();
		System.out.println("Ingrese el mes actual : ");
		mesA = leer.nextInt();
		System.out.println("Ingrese el anio actual : ");
		anioA = leer.nextInt();
		actual = new Fecha (diaA, mesA, anioA);
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//DATOS DE LA PERSONA
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		System.out.println("DATOS DE LA PERSONA");

		System.out.println("Ingrese el nombre de la persona : ");
		nombreP = leer.nextLine();
		nombreP = leer.nextLine();
		System.out.print("Ingrese el apellido de la persona : ");
		apellidoP = leer.nextLine();
		System.out.println("Ingrese la cedula de la persona : ");
		cedulaP = leer.nextLine();
		
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//DATOS DE LA LICENCIA
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

		System.out.println("DATOS DE LA LICENCIA DE CONDUCIR");
		
		System.out.print("Ingrese el numero de su licencia de conducir : ");
		numero = leer.nextLine();
		System.out.println("Seleccione la categoria de su licencia (1)A1 (2)A2 (3)B1 (4)C : ");
		categoria = leer.nextInt();
		System.out.println("Ingrese el dia de expedicion de su licencia : ");
		diaE = leer.nextInt();
		System.out.println("Ingrese el mes de expedicion de su licencia : ");
		mesE = leer.nextInt();
		System.out.println("Ingrese el anio de expedicion de su licencia : ");
		anioE = leer.nextInt();
		
		exp = new Fecha (diaE, mesE, anioE);
		
		Licencia l1 = new Licencia (numero, exp, categoria);
		l1.calcularFechaVen(diaA, mesA, anioA, diaE, mesE,anioE);
		
    //--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//DATOS DEL VEHICULO
	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		
		System.out.println("DATOS DEL VEHICULO");
		
		System.out.println("Ingrese la placa del vehiculo : ");
		placa = leer.nextLine();
		nombreP = leer.nextLine();
		System.out.println("Defina el tipo de vehiculo : (1) CARRO (2) MOTO ");
		tipo = leer.nextInt();
		System.out.println("�En cuanto esta avaluado su vehiculo? : ");
		aval = leer.nextDouble();
        System.out.println("Ingrese el modelo del vehiculo (anio) : "); 
		modelo = leer.nextInt();
		System.out.print("Ingrese el kilometraje del vehiculo : ");
		kilometraje = leer.nextInt();
		System.out.println("Defina el cilindraje del vehiculo (1) alto (2) normal ");
		cilindraje = leer.nextInt();
		
		v1 = new Vehiculo (placa, modelo, kilometraje, tipo, cilindraje, aval);
	
		System.out.println("Digite (1) si tiene otro vehiculo. Y (0) en caso contrario : ");
		int opcion = leer.nextInt();
		leer.nextLine();
		
		if (opcion == 1)
		{	
			System.out.println("Ingrese la placa del vehiculo : ");
			placa = leer.nextLine();
			System.out.println("Defina el tipo de vehiculo : (1) CARRO (2) MOTO ");
			tipo = leer.nextInt();
			System.out.println("�En cuanto esta avaluado su vehiculo? : ");
			aval = leer.nextDouble();
			System.out.println("Ingrese el modelo del vehiculo (anio) : "); 
			modelo = leer.nextInt();
			System.out.print("Ingrese el kilometraje del vehiculo : ");
			kilometraje = leer.nextInt();
			System.out.println("Defina el cilindraje del vehiculo (1) alto (2) normal ");
			cilindraje = leer.nextInt();
			
			v2 = new Vehiculo (placa, modelo, kilometraje, tipo, cilindraje, aval);	
		}
		else 
			v2 = null;
		
		Persona firstPersona = new Persona (cedulaP, nombreP, apellidoP, v1, v2, l1);
		
	
	
		System.out.println("DATOS PARA EL COSTO DE LA TECNO MECANICA");
		
		System.out.println("De que vehiculo desea saber su revision tecnico mecanica? (1) vehiculo1 (2) vehiculo2 : ");
		int cualV = leer.nextInt();
		System.out.println("Ingrese la alinecion de su vehiculo (En m/km) : ");
		alineacion = leer.nextDouble();
		System.out.println("Ingrese el porcentaje de la suspension de su vehiculo  : ");
		suspension = leer.nextDouble();
		System.out.println("Ingrese el porcentaje de frenos de su vehiculo : ");
		frenos = leer.nextDouble();
		System.out.println("Ingrese los decibeles de ruido de su vehiculo : ");
		ruido = leer.nextDouble();
		System.out.println("Ingrese la cantidad de emision de co2 de su vehiculo : ");
		co2 = leer.nextDouble();
		System.out.println("Ingrese la cantidad de emision de hidrocarburos de su vehiculo : ");
		hidrocarburos = leer.nextDouble();
		
		if (cualV == 1)
			valorTm = v1.calcularTm(alineacion, suspension, frenos, ruido, co2, hidrocarburos);
		else 
			valorTm = v2.calcularTm(alineacion, suspension, frenos, ruido, co2, hidrocarburos);
	
	requerimiento1();

}

	public void requerimiento1(){
		
		Scanner leer = new Scanner(System.in);
		
		System.out.println("Que vehiculo desea consultar? (1) vehiculo1 (2) vehiculo2 : ");
		int consul = leer.nextInt();
		if (consul == 1)
		{
			System.out.println("La tecno mecanica de su vehiculo es " + firstPersona.darV1().darPrecioTm());
			System.out.println("El valor del SOAT es : " + firstPersona.darV1().darSoat());
			System.out.println("Su vehiculo : " + firstPersona.darV1().saberTecnoMec());
			System.out.println("Su vehiculo : " + firstPersona.darV1().saberPicoyPlaca());
			System.out.println("El impuesto que debe pagar por su vehiculo es de : " + firstPersona.darV1().calcularImpuesto());
		}
		else 
		{		
			System.out.println("La tecno mecanica de su vehiculo es " + firstPersona.darV2().darPrecioTm());
			System.out.println("El valor del SOAT es : " + firstPersona.darV2().darSoat());
			System.out.println("Su vehiculo : " + firstPersona.darV2().saberTecnoMec());
			System.out.println("Su vehiculo : " + firstPersona.darV2().saberPicoyPlaca());
			System.out.println("El impuesto que debe pagar por su vehiculo es de : " + firstPersona.darV2().calcularImpuesto());
		}	
	}		
		
	public static void main (String args []){
		
		MenuConsola	m = new MenuConsola();
	
	}

	
	
	
}

	
	
	