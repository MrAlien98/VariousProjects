package modelo;

public class Vehiculo

{	
	//--------------------------------------------------------
	//CONSTANTES
	//--------------------------------------------------------

	public final static int MOTO = 1;
	public final static int CARRO = 2;
	public final static int ANIOACTUAL = 2017;
	
	//-------------------------------------------------------------------
	// Atributos
	//-------------------------------------------------------------------
	
	private String placa;
	private int modelo;
	private int kilometraje;
	private int tipo;
	private int cilindraje;
	private double soat;		
	private double avaluo;
	private double impuesto;
	private double precioTm;
	
	//--------------------------------------------------------
	//VAINAS DE LA TECNO
	//--------------------------------------------------------
	
	private double alineacion;
	private double suspension;
	private double frenos;
	private double ruido;
	private double gases;
	
	
	//--------------------------------------------------------
	//CONSTRUCTOR
	//--------------------------------------------------------
	
		public Vehiculo(String pl, int mod, int kilo, int tipo, int cili, double aval){
			
			placa = pl;
			modelo = mod;
			kilometraje = kilo;
			this.tipo = tipo;
			cilindraje = cili;
			avaluo = aval;
			
			calcularSoat();
			calcularImpuesto();
		}
		
		 //----------------------------------------------------------------------------------
		 // METODOS
		 //----------------------------------------------------------------------------------
		
		public String darPlaca(){
			return placa;
		}
		
		public int darModelo(){
			return modelo;
		}
		
		public int darKilometraje(){
			return kilometraje;
		}
		
		public int darTipoVehiculo(){
			return tipo;
		}
		
		public int darCilindraje(){
			return cilindraje;
		}
		
		public double darSoat(){
			return soat;
		}
		
		public double darAvaluo(){
			return avaluo;
		}
		
		public double darImpuesto(){
			return impuesto;
		}
		
		public double darPrecioTm(){
			return precioTm;
		}
		
		public void modificarPlaca(String placa){
			this.placa = placa;
		}
		
		public void modificarModelo(int modelo){
			this.modelo = modelo;
		}
		
		public void modificarKilometraje(int kilometraje){
			this.kilometraje = kilometraje;
		}
		
		public void modificarTipoVehiculo(int tipoVehiculo){
			tipo = tipoVehiculo;
		}
			
		public void modificarCilindraje(int cilindraje){
			this.cilindraje = cilindraje;
			
		}
		
		public void modificarSoat(double soat){
			this.soat = soat;
			
		}
		
		public void modificarAvaluo(double avaluo){
			this.avaluo = avaluo;
		}
		
		public void modificarImpuesto(double impuesto){
			this.avaluo = avaluo;
		}
		
		public void modificarPrecioTm(double precioTm){
			this.precioTm = precioTm;
		}

		
		public void calcularSoat(){
			double vs = (kilometraje * 0.25 ) * 1600;
			vs += (tipo == MOTO) ? 50000 : 70000;
			soat = vs;
			vs += (modelo <= 2010) ? 10000 : 0 ;
			vs -= esBajoCilindraje() ? vs * 0.10 : 0 ;
			
		}
	
		public boolean esBajoCilindraje(){
			return ((cilindraje == 2) ? true : false);
		}
		
		public String saberPicoyPlaca(){
		
			String mensaje;
			char ultNum = (darPlaca().charAt(5));
			mensaje = (ultNum == '2') ? "tiene pico y placa los lunes y miercoles" : (ultNum == '4') ? "tiene pico y placa los lunes y miercoles" : (ultNum == '6') ? "tiene pico y placa los lunes y miercoles" : (ultNum == '8') ? "tiene pico y placa los lunes y miercoles" : "tiene pico y placa los lunes y miercoles";
			return mensaje;	

		}	
			
		public String saberTecnoMec(){
			String tecnoM;
			tecnoM = (2017 - modelo > 5) ? "necesita revision tecnico macanica" : (kilometraje > 99999) ? "necesita revision tecnico mecanica" : "aun no necesita revision tecnico mecanica";
			return tecnoM;
		
		}
		
		public double calcularTm (double alineacion, double suspension, double frenos, double riudo, double co2, double hidrocarburos){
			double valorTm = 0.0;
			int contadorFallos = 0;
			//CALCULA EL VALOR DE LA BASE 
			valorTm += (tipo == MOTO) ? 35000 : 90000;
			//VERIFICA ALINEACION, SUSPENSION, FRENOS Y RUIDO
			if (alineacion > 10)
				contadorFallos ++;
			if (suspension < 40)
				contadorFallos ++;
			if (tipo == MOTO && frenos < 30)
				contadorFallos ++;			
			else if (tipo == CARRO && (frenos < 30 || frenos > 50))
				contadorFallos ++;
			if (ruido> 95)
				contadorFallos ++;
			//VERIFICA EMISIONES
			if (modelo <= 1970)
				if (co2 > 5.0 || hidrocarburos > 800)
					contadorFallos ++;
			else if (modelo >= 1971 && modelo <= 1984)
				if (co2 > 4.0 || hidrocarburos > 650)
					contadorFallos ++;
			else if (modelo >= 1985 && modelo <= 1997)
				if (co2 > 3.0 || hidrocarburos > 400)
					contadorFallos ++;
			else
				if (co2 > 1.0 || hidrocarburos > 200)
					contadorFallos ++;
			
			if (contadorFallos > 2)
				return 0.0;
			else 
				valorTm += contadorFallos * 25000;
			
			precioTm = valorTm;
			
			return precioTm;
		}
		
	
	public double calcularImpuesto(){
		int tBase = 10000;
		double porc = 0;
		if (tipo == CARRO)
			if (avaluo <= 25000000)
				porc += avaluo * 1.5;
			if (avaluo > 25000000 || avaluo <= 40000000)
				porc += avaluo * 2.5;
			if (avaluo > 40000000)
				porc += avaluo * 3.5;
		else 
			if (cilindraje == 1)
				porc += avaluo * 1.5;
			
		porc +=((ANIOACTUAL - modelo) * tBase);
		
		impuesto = porc;
		
		return impuesto;
		
	}
			
			
			
			
			
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}