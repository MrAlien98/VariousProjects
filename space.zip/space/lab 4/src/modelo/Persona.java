package modelo;

public class Persona

{
	
	public final static int MULTA = 165000;	 

	//--------------------------------------------------------
	//ATRIBUTOS
	//--------------------------------------------------------
	
	private String nombre;
	private String apellido;
	private String cedula;
	
	//--------------------------------------------------------
	//ASOCIACIONES
	//--------------------------------------------------------
	
	private Vehiculo v1;
	private Vehiculo v2;
	private Licencia l1;
	
	//--------------------------------------------------------
	//CONSTRUCTOR
	//--------------------------------------------------------
	
		public Persona(String nom, String ape, String cc, Vehiculo v1, Vehiculo v2, Licencia l1){
			nombre = nom;
			apellido = ape;
			cedula = cc;
			this.v1 = v1;
			this.v2 = v2;
			this.l1 = l1;
		}
		
		public String darNombre(){
			return nombre;
		}
		
		public String darApellido(){
			return apellido;
		}
		
		public String darCedula(){
			return cedula;
		}
		
		public Vehiculo darV1(){
			return v1;
		}
		
		public Vehiculo darV2(){
			return v2;
		}
		
		public Licencia darL1(){
			return l1;
		}
		
		public void modificarNombre(String nombre){
			this.nombre = nombre;
		}
		
		public void modificarApellido(String apellido){
			this.apellido = apellido;	
		}
		
		public void modificarCedula(String cedula){
			this.cedula = cedula;
		}
		
		public void modificarV1(Vehiculo v1){
			this.v1 = v1;
		}
		
		public void modificarV2(Vehiculo v2){
			this.v2 = v2;
		}
		
		public void modificarL1(Licencia l1){
			this.l1 = l1;
		}
		
		public double calcularMulta(Fecha fechaActual){
			double multa = 0;
			if (l1 != null)
			{
				boolean resultado = l1.darMensajeVen();
				if (resultado == true)
				{
					multa += MULTA;
				}
			}
			else 
			{
				multa += MULTA;
			}
			
			return multa;
		}
		
		
		
		
		
		
	
}