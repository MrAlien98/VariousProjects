package modelo;

public class Licencia
{
	
	//--------------------------------------------------------
	//CONSTANTES
	//--------------------------------------------------------
	
	public final static int MULTA = 165000;
	public final static int A1 = 1;
	public final static int A2 = 2;
	public final static int B1 = 3;
	public final static int C = 4;
	public final static int ACTIVA = 5;
	public final static int VENCIDA =6;
	
	//--------------------------------------------------------
	//ATRIBUTOS
	//--------------------------------------------------------
	
	private String numero;
	private int estado;
	private int categoria; 
	private int cat;
	boolean mensajeVen;
	//--------------------------------------------------------
	//ASOCIACIONES
	//--------------------------------------------------------
	
	private Fecha act;
	private Fecha exp;
	private Fecha venc;
	
	//--------------------------------------------------------
	//CONSTRUCTOR
	//--------------------------------------------------------
	
	public Licencia(String num, Fecha ep, int cate){
		numero = num;
		exp = ep;
		cat = cate;
	}
	
	//----------------------------------------------------------------------------------
	// METODOS
	//----------------------------------------------------------------------------------
	
	public String darNumero(){
		return numero;
	}
	
	public boolean esActiva(){
		return ((estado == 5) ? true : false);
	}
	
	public int darCategoria(){
		return categoria;
	}
	
	public Fecha darExp(){
		return exp;
	}
	
	public Fecha darVenc(){
		return venc;
	}
	
	public void modificarNumero(String numero){
		this.numero = numero;
	}
	
	
	public void modificarCatrgoria(int categoria){
		this.categoria = categoria;
	}
	
	public void modificarExp(Fecha exp){
		this.exp = exp;
	}
	
	public void modificarVenc(Fecha venc){
		this.venc = venc;
	}
	
	public boolean calcularFechaVen(int diaA, int mesA, int anioA, int diaE, int mesE, int anioE){
		int anioV = 0;
		anioV = anioE += 5;
		
		if ((anioA - anioV) > 0)
			estado = VENCIDA;
		else if ((anioA - anioV) == 0)
			if ((mesA -mesE) > 0)
				estado = VENCIDA;
			else if ((mesA - mesE) == 0)
				if ((diaA - diaE) > 0)
					estado = VENCIDA;
				else 
					estado = ACTIVA;
				
		if (estado == ACTIVA)
			mensajeVen =  true;
		else 
			mensajeVen = false;
		
		return mensajeVen;
	}
	
	public int darMulta(){
		int multa = 0;
		if (estado == VENCIDA)
			multa += MULTA;
		
		return multa;
		
	}
	
	public boolean darMensajeVen(){
		return mensajeVen;
	
	}
	
	
	
}
