package modelo;

public class Fecha

{
	
	public static final int ANIO_ACTUAL = 2017;

		
	//--------------------------------------------------------
	//ATRIBUTOS
	//--------------------------------------------------------
		
		private int dia;
		private int mes;
		private int anio;
		
		//--------------------------------------------------------
		//CONSTRUCTOR
		//--------------------------------------------------------
		
		public Fecha(int d, int m, int a){
			dia = d;
			mes = m;
			anio = a;
		}
		
		//--------------------------------------------------------
		//METODOS
		//--------------------------------------------------------
		
		public int darDia(){
			return dia;
		}
		
		public int darMes(){
			return mes;
		}
		
		public int darAnio(){
			return anio;
		}
		
		public void modificarDia(int dia){
		this.dia = dia;
		}
		
		
		public void modificarMes(int mes){
			this.mes = mes;
		}

		public void modificarAnio(int anio){
			this.anio = anio;
		}
		
		
		
		
	

}