package interfaz;

public class Recursivity {

	public Recursivity() {
		
	}
	
	public int suma(int n) {
		if(n<=1) {
			return 1;
		}else {
			return n+suma(n-1);
		}
	}
	
	public boolean isPalindrome(String str) {
		if(str.length()==1) {
			return true;
		}else {
			if(str.charAt(0)==str.charAt(str.length()-1)) {
				return isPalindrome(str.substring(1, str.length()-1));
			}else {
				return false;
			}
		}
	}
	
	public String invertir(String p) {
		String devolver="";
		if(p.length()==1) {
			devolver=p;
		}else {
			
		}
	}
	
	
	public boolean iguales(int n,int[] a, int[] b) {
		if(n==0 && a[n]==b[n]) {
			return true;
		}
		if(a[n]==b[n]) {
			return iguales(n-1,a,b);
		}
		return false;
		
	}
	
	
	public static void main(String[] args) {
		Recursivity rec=new Recursivity();
	
		int[] a= {1,2,3,4};
		int[] b= {1,2,3,4};
		int n=a.length-1;
		System.out.println(rec.iguales(n, a, b));
		
		System.out.println(rec.suma(5));
		System.out.println(rec.isPalindrome("somos"));
		
	}
	
	
//	public boolean iguales(int n,int[] a, int[] b) {
//		if(n==0) {
//			if(a[n]==b[n]) {
//				return true;
//			}else {
//				return false;
//			}
//		}else {
//			if(a[n]==b[n]) {
//				return iguales(n-1, a, b);
//			}else {
//				return false;
//			}
//		}
//	}
	
	
}
