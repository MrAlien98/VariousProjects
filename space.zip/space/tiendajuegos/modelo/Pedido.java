package modelo;

import java.util.*;


/**
 * Implementa la clase pedido
 * @author Victor Mora
 * @version 1.0 11/10/2017
 *
*/
public class Pedido{


private ArrayList itemsPedido;
	
/**
* Inicializa los valores 
*/
public Pedido(){
	itemsPedido = new ArrayList();
}


/**
* muestra los elementos del arreglo itemsPedido
* pre: el arreglo itemsPedido se ha inicializado
* @return elementos del arreglo itemsPedido
*/
public ArrayList darItemsPedido(){
	return itemsPedido;
}


/**
* Hace una lista de los elementos en el arrelo itemsPedido.
* pre: el arreglo itemsPedido se ha inicializado
* @return retorna una lista de los elementos en el e�arreglo itemsPedido.
*/
public String listarPedido(){
	String listaPed = "";
	for(int i=0; i<itemsPedido.size(); i++){
		ItemPedido ip = (ItemPedido)itemsPedido.get(i);
		listaPed += (i+1)+". "+ip.darProducto().darNombre()+"\t"+ip.darCantidad()+"\t"+ip.darProducto().darPrecio()+"\t"+ip.darProducto().darPrecio()*ip.darCantidad()+" COP"+"\n";
	}
	return listaPed;
}


/**
* Agrega un nuevo producto al arreglo itemsPedido.
* @param x!=null y u!=null.
* @param u>5 y u!=null.
*/
public void agregarItem(Producto x, int u){

	itemsPedido.add(new ItemPedido(u, x));
}


/**
* Elmina un elemento de el arreglo itemsPedido.
* pre: el arrelo itemsPedido debe estar inicializado y tener al menos un elemento.
* @param l!= null. l debe ser un numero entre 1 y el numero de elementos del arreglo itemsPedido.
*/
public void eliminarItem(int l){
	itemsPedido.remove(l);
}


/**
* Modifica el numero de unidades de un elemento el el arreglo itemsPedido.
* pre: el arreglo itemsPedido debe estar inicializado y tener al menos un elemento.
* @param x debe ser un numero entre 1 y el numero de elementos en el arreglo itemsPedido. x!=null.
* @param nUni>5 y nUni!=null.
*/
public void modificarPedido(int x, int nUni){
	x-= 1;
	ItemPedido ip = (ItemPedido)itemsPedido.get(x);
	ip.modificarCantidad(nUni);
}


/**
* Calcula el precio total de los articulos en el arreglo itemsPedido.
* pre: el arreglo itemsPedido debe estar inicializado y tener al menos un elemento.
* @return el precio total de los articulos en el arreglo itemsPedido.
*/
public double precioTotal(){
	double vT = 0;
	for(int i=0;i<itemsPedido.size();i++){
		ItemPedido ip = (ItemPedido)itemsPedido.get(i);
		vT+=ip.darProducto().darPrecio()*ip.darCantidad();
	}
	return vT;
}



}