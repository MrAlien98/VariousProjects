package modelo;

import java.util.*;


/**
 * Implementa la clase producto
 * @author Victor Mora
 * @version 1.0 11/10/2017
 *
*/
public class Producto
{
	private String codigo;
	private String nombre;
	private int precio;

	/**
	*Inicializa los valores de la clase tienda
	*/
	public Producto(String codigo, String nombre, int precio){
		this.codigo = codigo;
		this.nombre = nombre;
		this.precio = precio;
	}

/**
* Lleva el nombre del producto a quien lo llame 
* @return retorna el nombre del producto
*/
public String darNombre(){
	return nombre;
}

/**
* Modifica el nombre de un producto
* pre: nombre!="" y nombre!=null
*/
public void modificarNombre(String nombre){
	this.nombre = nombre;
}


/**
* Lleva el codigo del producto a quien lo llame
* @return retorna el codigo del producto 
*/
public String darCodigo(){
	return codigo;
}


/**
* Modifica el codigo de un producto
* pre: codigo!="" y codigo!=null
*/
public void modificarCodigo(String codigo){
	this.codigo = codigo;
}


/**
* Lleva el precio del codigo a quien lo llame
* @return retorna el precio del producto
*/
public int darPrecio(){
	return precio;
}


/**
* Modifica el precio de un producto
* pre: precio>0 y precio!=null
*/
public void modificarPrecio(int precio){
	this.precio = precio;
}




}	