package modelo;

import java.util.*;

/**
 * Implementa la clase tienda
 * @author Victor Mora
 * @version 1.0 11/10/2017
 *
*/
public class Tienda{

private ArrayList productos;
private Pedido pedido;

	/**
	* Este metodo inicializa los valores de la clase tienda.
	* post: Se instancio un ArrayList de productos
	* post: Se instanciaron 6 videjuegos de la clase Producto y se a�aden al arreglo de productos
	* post: Se instancia el pedido
	*/
	public Tienda(){
		productos = new ArrayList();

		productos.add(new Producto("vjxb001", "Battlefield 1 Standard Edition", 209000));
		productos.add(new Producto("vjxb002", "Battlefield 1 Early Enlister Deluxe Edition", 274900));	
		productos.add(new Producto("vjxb003", "Call of Duty: Infinite Warfare", 199900));
		productos.add(new Producto("vjxb004", "Call of Duty: Infinite Warfare Digital - Deluxe Edition", 300000));
		productos.add(new Producto("vjxb005", "Call of Duty: Infinite Warfare - Digital Legacy Edition", 250000));
		productos.add(new Producto("vjxb006", "EA SPORTS FIFA 17", 210000));

		pedido = new Pedido();
	}

	/**
	* muestra los elementos del arreglo productos
	* @return arreglo productos
	*/
	public ArrayList darProductos(){
		return productos;
	}
	/**
	* 
	*/
	public Pedido darPedido(){
		return pedido;
	}

	/**
	* Agrega un nuevo elemento al pedido
	* @param posicion del item en la lista. b!= null. b>1 y b<= tama�o del arreglo productos
	* @param numero de unidades del producto requeridas. unidades!=null. unidades>5
	*/
	public void agregarAPedido(int b, int unidades){
		pedido.agregarItem((Producto)productos.get(b-1), unidades);
	}


	/**
	* Agrega un nuevo producto al arreglo productos
	* @param codigo del nuevo producto. codigoN debe ser diferente a los codigos exixtentes. codigoN!=null. codigoN!=""
	* @param nombre del nuevo produto. nombreN debe ser diferente a los nombres existentes. nombreN!=null. nombreN!=""
	* @param precio del nuevo producto. precioN>0
	*/
	public void agregarProducto(String codigoN, String nombreN, int precioN){
		Producto p = new Producto(codigoN, nombreN, precioN);
		productos.add(p);
	}


	/**
	* Hace una lista de los elementos en el arreglo productos
	*/
	public String listarProductos(){
		String listaProductos ="Lista de los productos disponibles\n";
		for(int i = 0; i < productos.size(); i++){
			Producto pc = (Producto)productos.get(i);
			listaProductos += (i+1)+". "+pc.darNombre()+"\t"+pc.darCodigo()+"\n";
		}
		return listaProductos;
	}


	/**
	* Elimina un elemento de el arreglo itemsPedido
	* pre: el numero recibido debe estar entre 1 y el numero de elementos del arreglo ItemsPedido
	*/
	public void eliminarElementoPedido(int y){
		pedido.eliminarItem(y-1);
	}


	/**
	* Verifica si ya existe un videojuego con el codigo recibido como parametro
	* pre: c != "" 
	* pre: c != null
	* @return retorna true si encuentra un videojuego con el mismo codigo y false en caso contrario
	*/
	public boolean verificarCodigo(String c){

		for(int i =0; i<productos.size(); i++){
			Producto p = (Producto)productos.get(i);
			if(p.darCodigo().equalsIgnoreCase(c)){
				return true;
			}
		}
		
		return false;
	}



}