package modelo;

import java.util.*;

/**
 * Implementa la clase itempedido
 * @author Victor Mora
 * @version 1.0 11/10/2017
 *
*/

public class ItemPedido{

	private int cantidad;
	
	private Producto producto;

/**
* Este metodo inicializa los valores de la clase ItemPedido.
*/
public ItemPedido(int xCantidad, Producto nProducto){
	cantidad = xCantidad;
	producto = nProducto;

}

/**
* retorna la cantidad de unidades que el usuario quiere del item del pedido.
* @return cantidad pedida de un item.
*/
public int darCantidad(){
	return cantidad;
}

/**
* retorna el producto.
* @return e lproducto.
*/
public Producto darProducto(){
	return producto;
}


/**
* modifica la cantidad de unidades de un producto.
* @param cant>5. cant!=null.
*/
public void modificarCantidad(int cant){
	cantidad = cant;
}



}