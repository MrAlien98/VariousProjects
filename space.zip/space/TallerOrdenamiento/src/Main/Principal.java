package Main;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

public class Principal {

	private ArrayList<int[]> arreglos;
	private Random aleatorio;
	
	public Principal() {
		arreglos=new ArrayList<int[]>();
		aleatorio=new Random();
		crearArreglos();
	}
	
	public ArrayList<int[]> darArreglos() {
		return arreglos;
	}
	
	public void crearArreglos() {
		int f=0;
		for(int i=0;i<100;i++) {
			f=aleatorio.nextInt(1000)+10;
			int[] n=new int[f];
			for(int j=0;j<n.length;j++) {
				f=aleatorio.nextInt(1000);
				n[j]=f;
			}
			arreglos.add(n);
		}
		burbuja(darArreglos());
		insercion(darArreglos());
		seleccion(darArreglos());
		escribirArchivos();
	}
	
	public String burbuja(ArrayList<int[]> llega) {
		long principio=System.nanoTime();
		String end="";
		ArrayList<int[]> arreglo=llega;
		for(int i=0;i<arreglo.size();i++) {
			int[] n=arreglo.get(i);
			end+="\n";
			for(int l=n.length-1;l>0;l--) {
				for(int j=0;j<l;j++) {
					if(n[j]>n[j+1]) {
						int temp=n[j];
						n[j]=n[j+1];
						n[j+1]=temp;
					}
				}
			}
			for(int m=0;m<n.length;m++) {
				end+=n[m]+" ";
			}
		}
		System.out.println(end);
		long finish=System.nanoTime();
		long transcurso=finish-principio;
		nanoBurbuja(transcurso);
		return end;
	}
	
	public String insercion(ArrayList<int[]> llega) {
		long principio=System.nanoTime();
		String end="";
		ArrayList<int[]> arreglo=llega;
		for(int i=0;i<arreglo.size();i++) {
			int[] n=arreglo.get(i);
			end+="\n";
			for(int j=1;j<n.length-1;j++) {
				for(int l=j;l>0 && n[l-1]>n[l];l++) {
					int temp=n[l];
					n[l]=n[l-1];
					n[l-1]=temp;
				}
			}
			for(int m=0;m<n.length;m++) {
				end+=n[m]+" ";
			}
		}
		System.out.println(end);
		long finish=System.nanoTime();
		long transcurso=finish-principio;
		nanoInsercion(trnscurso);
		return end;
	}
	
	public String seleccion(ArrayList<int[]> llega) {
		long principio=System.nanoTime();
		String end="";
		ArrayList<int[]> arreglo=llega;
		for(int l=0;l<arreglo.size();l++) {
			int[] n=arreglo.get(l);
			end+="\n";
			for(int i=0;i<n.length-1;i++) {
				int menor=n[i];
				int cual=i;
				for(int j=i+1;j<n.length;j++) {
					if(n[j]<menor) {
						cual=j;
					}
				}
				int temp=n[i];
				n[i]=menor;
				n[cual]=temp;
			}
			for(int m=0;m<n.length;m++) {
				end+=n[m]+" ";
			}
		}
		System.out.println(end);
		long finish=System.nanoTime();
		long transcurso=finish-principio;
		nanoSeleccion(transcurso);
		return end;
	}
	
	public void nanoBurbuja(long burbuja) {
		System.out.println("El metodo de burbuja tard�: "+burbuja+" nanosegundos");
	}
	
	public void nanoInsercion(long insercion) {
		System.out.println("El metodo de incersion tard�: "+insercion+" nanosegundos");
	}
	
	public void nanoSeleccion(long seleccion) {
		System.out.println("El metodo de seleccion tard�: "+seleccion+" nanosegundos");
	}
	
	public void escribirArchivos(long burbuja, long insercion, long seleccion) {
		try {
			ObjectOutputStream escribir=new ObjectOutputStream(/**Indico la ruta de donde se va a guardar*/new FileOutputStream("C:/Users/c/eclipse-workspace/TallerOrdenamiento/src/Burbuja.txt"));
			escribir.writeObject(burbuja(darArreglos()));
			escribir.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		try {
			ObjectOutputStream escribir=new ObjectOutputStream(/**Indico la ruta de donde se va a guardar*/new FileOutputStream("C:/Users/c/eclipse-workspace/TallerOrdenamiento/src/Insercion.txt"));
			escribir.writeObject(insercion(darArreglos()));
			escribir.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		try {
			ObjectOutputStream escribir=new ObjectOutputStream(/**Indico la ruta de donde se va a guardar*/new FileOutputStream("C:/Users/c/eclipse-workspace/TallerOrdenamiento/src/Seleccion.txt"));
			escribir.writeObject(seleccion(darArreglos()));
			escribir.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main (String[] args) {
		Principal principal=new Principal();
	}
}