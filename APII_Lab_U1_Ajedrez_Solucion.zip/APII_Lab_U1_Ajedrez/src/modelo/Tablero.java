package modelo;

/**
 * Entidad que representa un tablero de ajedrez
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 */
public class Tablero {
	/**
	 * Constante para indicar que el tablero no esta rotado
	 */
	public final static int ROTACION_0 = 0;
	
	/**
	 * Constante para indicar que el tablero esta rotado 90 grados
	 */
	public final static int ROTACION_90 = 1;
	
	/**
	 * Constante para indicar que el tablero esta rotado 180 grados
	 */
	public final static int ROTACION_180 = 2;
	
	/**
	 * Constante para indicar que el tablero esta rotado 270 grados
	 */
	public final static int ROTACION_270 = 3;
	
	/**
	 * Constante para la cantidad de casillas de cada lado del tablero
	 */
	public final static int LADO = 9;
	
	/**
	 * Constante para el tamano maximo de una jugada
	 */
	public final static int MAX_JUGADA = 5;
	
	/**
	 * Indica la direccion del tablero, true para blancas abajo, false para blancas arriba 
	 */
	private int direccion;
	
	/**
	 * Un arreglo bidimensional de todas las casillas del tablero 
	 */
	private Casilla[][] tablero;
	
	/**
	 * Crea un nuevo tablero, lo inicializa y pone las piezas en su estado inicial
	 */
	public Tablero() {
		inicializarTablero();
	}
	
	/**
	 * Inicializa todas las casillas, el tablero y sus piezas en su posicion inicial
	 * con la direccion de blancas abajo 
	 */
	public void inicializarTablero() {
		inicializarCasillas();
		establecerPosicionInicial();		
		direccion = ROTACION_0;
	}
	
	/**
	 * Inicializa las casillas con sus respectivos colores, pero sin fichas
	 */
	private void inicializarCasillas() {
		tablero = new Casilla[LADO][LADO];
		for(int i=0;i<tablero.length-1;i++) {
			tablero[i][0] = new Casilla(Casilla.GRIS, (tablero.length-1-i)+"");
			for(int j=1;j<tablero[i].length;j++) {
				char colorCasilla = darColorCasilla(i, j);
				tablero[i][j] = new Casilla(colorCasilla);
			}
		}
		tablero[tablero.length-1][0] = new Casilla(Casilla.GRIS);
		char letra = 'a';
		for(int j=1;j<tablero[tablero.length-1].length;j++) {
			tablero[tablero.length-1][j] = new Casilla(Casilla.GRIS, (char)(letra+j-1)+"");
		}
		
	}
	
	/**
	 * Calcula el color de la casilla de acuerdo con su coordenada
	 * @param i es la fila de la casilla
	 * @param j es la columna de la casilla
	 * @return el color de la casilla en esa posicion
	 */
	private char darColorCasilla(int i, int j) {
		if((i+j)%2==0) {
			return Casilla.NEGRO;
		}else {
			return Casilla.BLANCO;
		}
	}
	
	/**
	 * Consultar todas las casillas del tablero
	 * @return las casillas
	 */
	public String[][] darCasillas(){
		String[][] casillas = new String[tablero.length][tablero[0].length];
		for (int i = 0; i < casillas.length; i++) {
			for (int j = 0; j < casillas[i].length; j++) {
				String nombreFichaCasilla = darNombreFichaCasilla(tablero[i][j]);
				casillas[i][j] = nombreFichaCasilla;
			}
		}
		casillas = rotarTablero(casillas);
		return casillas;
	}
	
	private String[][] rotarTablero(String[][] casillas) {
		switch(direccion) {
			case ROTACION_90:
				casillas = rotarMatriz90(casillas);
			break;
			case ROTACION_180:
				casillas = rotarMatriz180(casillas);
			break;
			case ROTACION_270:
				casillas = rotarMatriz180(casillas);
				casillas = rotarMatriz90(casillas);
			break;
		}
		return casillas;
	}

	/**
	 * Rota un tablero 180 grados manteniendo la ubicacion pero actualizando 
	 * los valores de las filas y las columnas  
	 * @param matriz es la matriz que se va a rotar
	 * @return la matriz ya rotada
	 */
	private String[][] rotarMatriz180(String[][] matriz){
		String[][] rotada = new String[matriz.length][matriz[0].length];
		
		//rotando el tablero
		for (int i = 0; i < rotada.length-1; i++) {
			for (int j = 1; j < rotada[i].length; j++) {
				rotada[i][j] = matriz[matriz.length-i-2][matriz[i].length-j];
			}
		}
		
		//inviertiendo los numeros de las filas
		for (int i = 0; i < rotada.length-1; i++) {
			rotada[i][0] = matriz[matriz.length-i-2][0];
		}
		
		//inviertiendo las letras de las columnas
		for (int j = 1; j < rotada[rotada.length-1].length; j++) {
			rotada[rotada.length-1][j] = matriz[matriz.length-1][matriz.length-j];
		}
		
		return rotada;
	}
	
	/**
	 * Rota un tablero 90 grados manteniendo la ubicacion pero actualizando 
	 * los valores de las filas y las columnas  
	 * @param matriz es la matriz que se va a rotar
	 * @return la matriz ya rotada
	 */
	private String[][] rotarMatriz90(String[][] matriz){
		String[][] rotada = new String[matriz.length][matriz[0].length];
		
		//rotando el tablero
		for (int i = 0; i < rotada.length-1; i++) {
			for (int j = 1; j < rotada[i].length; j++) {
				rotada[i][j] = matriz[matriz.length-j-1][i+1];
			}
		}

		//inviertiendo los numeros de las filas
		for (int i = 0; i < rotada.length-1; i++) {
			rotada[i][0] = matriz[matriz.length-1][i+1];
		}
		
		//inviertiendo las letras de las columnas
		for (int j = 1; j < rotada[rotada.length-1].length; j++) {
			rotada[rotada.length-1][j] = matriz[rotada.length-j-1][0];
		}

		return rotada;
	}
	
	/**
	 * Consultar la direccion del tablero
	 * @return la direccion actual del tablero
	 */
	public int darDireccion() {
		return direccion;
	}
	
	/**
	 * Rota el tablero 90 grados en sentido de las manecillas del reloj
	 */
	public void rotar() {
		direccion = (direccion+1)%4;
	}
	
	/**
	 * Convierte la casilla en un formato de cadena para que pueda ser interpretado por
	 * otras clases, entre ellas la interfaz con el usuario
	 * @param c es la casilla que sera convertida a cadena
	 * @return la cadena con la informacion de la casilla
	 */
	private String darNombreFichaCasilla(Casilla c) {
		String nombre;
		if(c.darColor()==Casilla.GRIS) {
			nombre = c.darPosicion();
		}else {
			nombre = ""+c.darColor();
			Ficha f = c.darFicha();
			if(f!=null) {
				nombre = f.darTipo()+"_"+f.darColor()+"_"+nombre;
			}
		}
		return nombre;
	}
	
	/**
	 * Pone las casillas en la posicion inicial estandar de ajedrez
	 * <b>pre:</b>tablero!=null y tablero[i][j]!=null para todas las casillas
	 */
	private void establecerPosicionInicial() {
		tablero[0][1].cambiarFicha(new Ficha(Ficha.TORRE,Ficha.NEGRO));
		tablero[0][2].cambiarFicha(new Ficha(Ficha.CABALLO, Ficha.NEGRO));
		tablero[0][3].cambiarFicha(new Ficha(Ficha.ALFIL, Ficha.NEGRO));
		tablero[0][4].cambiarFicha(new Ficha(Ficha.DAMA, Ficha.NEGRO));
		tablero[0][5].cambiarFicha(new Ficha(Ficha.REY, Ficha.NEGRO));
		tablero[0][6].cambiarFicha(new Ficha(Ficha.ALFIL, Ficha.NEGRO));
		tablero[0][7].cambiarFicha(new Ficha(Ficha.CABALLO, Ficha.NEGRO));
		tablero[0][8].cambiarFicha(new Ficha(Ficha.TORRE, Ficha.NEGRO));
		
		tablero[7][1].cambiarFicha(new Ficha(Ficha.TORRE,Ficha.BLANCO));
		tablero[7][2].cambiarFicha(new Ficha(Ficha.CABALLO, Ficha.BLANCO));
		tablero[7][3].cambiarFicha(new Ficha(Ficha.ALFIL, Ficha.BLANCO));
		tablero[7][4].cambiarFicha(new Ficha(Ficha.DAMA, Ficha.BLANCO));
		tablero[7][5].cambiarFicha(new Ficha(Ficha.REY, Ficha.BLANCO));
		tablero[7][6].cambiarFicha(new Ficha(Ficha.ALFIL, Ficha.BLANCO));
		tablero[7][7].cambiarFicha(new Ficha(Ficha.CABALLO, Ficha.BLANCO));
		tablero[7][8].cambiarFicha(new Ficha(Ficha.TORRE, Ficha.BLANCO));
		
		for (int i = 1; i < tablero.length; i++) {
			tablero[1][i].cambiarFicha(new Ficha(Ficha.PEON, Ficha.NEGRO));
			tablero[6][i].cambiarFicha(new Ficha(Ficha.PEON, Ficha.BLANCO));
		}
	}
	
	/**
	 * Lleva a cabo la jugada indicada en la cadena jugada que entra por parametro<br/>
	 * @param jugada es la jugada en notacion algebraica modificada, la jugada es valida
	 */
	public void jugar(String jugada) {
		int ajuste = 0; //si se mueve un peon
		if(jugada.length()==MAX_JUGADA) {//si se mueve una pieza
			ajuste = 1;
		}
		char columnaInicialNotacion = jugada.charAt(0+ajuste);
		char filaInicialNotacion = jugada.charAt(1+ajuste);
		char columnaFinalNotacion = jugada.charAt(2+ajuste);
		char filaFinalNotacion = jugada.charAt(3+ajuste);
		
		int columnaInicialReal = convertirAColumnaReal(columnaInicialNotacion);
		int filaInicialReal    = convertirAFilaReal(filaInicialNotacion);
		int columnaFinalReal   = convertirAColumnaReal(columnaFinalNotacion);
		int filaFinalReal      = convertirAFilaReal(filaFinalNotacion);
		//System.out.println(filaInicialNotacion+","+columnaInicialNotacion+":"+filaFinalNotacion+","+columnaFinalNotacion);
		//System.out.println(filaInicialReal+","+columnaInicialReal+":"+filaFinalReal+","+columnaFinalReal);
		
		Casilla casillaInicial = tablero[filaInicialReal][columnaInicialReal];
		Casilla casillaFinal = tablero[filaFinalReal][columnaFinalReal];
		casillaFinal.cambiarFicha(casillaInicial.darFicha());
		casillaInicial.cambiarFicha(null);
	}
	
	/**
	 * Convierte una columna de tablero de ajedrez (de la a hasta la h) a una coordenada en
	 * el tablero (matriz) manejado en esta clase
	 * @param columnaNotacion la letra de la columna a convertir
	 * @return la posicion de la columna en la matriz del tablero
	 */
	private int convertirAColumnaReal(char columnaNotacion) {
		return columnaNotacion-'a'+1;
	}
	
	/**
	 * Convierte una fila de tablero de ajedrez con blancas abajo en una coordenada en
	 * el tablero manejado en esta clase
	 * @param filaNotacion es el numero en formato char que se va a convertir
	 * @return la posicion de la fila en la matriz del tablero
	 */
	private int convertirAFilaReal(char filaNotacion) {
		return LADO-(filaNotacion-'0')-1;
	}	
}
