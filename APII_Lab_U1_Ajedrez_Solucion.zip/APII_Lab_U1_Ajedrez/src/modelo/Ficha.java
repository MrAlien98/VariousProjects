package modelo;

/**
 * Entidad que representa una ficha en un tablero de ajedrez.
 * Esta puede ser pieza (caballo, torre, alfil, dama y rey) o peon.
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 */
public class Ficha {
	/**
	 * Constante para representar la pieza caballo
	 */
	public final static char CABALLO='C';
	/**
	 * Constante para representar la pieza torre
	 */
	public final static char TORRE='T';
	/**
	 * Constante para representar la pieza alfil
	 */
	public final static char ALFIL='A';
	/**
	 * Constante para representar la pieza dama
	 */
	public final static char DAMA='D';
	/**
	 * Constante para representar la pieza rey
	 */
	public final static char REY='R';
	/**
	 * Constante para representar el peon
	 */
	public final static char PEON='P';
	
	/**
	 * Constante para representar el ejercito blanco
	 */
	public final static char BLANCO = 'B';
	/**
	 * Constante para representar el ejercito negro
	 */
	public final static char NEGRO = 'N';
	
	/**
	 * Indica el tipo de ficha (peon, caballo, alfil, torre, dama o rey)
	 */
	private char tipo;
	
	/**
	 * Indica el ejercito al que pertenece esta pieza: blanco o negro
	 */
	
	private char color;
	
	/**
	 * Crea una nueva ficha con el tipo y color indicado
	 * @param t es el tipo de la nueva ficha
	 * @param c es el color de la nueva ficha
	 */
	public Ficha(char t, char c) {
		tipo = t;
		color = c;
	}

	/**
	 * Consulta el tipo
	 * @return el tipo de esta ficha
	 */
	public char darTipo() {
		return tipo;
	}
	
	/**
	 * Cambia el tipo de esta ficha. En el juego estandar solo aplica
	 * cuando el peon se promociona al llegar a la ultima fila
	 * @param t es el nuevo tipo de ficha
	 */
	public void cambiarTipo(char t) {
		tipo = t;
	}
	
	/**
	 * Consulta el color
	 * @return el color de esta ficha
	 */
	public char darColor() {
		return color;
	}
}
