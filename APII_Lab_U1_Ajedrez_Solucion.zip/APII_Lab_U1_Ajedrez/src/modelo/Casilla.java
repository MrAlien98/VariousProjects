package modelo;

/**
 * Entidad que representa una casilla del tablero
 * @author Juan Manuel Reyes <jmreyes@icesi.edu.co>
 */
public class Casilla {
	/**
	 * Constate para el color blanco de una casilla
	 */
	public final static char BLANCO = 'B';
	/**
	 * Constate para el color negro de una casilla
	 */
	public final static char NEGRO = 'N';
	
	/**
	 * Constate para el color gris de una casilla
	 */
	public final static char GRIS = 'G';
	
	/**
	 * Indica el color actual de esta casilla
	 */
	private char color;
	
	/**
	 * La ficha que se encuentra en la casilla actual
	 */
	private Ficha ficha;

	/**
	 * Indica la posicion de esta casilla en nomenclatura algebraica
	 */
	private String posicion;
	
	/**
	 * Crea una nueva casilla sin ficha en ella
	 * @param c es el color de la nueva casilla
	 */
	public Casilla(char c) {
		color = c;
		ficha = null;
		posicion = "";
	}

	/**
	 * Crea una nueva casilla
	 * @param c es el color de la nueva casilla
	 * @param f es la ficha en la nueva casilla
	 */
	public Casilla(char c, Ficha f) {
		color = c;
		ficha = f;
		posicion = "";
	}

	/**
	 * Crea una nueva casilla
	 * @param c es el color de la nueva casilla
	 * @param p es la posicion de la nueva casilla
	 */
	public Casilla(char c, String p) {
		color = c;
		ficha = null;
		posicion = p;
	}

	/**
	 * Consulta el color de la casilla actual
	 * @return el color de esta casilla
	 */
	public char darColor() {
		return color;
	}

	/**
	 * Consulta la ficha que se encuentra actualmente la casilla
	 * @return la ficha actual
	 */
	public Ficha darFicha() {
		return ficha;
	}
	
	/**
	 * Cambia la casilla actual por otra (o null si queda vacia)
	 * @param f es el valor de la nueva casilla
	 */
	public void cambiarFicha(Ficha f) {
		ficha = f;
	}
	
	/**
	 * Consulta la posicion que tiene la casilla actual
	 * @return la posicion de la casilla
	 */
	public String darPosicion() {
		return posicion;
	}	
}
