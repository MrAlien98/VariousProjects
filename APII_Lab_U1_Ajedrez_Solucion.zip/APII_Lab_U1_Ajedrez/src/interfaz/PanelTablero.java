package interfaz;

import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class PanelTablero extends JPanel{
	private JLabel[][] casillas;
	public PanelTablero() {
		
	}
	
	/**
	 * Actualiza el estado del tablero en el panel 
	 * @param tablero es una matriz de cadenas con la configuracion del tablero con sus piezas
	 */
	public void refrescar(String[][] tablero) {
		int alto = tablero.length;
		int ancho = tablero[0].length;
		
		removeAll();
		setLayout(new GridLayout(alto, ancho));
		
		casillas = new JLabel[alto][ancho];
		
		for (int i = 0; i < casillas.length; i++) {
			for (int j = 0; j < casillas[i].length; j++) {
				String nombreFichaCasilla = tablero[i][j];
				String nombreArchivo = "imgs/"+nombreFichaCasilla+".png";
				ImageIcon ii = new ImageIcon(nombreArchivo);
				
				if(ii.getIconHeight()==-1) {//si no hay archivo de imagen con ese nombre
					casillas[i][j] = new JLabel(nombreFichaCasilla, SwingConstants.CENTER);
					casillas[i][j].setFont(new Font("Helvetica", Font.BOLD, 20));
				}else {//si hay archivo de imagen con ese nombre
					casillas[i][j] = new JLabel(ii);
				}
				add(casillas[i][j]);
			}
		}
	}

}
