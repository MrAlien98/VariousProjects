package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

@SuppressWarnings("serial")
public class PanelOpciones extends JPanel implements ActionListener{
	private JLabel labJugada;
	private JTextField txtJugada;
	private JButton butJugar;
	private JButton butRotar;
	private JButton butReiniciar;
	private JCheckBox chkRotar;
	
	public final static String JUGAR = "JUGAR";
	public final static String ROTAR = "ROTAR";
	public final static String REINICIAR = "REINICIAR";
	
	private VentanaAjedrez principal;
	
	public PanelOpciones(VentanaAjedrez ventana) {
		principal = ventana;
		
		setLayout(new BorderLayout());
		
		labJugada    = new JLabel("Jugada:", SwingConstants.RIGHT);
		txtJugada    = new JTextField();
		butJugar     = new JButton("Jugar!");
		butRotar     = new JButton("Rotar");
		butReiniciar = new JButton("Reiniciar");
		chkRotar     = new JCheckBox("Rotar Aut.");
		
		JPanel panelAuxiliar = new JPanel();
		panelAuxiliar.setLayout(new GridLayout(1, 5));
		panelAuxiliar.add(labJugada);
		panelAuxiliar.add(txtJugada);
		panelAuxiliar.add(butJugar);
		panelAuxiliar.add(butRotar);
		panelAuxiliar.add(butReiniciar);
		
		add(panelAuxiliar, BorderLayout.WEST);
		add(chkRotar, BorderLayout.EAST);
		
		butJugar.setActionCommand(JUGAR);
		butRotar.setActionCommand(ROTAR);
		butReiniciar.setActionCommand(REINICIAR);
		
		butJugar.addActionListener(this);
		butRotar.addActionListener(this);
		butReiniciar.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String comando = e.getActionCommand();
		
		if(comando.equals(JUGAR)) {
			principal.jugar();
		}else if(comando.equals(ROTAR)) {
			principal.rotar();
		}else if(comando.equals(REINICIAR)) {
			principal.reiniciar();
		}
	}
	
	public String darJugada() {
		return txtJugada.getText().trim();
	}
	
	public boolean rotaAutomaticamente() {
		return chkRotar.isSelected();
	}
}
