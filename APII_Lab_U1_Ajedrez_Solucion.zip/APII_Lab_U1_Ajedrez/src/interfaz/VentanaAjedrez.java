package interfaz;

import java.awt.BorderLayout;

import javax.swing.JFrame;

import modelo.Tablero;

@SuppressWarnings("serial")
public class VentanaAjedrez extends JFrame{
	private Tablero miTablero;
	private PanelTablero panelTablero;
	private PanelOpciones panelOpciones;
	
	public VentanaAjedrez() {
		miTablero = new Tablero();
		panelOpciones = new PanelOpciones(this);
		panelTablero = new PanelTablero();
		actualizarPanelTablero();
		
		setTitle("Ajedrez Academico :: Algoritmos y Programacion II");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		add(panelTablero, BorderLayout.CENTER);
		add(panelOpciones, BorderLayout.SOUTH);
		pack();
	}
	
	private void actualizarPanelTablero() {
		String[][] casillas = miTablero.darCasillas();
		panelTablero.refrescar(casillas);
		panelTablero.revalidate();
	}
	
	public void jugar() {
		String jugada = panelOpciones.darJugada();
		boolean rotaAutom = panelOpciones.rotaAutomaticamente();
		
		miTablero.jugar(jugada);
		if(rotaAutom) {
			miTablero.rotar();
		}
		actualizarPanelTablero();
	}
	
	public void rotar() {
		miTablero.rotar();
		actualizarPanelTablero();
	}
	
	public void reiniciar() {
		miTablero.inicializarTablero();
		actualizarPanelTablero();
	}
	
	public static void main(String[] args) {
		VentanaAjedrez va;
		va = new VentanaAjedrez();
		va.setVisible(true);
	}
}
