/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico
 * Autor: Mario S�nchez - 23/06/2005 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

package uniandes.cupi2.brazoMecanico.test;

import java.awt.Color;
import java.io.File;

import junit.framework.TestCase;
import uniandes.cupi2.brazoMecanico.mundo.Bodega;
import uniandes.cupi2.brazoMecanico.mundo.Cubo;

/**
 * Clase de prueba para la bodega
 */
public class BodegaTest extends TestCase
{
    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Bodega del escenario 1
     */
    private Bodega bodega1 = null;

    /**
     * Bodega del escenario 2
     */
    private Bodega bodega2 = null;

    /**
     * Bodega del escenario 3
     */
    private Bodega bodega3 = null;

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Prepara el escenario 1 <br>
     * <code>
     *   |       | 
     *   |  x    | 
     *   |  x x  |
     *   |x x x  |
     *    - - - - 
     * </code>
     */
    private void setupEscenario1( )
    {
        bodega1 = new Bodega( 4, 4 );

        Cubo c1 = new Cubo( Color.BLACK );
        Cubo c2 = new Cubo( Color.YELLOW );
        Cubo c3 = new Cubo( Color.RED );
        Cubo c4 = new Cubo( Color.BLUE );
        Cubo c5 = new Cubo( Color.GREEN );
        Cubo c6 = new Cubo( Color.CYAN );

        bodega1.agregarCubo( 0, 0, c1 );
        bodega1.agregarCubo( 1, 0, c2 );
        bodega1.agregarCubo( 1, 1, c3 );
        bodega1.agregarCubo( 1, 2, c4 );
        bodega1.agregarCubo( 2, 0, c5 );
        bodega1.agregarCubo( 2, 1, c6 );
    }

    /**
     * Prepara el escenario 2 <br>
     * <code>
     *   |             | 
     *   |             | 
     *   |             | 
     *   |             |
     *   |  R   V      |
     *    - - - - - - -
     * </code>
     * @throws Exception Error al cargar la bodega
     */
    private void setupEscenario2( ) throws Exception
    {
        bodega2 = new Bodega( );
        bodega2.cargarMundo( new File( "test/data/bodega1.bdg" ) );
    }

    /**
     * Crea una bodega sin inicializar
     */
    private void setupEscenario3( )
    {
        bodega3 = new Bodega( );
    }

    /**
     * Verifica el m�todo agarrarCubo
     */
    public void testAgarrarCubo( )
    {
        setupEscenario1( );

        Cubo c = bodega1.darCubo( 0, 1 );
        assertNull( "En una posici�n vac�a agarrarCubo deber�a retornar null", c );

        Cubo c2;
        try
        {
            c2 = bodega1.recogerCubo( 0, 0 );
            assertNotNull( "En una posici�n no vac�a agarrarCubo no deber�a retornar null", c2 );
            assertEquals( "El color del cubo est� equivocado", c2.darColor( ), Color.BLACK );

            assertFalse( "En la posici�n donde se recogi� el cubo ya no hay uno", bodega1.hayCubo( 0, 0 ) );
        }
        catch( Exception e )
        {
            fail( "Error al recoger un cubo en una posici�n valida!" );
        }
    }

    /**
     * Verificar el m�todo cargar
     *  
     */
    public void testCargar( )
    {
        try
        {
            setupEscenario2( );
        }
        catch( Exception e )
        {
            fail( "No se pudo cargar la bodega" );
        }

        assertEquals( "Las dimensiones se cargaron mal", bodega2.darMaxX( ), 6 );
        assertEquals( "Las dimensiones se cargaron mal", bodega2.darMaxY( ), 4 );
        assertTrue( "La bodega no se inici�", bodega2.darIniciado( ) );
        for( int x = 0; x <= 6; x++ )
        {
            for( int y = 0; y <= 4; y++ )
            {
                try
                {
                    Cubo c = bodega2.darCubo( x, y );

                    boolean posicionCorrecta = false;
                    if( ( 1 == x || 3 == x ) && y == 0 )
                        posicionCorrecta = true;

                    assertEquals( "Hay un cubo en una posici�n equivocada (" + x + "," + y + ")", posicionCorrecta, c != null );
                }
                catch( Exception e )
                {
                    fail( e.getMessage( ) );
                }
            }
        }
    }

    /**
     * Verifica el m�todo darCubo
     *  
     */
    public void testDarCubo( )
    {
        setupEscenario1( );

        try
        {
            Cubo c = bodega1.darCubo( 0, 1 );
            assertNull( "En una posici�n vac�a agarrarCubo deber�a retornar null", c );
        }
        catch( Exception e )
        {
            fail( e.getMessage( ) );
        }

        try
        {
            Cubo c2 = bodega1.darCubo( 0, 0 );

            assertNotNull( "En una posici�n no vac�a agarrarCubo no deber�a retornar null", c2 );
            assertEquals( "El color del cubo est� equivocado", c2.darColor( ), Color.BLACK );

            assertTrue( "En la posici�n donde se pidi� el cubo sigue estando", bodega1.hayCubo( 0, 0 ) );
        }
        catch( Exception e )
        {
            fail( e.getMessage( ) );
        }
    }

    /**
     * Verificar el m�todo darFilaTopeColumna
     *  
     */
    public void testDarFilaTopeColumna( )
    {
        setupEscenario1( );

        assertEquals( "El tope de la columna 1 debe ser 1", 1, bodega1.darFilaTopeColumna( 0 ) );
        assertEquals( "El tope de la columna 2 debe ser 3", 3, bodega1.darFilaTopeColumna( 1 ) );
        assertEquals( "El tope de la columna 3 debe ser 2", 2, bodega1.darFilaTopeColumna( 2 ) );
        assertEquals( "El tope de la columna 4 debe ser 0", 0, bodega1.darFilaTopeColumna( 3 ) );
    }

    /**
     * Verificar el m�todo darIniciado
     *  
     */
    public void testDarIniciado( )
    {
        setupEscenario1( );
        try
        {
            setupEscenario2( );
        }
        catch( Exception e )
        {
            fail( "No se pudo cargar la bodega" );
        }
        setupEscenario3( );

        assertTrue( "La bodega ya est� iniciada", bodega1.darIniciado( ) );
        assertTrue( "La bodega ya est� iniciada", bodega2.darIniciado( ) );
        assertFalse( "La bodega no est� iniciada", bodega3.darIniciado( ) );
    }

    /**
     * Verificar el ancho y el alto de las bodegas
     *  
     */
    public void testDarMax( )
    {
        setupEscenario1( );
        try
        {
            setupEscenario2( );
        }
        catch( Exception e )
        {
            fail( "No se pudo cargar la bodega" );
        }

        assertEquals( "El ancho de la bodega 1 est� equivocado", 3, bodega1.darMaxX( ) );
        assertEquals( "El alto de la bodega 1 est� equivocado", 3, bodega1.darMaxY( ) );

        assertEquals( "El ancho de la bodega 2 est� equivocado", 6, bodega2.darMaxX( ) );
        assertEquals( "El alto de la bodega 2 est� equivocado", 4, bodega2.darMaxY( ) );
    }

    /**
     * Verificar el m�todo dejarCubo
     *  
     */
    public void testDejarCubo( )
    {
        setupEscenario1( );

        try
        {
            bodega1.dejarCubo( 1, 3, new Cubo( Color.BLACK ) );
            Cubo c = bodega1.darCubo( 1, 3 );
            assertEquals( "El cubo que se sac� de la posici�n no es el mismo que se dej�", Color.BLACK, c.darColor( ) );
        }
        catch( Exception e )
        {
            fail( "En la posici�n indicada se puede dejar un cubo" );
        }

        try
        {
            bodega1.dejarCubo( 1, 3, new Cubo( Color.BLUE ) );
            fail( "En la posici�n indicada NO se puede dejar un cubo" );
        }
        catch( Exception e )
        {

        }

        try
        {
            Cubo c = bodega1.darCubo( 1, 3 );

            assertEquals( "El cubo que se sac� de la posici�n no es el mismo que se dej�: el intento fallido reemplaz� el cubo", Color.BLACK, c.darColor( ) );
        }
        catch( Exception e )
        {
            fail( e.getMessage( ) );
        }

        try
        {
            bodega1.dejarCubo( 0, 3, new Cubo( Color.BLUE ) );
            fail( "En la posici�n indicada NO se puede dejar un cubo" );
        }
        catch( Exception e )
        {
        }

        try
        {
            bodega1.dejarCubo( 5, 4, new Cubo( Color.BLUE ) );
            fail( "En la posici�n indicada NO se puede dejar un cubo" );
        }
        catch( Exception e )
        {
        }

        try
        {
            bodega1.dejarCubo( 1, 5, new Cubo( Color.BLUE ) );
            fail( "En la posici�n indicada NO se puede dejar un cubo" );
        }
        catch( Exception e )
        {
        }
    }

    /**
     * Verificar el m�todo hayCubo
     *  
     */
    public void testHayCubo( )
    {
        setupEscenario1( );

        assertTrue( "En la posici�n verificada hay un cubo", bodega1.hayCubo( 1, 2 ) );
        assertFalse( "En la posici�n verificada no hay un cubo", bodega1.hayCubo( 1, 3 ) );
    }

    /**
     * Verificar el m�todo puede soltar
     *  
     */
    public void testPuedeSoltar( )
    {
        setupEscenario1( );

        assertTrue( "En la posici�n indicada se puede dejar un cubo", bodega1.puedeDejarCubo( 1, 3 ) );

        assertFalse( "En la posici�n indicada NO se puede dejar un cubo", bodega1.puedeDejarCubo( 1, 2 ) );

        assertFalse( "En la posici�n indicada NO se puede dejar un cubo", bodega1.puedeDejarCubo( -1, 3 ) );
        assertFalse( "En la posici�n indicada NO se puede dejar un cubo", bodega1.puedeDejarCubo( 4, 3 ) );
        assertFalse( "En la posici�n indicada NO se puede dejar un cubo", bodega1.puedeDejarCubo( 1, -1 ) );
    }
}