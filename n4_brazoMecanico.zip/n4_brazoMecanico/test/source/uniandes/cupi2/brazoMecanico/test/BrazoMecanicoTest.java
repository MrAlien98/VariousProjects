/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico
 * Autor: Mario S�nchez - 23/06/2005 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

package uniandes.cupi2.brazoMecanico.test;

import java.awt.*;

import junit.framework.*;
import uniandes.cupi2.brazoMecanico.mundo.*;

/**
 * Clase de prueba del brazo mec�nico
 */
public class BrazoMecanicoTest extends TestCase
{
    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Bodega del escenario 1
     */
    private Bodega bodega1;

    /**
     * Brazo Mec�nico del escenario 1
     */
    private BrazoMecanico brazo1;

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Prepara el escenario 1 <br>
     * <code>
     *   |       | 
     *   |  x    | 
     *   |  x x  |
     *   |x x x  |
     *    - - - - 
     * </code>
     */
    private void setupEscenario1( )
    {
        bodega1 = new Bodega( 4, 4 );

        Cubo c1 = new Cubo( Color.BLACK );
        Cubo c2 = new Cubo( Color.YELLOW );
        Cubo c3 = new Cubo( Color.RED );
        Cubo c4 = new Cubo( Color.BLUE );
        Cubo c5 = new Cubo( Color.GREEN );
        Cubo c6 = new Cubo( Color.CYAN );

        bodega1.agregarCubo( 0, 0, c1 );
        bodega1.agregarCubo( 1, 0, c2 );
        bodega1.agregarCubo( 1, 1, c3 );
        bodega1.agregarCubo( 1, 2, c4 );
        bodega1.agregarCubo( 2, 0, c5 );
        bodega1.agregarCubo( 2, 1, c6 );

        brazo1 = new BrazoMecanico( bodega1 );
    }

    /**
     * Verificar que cuando el brazo se construye est� en la esquina superior izquierda de la bodega y sin cargar un cubo
     */
    public void testPosicionBrazo( )
    {
        setupEscenario1( );

        assertEquals( "El brazo no est� en la esquina", brazo1.darPosX( ), 0 );
        assertEquals( "El brazo no est� en la esquina", brazo1.darPosY( ), bodega1.darMaxY( ) );
        assertTrue( "El brazo no deber�a estar cargando un cubo", !brazo1.tieneCubo( ) );
    }

    /**
     * Verifica el m�todo agarrarCubo
     */
    public void testAgarrarCubo( )
    {
        setupEscenario1( );

        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        try
        {
            brazo1.agarrarCubo( );
            assertTrue( "El brazo tom� un cubo pero no lo conserv�", brazo1.tieneCubo( ) );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
    }

    /**
     * Verifica el m�todo darCubo
     *  
     */
    public void testDarCubo( )
    {
        setupEscenario1( );

        assertTrue( "El brazo tiene un cubo desde que se crea", !brazo1.tieneCubo( ) );

        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        try
        {
            brazo1.agarrarCubo( );
            assertTrue( "El brazo tom� un cubo pero no lo conserv�", brazo1.tieneCubo( ) );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
    }

    /**
     * Verifica los m�todos darPosX y darPosY para conocer las coordenadas del brazo
     *  
     */
    public void testDarCoordenadas( )
    {
        setupEscenario1( );

        assertEquals( "La coordenada X inicial est� equivocada", 0, brazo1.darPosX( ) );
        assertEquals( "La coordenada Y inicial est� equivocada", bodega1.darMaxY( ), brazo1.darPosY( ) );
    }

    /**
     * Verifica el m�todo hayCubo()
     *  
     */
    public void testHayCubo1( )
    {
        setupEscenario1( );

        assertFalse( "En la posici�n actual del brazo no hay un cubo", brazo1.tieneCubo( ) );
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        assertTrue( "En la posici�n actual del brazo hay un cubo", !brazo1.tieneCubo( ) );
        try
        {
            brazo1.agarrarCubo( );
            assertTrue( "El brazo est� cargando un cubo", brazo1.tieneCubo( ) );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
    }

    /**
     * Verifica el m�todo hayCubo
     *  
     */
    public void testHayCubo2( )
    {
        setupEscenario1( );
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            assertFalse( "En la posici�n actual del brazo no hay un cubo", brazo1.detectarCubo( BrazoMecanico.ARRIBA ) );
            assertFalse( "En la posici�n actual del brazo no hay un cubo", brazo1.detectarCubo( BrazoMecanico.DERECHA ) );
            assertFalse( "En la posici�n actual del brazo no hay un cubo", brazo1.detectarCubo( BrazoMecanico.IZQUIERDA ) );
            assertTrue( "Debajo de la posici�n actual del brazo hay un cubo", brazo1.detectarCubo( BrazoMecanico.ABAJO ) );

            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
            assertTrue( "Debajo de la posici�n actual del brazo hay un cubo", brazo1.detectarCubo( BrazoMecanico.ABAJO ) );
            assertTrue( "A la izquierda de la posici�n actual del brazo hay un cubo", brazo1.detectarCubo( BrazoMecanico.IZQUIERDA ) );

            brazo1.mover( BrazoMecanico.ARRIBA );
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            brazo1.mover( BrazoMecanico.ABAJO );
            assertTrue( "A la derecha de la posici�n actual del brazo hay un cubo", brazo1.detectarCubo( BrazoMecanico.DERECHA ) );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
    }

    /**
     * Verificar el m�todo mover sin cargar cubo
     *  
     */
    public void testMover1( )
    {
        setupEscenario1( );

        try
        {
            brazo1.mover( BrazoMecanico.ARRIBA );
            fail( "No se puede mover hacia arriba desde esa posici�n porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {
        }
        try
        {
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            fail( "No se puede mover hacia la izquierda desde esa posici�n porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la derecha desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia abajo desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
            fail( "No se puede mover hacia abajo desde esa posici�n porque hay un cubo" );
        }
        catch( Exception e )
        {
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la derecha desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la derecha desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            fail( "No se puede mover hacia la derecha desde esa posici�n porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia abajo desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia abajo desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
            fail( "No se puede mover hacia abajo desde esa posici�n porque porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {
        }

        try
        {
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            fail( "No se puede mover hacia la izquierda desde esa posici�n porque no es el tope de una columna" );
        }
        catch( Exception e )
        {
        }
    }

    /**
     * Verificar el m�todo mover cargando un cubo
     *  
     */
    public void testMover2( )
    {
        setupEscenario1( );

        // Tomar un cubo
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El movimiento es v�lido" );
        }
        try
        {
            brazo1.agarrarCubo( );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ARRIBA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia arriba desde esa posici�n" );

        }
        try
        {
            brazo1.mover( BrazoMecanico.IZQUIERDA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la izquierda desde esa posici�n " );

        }
        try
        {
            brazo1.mover( BrazoMecanico.ARRIBA );
            fail( "No se puede mover hacia arriba desde esa posici�n porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {

        }
        try
        {
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            fail( "No se puede mover hacia la izquierda desde esa posici�n porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {

        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la derecha desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );

        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia abajo desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
            fail( "No se puede mover hacia abajo desde esa posici�n porque hay un cubo y tambi�n est� cargando uno" );
        }
        catch( Exception e )
        {

        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la derecha desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia la derecha desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            fail( "No se puede mover hacia la derecha desde esa posici�n porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {

        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia abajo desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia abajo desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.ABAJO );
            fail( "No se puede mover hacia abajo desde esa posici�n porque porque se saldr�a del mundo" );
        }
        catch( Exception e )
        {

        }
        try
        {
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            fail( "No se puede mover hacia la izquierda desde esa posici�n porque porque no es el tope de una columna" );
        }
        catch( Exception e )
        {

        }
        try
        {
            brazo1.mover( BrazoMecanico.ARRIBA );

        }
        catch( Exception e )
        {
            fail( "Se puede mover hacia arriba desde esa posici�n" );
        }
        try
        {
            brazo1.mover( BrazoMecanico.IZQUIERDA );
            fail( "No se puede mover hacia la izquierda desde esa posici�n porque es el tope de una columna y est� cargando un cubo" );
        }
        catch( Exception e )
        {

        }
    }

    /**
     * Verificar el m�todo reiniciar
     */
    public void testReiniciar( )
    {
        setupEscenario1( );

        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        try
        {
            brazo1.agarrarCubo( );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
        brazo1.reiniciar( );
        assertEquals( "El brazo no est� en la esquina", brazo1.darPosX( ), 0 );
        assertEquals( "El brazo no est� en la esquina", brazo1.darPosY( ), bodega1.darMaxY( ) );
        assertTrue( "El brazo no deber�a estar cargando un cubo", !brazo1.tieneCubo( ) );
    }

    /**
     * Sirve para verificar el m�todo soltarCubo
     *  
     */
    public void testSoltarCubo( )
    {
        setupEscenario1( );

        try
        {
            brazo1.soltarCubo( );
            fail( "El brazo no puede soltar un cubo que no est� cargando" );
        }
        catch( Exception e )
        {

        }

        try
        {

            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        try
        {
            brazo1.agarrarCubo( );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
        try
        {
            brazo1.soltarCubo( );

        }
        catch( Exception e )
        {
            fail( "En la posici�n actual se puede soltar el cubo" );
        }
        try
        {
            brazo1.agarrarCubo( );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.DERECHA );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        try
        {
            brazo1.soltarCubo( );
            fail( "En la posici�n actual no se puede soltar el cubo" );
        }
        catch( Exception e )
        {

        }
    }

    /**
     * Verificar el m�todo tieneCubo
     *  
     */
    public void testTieneCubo( )
    {
        setupEscenario1( );

        assertFalse( "El brazo no debe decir que est� cargando un cubo", brazo1.tieneCubo( ) );

        try
        {
            brazo1.mover( BrazoMecanico.DERECHA );
            brazo1.mover( BrazoMecanico.ABAJO );
        }
        catch( Exception e )
        {
            fail( "El brazo deber�a poderse mover en la direcci�n especificada" );
        }
        try
        {
            brazo1.agarrarCubo( );
        }
        catch( Exception e )
        {
            fail( "El brazo no puede recoger el cubo." );
        }
        assertTrue( "El brazo debe decir que est� cargando un cubo", brazo1.tieneCubo( ) );
    }
}
