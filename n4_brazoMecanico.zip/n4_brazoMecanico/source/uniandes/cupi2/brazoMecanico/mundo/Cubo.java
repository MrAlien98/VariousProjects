/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico 
 * Autor: Mario S�nchez - 22/06/2005
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.brazoMecanico.mundo;

import java.awt.*;

/**
 * Esta clase representa un cubo que se encuentra dentro de la bodega
 */
public class Cubo
{
    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Es el color del cubo
     */
    private Color color;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Construye un nuevo cubo con un color espec�fico
     * @param miColor - Color del cubo - miColor != null
     */
    public Cubo( Color miColor )
    {
        color = miColor;
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Este m�todo retorna el color del cubo
     * @return color
     */
    public Color darColor( )
    {
        return color;
    }
}
