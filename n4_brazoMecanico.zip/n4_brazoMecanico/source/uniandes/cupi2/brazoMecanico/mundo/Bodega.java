/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico 
 * Autor: Mario S�nchez - 22/06/2005
 * Autor: Pablo Barvo - 29-Ago-2005
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.brazoMecanico.mundo;

import java.awt.*;
import java.io.*;
import java.util.*;

/**
 * Esta clase representa una bodega en la cual hay un brazo mec�nico y cubos organizados en pilas.
 */
public class Bodega extends Observable
{
    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Indica si la bodega ya ha sido iniciada con un tama�o y un conjunto de cubos
     */
    private boolean iniciado = false;

    /**
     * Coordenada m�xima X de la bodega
     */
    private int maxX;

    /**
     * Coordenada m�xima Y de la bodega
     */
    private int maxY;

    /**
     * Es la colecci�n de las columnas de la bodega
     */
    private ArrayList columnas;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Constructor por defecto
     */
    public Bodega( )
    {
        iniciado = false;
    }

    /**
     * Construye una nueva bodega con las medidas indicadas
     * @param x - El ancho de la bodega - x > 0
     * @param y - La altura de la bodega - y > 0
     */
    public Bodega( int x, int y )
    {
        maxX = x;
        maxY = y;
        columnas = new ArrayList( );
        for( int i = 0; i < maxX; i++ )
            columnas.add( nuevaPila( ) );
        iniciado = true;
    }

    /**
     * Crea y retorna una pila de cubos vac�a
     * @return un vector vac�o que representa una pila de cubos
     */
    private ArrayList nuevaPila( )
    {
        return new ArrayList( );
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Sirve para saber cu�l es la coordenada m�xima en X
     * @return Coordenada m�xima en X
     */
    public int darMaxX( )
    {
        return maxX - 1;
    }

    /**
     * Sirve para saber cu�l es la coordenada m�xima en Y
     * @return Coordenada m�xima en Y
     */
    public int darMaxY( )
    {
        return maxY - 1;
    }

    /**
     * Valida una posici�n en el mundo
     * @param x X a validar
     * @param y Y a validar
     * @return true si es v�lida, false si no
     */
    private boolean posicionValida( int x, int y )
    {
        return ( x >= 0 ) && ( x < maxX ) && ( y >= 0 ) && ( y < maxY );
    }

    /**
     * Este m�todo sirve para saber cu�l es el contenido de una posici�n particular de la bodega.
     * @param x - Es la coordenada X del punto. La posici�n es v�lida
     * @param y - Es la coordenada Y del punto. La posici�n es v�lida
     * @return Retorna el cubo que se encuentra en la posici�n indicada. Si la posici�n est� vac�a retorna null.
     */
    public Cubo darCubo( int x, int y )
    {
        Cubo cubo = null;
        // Recupera la pila n�mero x de la bodega
        ArrayList columna = ( ArrayList )columnas.get( x );
        if( columna.size( ) > y )
        {
            // Recupera de la pila x el cubo y
            cubo = ( Cubo )columna.get( y );
        }
        return cubo;
    }

    /**
     * Este m�todo sirve para recoger un cubo en la posici�n dada.
     * @param x - Es la coordenada X del punto. La posici�n es v�lida
     * @param y - Es la coordenada Y del punto. La posici�n es v�lida
     * @return Retorna el cubo que se encuentra en la posici�n indicada. Si la posici�n est� vac�a retorna null.
     * @exception Exception Error al recoger el cubo.
     */
    public Cubo recogerCubo( int x, int y ) throws Exception
    {
        Cubo cubo = null;
        // Recupera la pila n�mero x de la bodega
        ArrayList columna = ( ArrayList )columnas.get( x );
        if( y >= columna.size( ) )
        {
            throw new Exception( "No hay cubo en la posici�n" );
        }
        // Remueve el y-�simo cubo en la columna
        cubo = ( Cubo )columna.remove( y );
        return cubo;
    }

    /**
     * Este m�todo sirve para saber si la bodega ya est� iniciada
     * @return Retorna true si la bodega ya est� iniciada (tiene l�mites y cubos cargados). Retorna false en caso contrario.
     */
    public boolean darIniciado( )
    {
        return iniciado;
    }

    /**
     * Este m�todo se encarga de inicializar el mundo a partir de la informaci�n que se encuentra en un archivo. <br>
     * <b>post: </b>Se inicializ� la bodega con la informaci�n del archivo
     * @param archivo - Es el descriptor del archivo que contiene la descripci�n de la bodega - archivo es un archivo v�lido
     * @throws Exception Cuando ocurre un error
     */
    public void cargarMundo( File archivo ) throws Exception
    {
        // Abrir el archivo
        BufferedReader br = abrirArchivo( archivo );

        // Inicializar la bodega
        String strMaxX = br.readLine( ); // Leer el tama�o X
        String strMaxY = br.readLine( ); // Leer el tama�o Y
        maxX = Integer.parseInt( strMaxX );
        maxY = Integer.parseInt( strMaxY );
        columnas = new ArrayList( );
        for( int i = 0; i < maxX; i++ )
            columnas.add( nuevaPila( ) );

        // Cargar los colores
        Map colores = new HashMap( ); // El mapa donde se van a guardar los colores
        cargarColores( colores, br );

        // Cargar los cubos
        cargarCubos( colores, br );
        iniciado = true;
        setChanged( );
        notifyObservers( );
    }

    /**
     * Este m�todo sirve para abrir el archivo y retornar un objeto que sirve para leer el contenido del archivo.
     * @param archivo - Es el descriptor del archivo que contiene la descripci�n de la bodega.
     * @return Retorna un BufferedReader para leer el archivo indicado.
     * @throws FileNotFoundException
     */
    private BufferedReader abrirArchivo( File archivo ) throws FileNotFoundException
    {
        return new BufferedReader( new FileReader( archivo ) );
    }

    /**
     * Este m�todo sirve para cargar los colores que est�n en el archivo de configuraci�n y dejarlos todos en el mapa "colores". <br>
     * En este mapa se encuentran las parejas <nombre_del_color , color>. <br>
     * "nombre_del_color" ser�a la llave, lo que se utiliza para buscar el "color", que es el valor.
     * @param colores - Es el mapa donde se dejar�n los colores - colores!=null
     * @param br - Es el BufferedReader que se usa para leer el archivo
     * @throws IOException
     */
    private void cargarColores( Map colores, BufferedReader br ) throws IOException
    {
        String strNumColores = br.readLine( ); // Leer el n�mero de colores
        int numColores = Integer.parseInt( strNumColores ); // Convertir el String a int
        for( int i = 0; i < numColores; i++ )
        {
            String linea = br.readLine( );
            StringTokenizer st = new StringTokenizer( linea, " " ); // Partir la cadena usando " "

            String nombreColor = st.nextToken( ); // Saco el nombre del color
            String strRojo = st.nextToken( ); // Saco el componente rojo del color
            String strVerde = st.nextToken( ); // Saco el componente verde del color
            String strAzul = st.nextToken( ); // Saco el componente azul del color

            Color color = new Color( Integer.parseInt( strRojo ), Integer.parseInt( strVerde ), Integer.parseInt( strAzul ) );
            colores.put( nombreColor, color );
        }
    }

    /**
     * Este m�todo sirve para cargar los cubos a partir del archivo de definici�n de la bodega. <br>
     * <b>post: </b>Se cargaron los cubos que se especificaban en el archivo
     * @param colores - Es el mapa que contiene los colores
     * @param br - Este objeto permite leer el archivo de definiciones l�nea por l�nea.
     * @return Retorna true si no hubo ning�n problema cargando los cubos. Retorna false en caso contrario.
     * @throws Exception Cuando ocurre un error
     */
    private boolean cargarCubos( Map colores, BufferedReader br ) throws Exception
    {
        boolean pudoAgregarCubo = true;
        String strNumCubos = br.readLine( ); // Leer el n�mero de cubos
        int numTotalColumnasConCubos = Integer.parseInt( strNumCubos ); // Convertir el String en int
        for( int i = 0; i < numTotalColumnasConCubos && pudoAgregarCubo; i++ )
        {
            String linea = br.readLine( );
            StringTokenizer st = new StringTokenizer( linea, " " ); // Partir la cadena usando " "
            String strNumColumna = st.nextToken( );
            int numColumna = Integer.parseInt( strNumColumna );

            int numPila = -1;
            while( st.hasMoreTokens( ) )
            {
                numPila++;
                if( !posicionValida( numColumna, numPila ) )
                    throw new Exception( "Posici�n de la bodega inv�lida" );
                String nombreColor = st.nextToken( );
                Color colorCubo = ( Color )colores.get( nombreColor ); // Saco el color usando el nombre
                Cubo cubo = new Cubo( colorCubo ); // Crea el nuevo cubo con el color obtenido
                agregarCubo( numColumna, numPila, cubo ); // Agrega el cubo en la columna
            }
        }
        return pudoAgregarCubo;
    }

    /**
     * Este m�todo sirve para agregar un cubo a la columna indicada (posX). <br>
     * <b>pre: </b>La columna x tiene menos de maxY cubos en este momento <br>
     * <b>post: </b>Se agreg� el cubo a la columna indicada
     * @param x - Es la coordenada x de la columna donde se va a agregar el cubo - La posici�n es v�lida.
     * @param y - Es la coordenada y de la pila donde se va a agregar un cubo La posici�n es v�lida.
     * @param cubo - Es el cubo que se va a poner en la columna - cubo != null
     */
    public void agregarCubo( int x, int y, Cubo cubo )
    {
        ArrayList columna = ( ArrayList )columnas.get( x ); // Buscar la columna x
        columna.add( y, cubo );
    }

    /**
     * Este m�todo sirve para saber si en una posici�n dada hay un cubo
     * @param x - La coordenada x del punto. La posici�n es v�lida
     * @param y - La coordenada y del punto. La posici�n es v�lida
     * @return Retorna true si en la posici�n indicada hay un cubo. Retorna false en caso contrario.
     */
    public boolean hayCubo( int x, int y )
    {
        if( x < 0 || x > darMaxX( ) )
        {
            return false;
        }
        else if( y < 0 || y > darMaxY( ) )
        {
            return false;
        }
        else
        {
            ArrayList columna = ( ArrayList )columnas.get( x ); // Buscar la columna x
            return ( columna.size( ) > y );
        }
    }

    /**
     * Sirve para saber si en la posici�n dada se puede depositar el cubo. Esto es posible solamente si el punto est� vac�o y est� justo encima de una pila o del piso.
     * @param x - La coordenada x del punto. La posici�n es v�lida
     * @param y - La coordenada y del punto. La posici�n es v�lida
     * @return Retorna true si la posici�n est� vac�a dentro de la bodega y est� justo encima de un cubo o del piso. Retorna false en caso contrario.
     */
    public boolean puedeDejarCubo( int x, int y )
    {
        if( hayCubo( x, y ) )
            return false;
        else if( y == 0 )
            return true;
        else if( hayCubo( x, y - 1 ) )
            return true;
        else
            return false;
    }

    /**
     * Este m�todo sirve para dejar un cubo en una posici�n del mundo. Un cubo se puede dejar solamente en el tope de una pila o sobre el piso. <br>
     * <b>pre: </b>!hayCubo(x,y) <br>
     * <b>post: </b>El brazo dej� el cubo en la posici�n indicada
     * @param x - La coordenada x del punto - 0 <x <=maxX
     * @param y - La coordenada y del punto - y <maxY y (x,y) est� una posici�n por encima del tope de una columna o del piso
     * @param cubo - Es el cubo que se va a dejar - cubo!=null
     * @throws Exception Se lanza esta excepci�n en caso de que no se pudiera dejar el cubo en la posici�n indicada.
     */
    public void dejarCubo( int x, int y, Cubo cubo ) throws Exception
    {
        boolean puede = puedeDejarCubo( x, y );
        if( puede )
        {
            ArrayList columna = ( ArrayList )columnas.get( x ); // Buscar la columna x
            columna.add( y, cubo ); // Dejar el cubo en el tope
            setChanged( );
        }
        else
        {
            throw new Exception( "En la posici�n actual no es posible dejar el cubo" );
        }
    }

    /**
     * Dada una columna indica cual es la fila donde est� el �ltimo cubo o tope de la columna. si la columna est� vac�a (sin cubos) retorna cero
     * @param columna - La columna de la que se quiere saber el tope - 0 < columna <= maxX
     * @return numero de la fila en la que est� el �ltimo cubo, 0 si no hay cubos
     */
    public int darFilaTopeColumna( int columna )
    {
        // Averigua cu�l es el tope de la columna
        int tope = maxY - 1;
        boolean buscandoTope = true;
        while( buscandoTope )
        {
            if( hayCubo( columna, tope ) )
            {
                buscandoTope = false;
                tope++;
            }
            else if( tope == 0 )
                buscandoTope = false;
            else
                tope--;
        }
        return tope;
    }
}