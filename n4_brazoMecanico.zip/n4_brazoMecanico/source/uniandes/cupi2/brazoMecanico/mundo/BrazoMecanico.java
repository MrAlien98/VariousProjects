/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico 
 * Autor: Mario S�nchez - 22/06/2005
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */
package uniandes.cupi2.brazoMecanico.mundo;

import java.util.*;

/**
 * Esta clase representa un brazo mec�nico que se encuentra en una bodega y puede mover los cubos que se encuentran apilados dentro de ella
 */
public class BrazoMecanico extends Observable
{
    //-----------------------------------------------------------------
    // Constantes
    //-----------------------------------------------------------------

    /**
     * Direcci�n Arriba
     */
    public static final int ARRIBA = 1;

    /**
     * Direcci�n Abajo
     */
    public static final int ABAJO = 2;

    /**
     * Direcci�n Izquierda
     */
    public static final int IZQUIERDA = 3;

    /**
     * Direcci�n Derecha
     */
    public static final int DERECHA = 4;

    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Es la posici�n en x donde est� el brazo
     */
    private int posX;

    /**
     * Es la posici�n en y donde est� el brazo
     */
    private int posY;

    /**
     * Es el cubo que est� cargando el brazo mec�nico en un momento dado
     */
    private Cubo cuboCargado;

    /**
     * Es la bodega en la cual se encuentra el brazo mec�nico
     */
    private Bodega bodega;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Este es el constructor del Brazo Mec�nico. <br>
     * Inicializa el robot en la esquina superior izquierda de la bodega, es decir en la coordenada X m�nima y Y m�xima. <br>
     * <b>post: </b> posX= 1 y posY = bodega.darMaxY()
     * @param miBodega - Es la bodega dentro de la que se encuentra el robot - miBodega!=null
     */
    public BrazoMecanico( Bodega miBodega )
    {
        bodega = miBodega;
        posX = 0; // Est� al lado izquierdo
        posY = bodega.darMaxY( ); // Est� arriba
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Retorna la coordenada X del Brazo Mec�nico
     * @return coordenada X del Brazo Mec�nico
     */
    public int darPosX( )
    {
        return posX;
    }

    /**
     * Retorna la coordenada Y del Brazo Mec�nico
     * @return coordenada Y del Brazo Mec�nico
     */
    public int darPosY( )
    {
        return posY;
    }

    /**
     * Retorna el cubo que lleva cargado o null si no lleva ninguno
     * @return El cubo que lleva agarrado o null si no lleva ning�n cubo
     */
    public Cubo darCuboCargado( )
    {
        return cuboCargado;
    }

    /**
     * Este m�todo ubica nuevamente al brazo mec�nico en la esquina superior izquierda de la bodega. Si estaba cargando alg�n cubo este desaparece del mundo. <br>
     * <b>post: </b> posX= 1 y posY = bodega.darMaxY() y cuboCargado=null
     */
    public void reiniciar( )
    {
        posX = 0; // Est� al lado izquierdo
        posY = bodega.darMaxY( ); // Est� arriba
        cuboCargado = null;
    }

    /**
     * Sirve para saber si el brazo mec�nico est� cargando un cubo.
     * @return Retorna true si el brazo est� cargando un cubo; retorna false en caso contrario.
     */
    public boolean tieneCubo( )
    {
        return cuboCargado != null;
    }

    /**
     * Mueve el brazo mec�nico en una direcci�n determinada (ARRIBA, ABAJO, IZQUIERDA o DERECHA). <br>
     * El brazo solamente puede llegar a una posici�n donde haya un cubo si no est� cargando un cubo. <br>
     * Si el brazo est� cargando un cubo, entonces no puede llegar a ninguna posici�n que ya tenga un cubo. <br>
     * El brazo solamente puede entrar a una posici�n que tiene un cubo si este cubo se encuentra en el tope de una columna. <br>
     * <b>post: </b>Si era posible el movimiento, el robot se movi� en la direcci�n indicada </b>
     * @param direccion - La direcci�n en la que se va a mover el brazo mec�nico - direccion pertenece a {ARRIBA, ABAJO, IZQUIERDA, DERECHA}
     * @throws Exception Se lanza esta excepci�n si el brazo llega a una posici�n inv�lida si realiza el movimiento
     */
    public void mover( int direccion ) throws Exception
    {
        boolean puede = false;
        int deltaX = 0;
        int deltaY = 0;
        switch( direccion )
        {
            case ARRIBA:
                deltaY = 1;
                puede = puedeMoverseArriba( );
                break;
            case ABAJO:
                deltaY = -1;
                puede = puedeMoverseAbajo( );
                break;
            case DERECHA:
                deltaX = 1;
                puede = puedeMoverseDerecha( );
                break;
            case IZQUIERDA:
                deltaX = -1;
                puede = puedeMoverseIzquierda( );
                break;
        }
        if( puede )
        {
            posX += deltaX;
            posY += deltaY;

            // Notificar a los observadores
            setChanged( );
            notifyObservers( );
        }
        else
        {
            throw new Exception( "El movimiento no se puede realizar" );
        }
    }

    /**
     * Este m�todo sirve para saber si el brazo puede moverse hacia arriba desde la posici�n actual. <br>
     * El �nico motivo por el cual el brazo no podr�a moverse hacia arriba desde una posici�n v�lida es que el brazo se encontrara en el l�mite superior de la bodega.
     * @return Retorna true si el brazo puede moverse hacia arriba; retorna false en caso contrario
     */
    private boolean puedeMoverseArriba( )
    {
        boolean puede = true;
        if( ( bodega.darMaxY( ) ) == posY )
            puede = false;
        return puede;
    }

    /**
     * Este m�todo sirve para saber si el brazo puede moverse en una direcci�n dada.
     * @param direccion Direcci�n a la cual se quiere mover.
     * @return Retorna true si el brazo puede moverse en la direcci�n dada. En caso contrario devuelve false.
     */
    public boolean puedeMoverse( int direccion )
    {
        boolean puede = false;
        switch( direccion )
        {
            case ARRIBA:
                puede = puedeMoverseArriba( );
                break;
            case ABAJO:
                puede = puedeMoverseAbajo( );
                break;
            case DERECHA:
                puede = puedeMoverseDerecha( );
                break;
            case IZQUIERDA:
                puede = puedeMoverseIzquierda( );
                break;
        }
        return puede;
    }

    /**
     * Este m�todo sirve para saber si el brazo puede moverse hacia abajo desde la posici�n actual. El brazo no podr�a moverse hacia abajo si:
     * <ul>
     * <li>Se encuentra sobre el piso de la bodega</li>
     * <li>Est� en el tope de una pila</li>
     * <li>Est� una posici�n por encima del tope de una pila y est� cargando un cubo</li>
     * </ul>
     * @return Retorna true si el brazo puede moverse hacia abajo; retorna false en caso contrario
     */
    private boolean puedeMoverseAbajo( )
    {
        boolean puede = true;
        if( 0 == posY ) // Est� en el piso
            puede = false;
        else if( bodega.hayCubo( posX, posY ) )
            // Est� en el tope
            puede = false;
        else if( tieneCubo( ) && bodega.hayCubo( posX, posY - 1 ) )
            // Est� sobre un cubo y est� cargando uno
            puede = false;
        return puede;
    }

    /**
     * Este m�todo sirve para saber si el brazo puede moverse hacia la derecha desde la posici�n actual. El brazo no podr�a moverse hacia la derecha si:
     * <ul>
     * <li>Se encuentra en el borde derecho de la bodega</li>
     * <li>Est� a la izquierda de una columna pero est� m�s abajo del tope de la pila</li>
     * <li>Est� una posici�n a la izquierda del tope de una pila pero est� cargando un cubo</li>
     * </ul>
     * @return Retorna true si el brazo puede moverse hacia la derecha; retorna false en caso contrario
     */
    private boolean puedeMoverseDerecha( )
    {
        boolean puede = true;
        if( ( bodega.darMaxX( ) ) == posX ) // Est� en el borde derecho
            puede = false;
        else if( tieneCubo( ) )
        {
            if( bodega.hayCubo( posX + 1, posY ) )
                puede = false;
        }
        else
        {
            if( bodega.hayCubo( posX + 1, posY + 1 ) )
                puede = false;
        }
        return puede;
    }

    /**
     * Este m�todo sirve para saber si el brazo puede moverse hacia la izquierda desde la posici�n actual. El brazo no podr�a moverse hacia la izquierda si:
     * <ul>
     * <li>Se encuentra en el borde izquierdo de la bodega</li>
     * <li>Est� a la derecha de una columna pero est� m�s abajo del tope de la pila</li>
     * <li>Est� una posici�n a la derecha del tope de una pila pero est� cargando un cubo</li>
     * </ul>
     * @return Retorna true si el brazo puede moverse hacia la izquierda; retorna false en caso contrario
     */
    private boolean puedeMoverseIzquierda( )
    {
        boolean puede = true;
        if( 0 == posX ) // Est� en el borde izquierdo
            puede = false;
        else if( tieneCubo( ) )
        {
            if( bodega.hayCubo( posX - 1, posY ) )
                puede = false;
        }
        else
        {
            if( bodega.hayCubo( posX - 1, posY + 1 ) )
                puede = false;
        }
        return puede;
    }

    /**
     * El brazo mec�nico agarra el cubo que est� en la misma posici�n donde se encuentra el brazo. <br>
     * Como el brazo no puede entrar cargando un cubo a una posici�n donde hay otro, entonces la condici�n de que el brazo solamente puede cargar un cubo a la vez debe ser
     * forzosamente v�lida. <br>
     * <b>pre: </b>cuboCargado = null <br>
     * <b>post: </b>Si en la posici�n del brazo hab�a un cubo entonces cuboCargado!=null
     * @throws Exception Error al recoger el cubo.
     */
    public void agarrarCubo( ) throws Exception
    {
        cuboCargado = bodega.recogerCubo( posX, posY );
        if( cuboCargado != null )
        {
            // Notificar a los observadores
            setChanged( );
            notifyObservers( );
        }
    }

    /**
     * El brazo mec�nico suelta un cubo que est� cargando y lo deja sobre el piso de la bodega o en la cima de una pila de cubos. <br>
     * Por las condiciones sobre el movimiento del brazo no es posible que en la posici�n donde est� el brazo ya haya un cubo. <br>
     * El brazo NO puede dejar caer los cubos, debe ponerlos sobre el piso o sobre otro cubo. <br>
     * <b>pre: </b>cuboCargado !=null <br>
     * <b>post: </b>cuboCargado == null y hayCubo(posX, posY) = true
     * @throws Exception Se lanza est� excepci�n si no se pudo dejar el cubo porque desde la posici�n actual no se puede
     */
    public void soltarCubo( ) throws Exception
    {
        bodega.dejarCubo( posX, posY, cuboCargado );
        cuboCargado = null;
        // Notificar a los observadores
        setChanged( );
        notifyObservers( );
    }

    /**
     * Este m�todo sirve para saber si en una posici�n espec�fica respecto a la posici�n actual del brazo los sensores detectan que hay un cubo. <br>
     * Por ejemplo, si hay solamente un cubo en la posici�n (1,1) y el robot est� en (2,1), entonces <code>hayCubo(IZQUIERDA)==true</code> y
     * <code>hayCubo(DERECHA)==false</code>.
     * @param direccion - La direcci�n donde se quiere saber si hay un cubo - direccion pertenece a (ARRIBA, ABAJO, IZQUIERDA, DERECHA).
     * @return Retorna true si en a partir de la posici�n del brazo hay un cubo en la direcci�n indicada. Retorna false en caso contrario.
     */
    public boolean detectarCubo( int direccion )
    {
        int deltaX = 0;
        int deltaY = 0;
        switch( direccion )
        {
            case ARRIBA:
                deltaY = 1;
                break;
            case ABAJO:
                deltaY = -1;
                break;
            case DERECHA:
                deltaX = 1;
                break;
            case IZQUIERDA:
                deltaX = -1;
                break;
        }
        return bodega.hayCubo( posX + deltaX, posY + deltaY );
    }

    //-----------------------------------------------------------------
    // Soluci�n al reto #1 del libro
    //-----------------------------------------------------------------

    /**
     * Este m�todo sirve para que el brazo mec�nico localice el �nico cubo que hay en la bodega y lo lleva a la posici�n de origen (coordenadas 0, 0). <br>
     * <b>post: </b> El brazo est� en la posici�n de origen, al igual que el �nico cubo de la bodega. El brazo no est� sujetando el cubo
     * @throws Exception Lanza una excepci�n si el robot se choca en cualquier momento mientras trata de resolver el problema, debido a que el estado de la bodega no
     *         corresponde al enunciado.
     * @throws Exception Lanza una excepci�n si encuentra alg�n obst�culo para agarrar el cubo (por ejemplo, un segundo cubo sobre �l).
     */
    public void solucionReto1( ) throws Exception
    {
        bajarARecoger( );
        encontrarUnicoCubo( );
        volverAPosicion0( );
    }

    /**
     * Este m�todo logra la primera meta del reto 1: bajar desde la posici�n de origen hasta el piso
     * @throws Exception Si el brazo choca tratando de bajar al piso de la bodega
     */
    private void bajarARecoger( ) throws Exception
    {
        for( int i = 0; i < bodega.darMaxY( ); i++ )
        {
            mover( ABAJO );
        }
    }

    /**
     * Este m�todo logra la segunda meta del reto 1: buscar y agarrar el �nico cubo que hay en el mundo. <br>
     * <b>pre: </b> El brazo est� en la posici�n 0,0 de la bodega. <br>
     * <b>post: </b> El brazo est� en la posici�n donde se encuentra el cubo y lo est� agarrando. <br>
     * @throws Exception Si no encontr� un cubo o si el brazo se estrell� contra una pila de cubos, dispara una excepci�n y detiene el brazo
     */
    private void encontrarUnicoCubo( ) throws Exception
    {
        boolean encontro = false;
        Cubo cubo = null;
        for( int i = 0; i <= bodega.darMaxX( ) && !encontro; i++ )
        {
            cubo = bodega.darCubo( i, 0 );
            if( cubo != null )
            {
                encontro = true;
            }
            else if( i < bodega.darMaxX( ) )
            {
                try
                {
                    mover( DERECHA );
                }
                catch( Exception e )
                {
                    throw new Exception( "Hay una pila de cubos" );
                }
            }
        }
        if( encontro )
            agarrarCubo( );
        else
            throw new Exception( "No hay ning�n cubo" );
    }

    /**
     * Este m�todo logra la tercera meta del reto 1: Llevar el cubo que lleva agarrado a la posici�n 0, 0.<br>
     * <b>pre: </b> El brazo est� agarrando un cubo y se encuentra a nivel del piso. Entre el punto en el que est� el brazo y el origen de la bodega (coordenadas 0,0) no hay
     * ning�n cubo. <br>
     * <b>post: </b> El brazo est� en la posici�n 0, 0, el �nico cubo de la bodega est� en la posici�n 0, 0 de la bodega, el brazo no est� sosteniendo el cubo.
     */
    private void volverAPosicion0( )
    {
        try
        {
            for( int i = posX; i > 0; i-- )
            {
                mover( IZQUIERDA );
            }
            soltarCubo( );
        }
        catch( Exception e )
        {
            // No debe hacer nada, porque nunca debe ocurrir
            // esta excepci�n
        }
    }

    //-----------------------------------------------------------------
    // Esqueleto de soluci�n al reto #2 del libro
    //-----------------------------------------------------------------

    /**
     * Este m�todo permite apilar los cubos que hay en la bodega en las primeras columnas de la misma
     * @throws Exception
     */
    public void solucionReto2( ) throws Exception
    {
        boolean hayCubosPorApilar = true;
        int i = 0;
        while( i < bodega.darMaxX( ) && hayCubosPorApilar )
        {
            hayCubosPorApilar = apileEnColumna( i );
            i++;
        }
    }

    /**
     * @param col es el n�mero de la columna en la bodega donde se van a apilar los cubos. col es una columna v�lida.
     * @return verdadero si a�n quedan cubos en la bodega para apilar, falso en caso contrario
     * @throws Exception No realiza ning�n disparo de excepci�n expl�citamente pero utiliza m�todos que s� pueden hacerlo. Delega en su invocador el manejo de la excepci�n.
     */
    private boolean apileEnColumna( int col ) throws Exception
    {
        // M�todo por desarrollar
        return false;
    }

    //-----------------------------------------------------------------
    // Puntos de Extensi�n
    //-----------------------------------------------------------------

    /**
     * Extensi�n 1
     * @throws Exception Lanza una excepci�n si la bodega no cumple con la descripci�n de enunciado
     */
    public void metodo1( ) throws Exception
    {
        solucionReto1( );
    }

    /**
     * Extensi�n 2
     * @throws Exception Lanza una excepci�n si la bodega no cumple con la descripci�n de enunciado
     */
    public void metodo2( ) throws Exception
    {
        solucionReto2( );
    }
}