/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico 
 * Autor: Mario S�nchez - 22/06/2005
 * Autor: Pablo Barvo - 29-Ago-2005
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

package uniandes.cupi2.brazoMecanico.interfaz;

import java.awt.*;
import java.util.*;

import javax.swing.*;

import uniandes.cupi2.brazoMecanico.mundo.*;

/**
 * Este panel sabe c�mo dibujar la bodega, los cubos y el brazo mec�nico. <br>
 * Esta clase es un observador de la bodega y del brazo mec�nico, es decir que cuando hay alg�n cambio en el mundo esta clase es notificada y se llama el respectivo m�todo
 */
public class PanelBodega extends JPanel implements Observer
{
    //-----------------------------------------------------------------
    // Constantes
    //-----------------------------------------------------------------

    /**
     * El color de las l�neas
     */
    private final static Color COLOR_LINEAS = Color.YELLOW;

    /**
     * El color del fondo del tablero
     */
    private final static Color COLOR_TABLERO = Color.LIGHT_GRAY;

    /**
     * El color del brazo
     */
    private final static Color COLOR_BRAZO = Color.BLACK;

    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------
    /**
     * Brazo mec�nico
     */
    private BrazoMecanico brazo;

    /**
     * Bodega
     */
    private Bodega bodega;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Crea el panel con la bodega y el brazo
     * @param elBrazo - El brazo mec�nico - elBrazo != null
     * @param laBodega - La bodega dentro de la que est� el brazo - laBodega!=null
     */
    public PanelBodega( BrazoMecanico elBrazo, Bodega laBodega )
    {
        brazo = elBrazo;
        brazo.addObserver( this );
        bodega = laBodega;
        bodega.addObserver( this );
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Este es el m�todo que se llama cuando hay un cambio en el mundo. Cuando esto sucede entonces este panel se encarga de actualizar la representaci�n del mundo.
     * @param obs - Es el objeto observado que cambi�
     * @param params - Son par�metros con informaci�n sobre el cambio
     */
    public void update( Observable obs, Object params )
    {
        repaint( );
    }

    /**
     * Este es el m�todo que dibuja el estado actual de la bodega.
     * @param g - La superficie del panel sobre la que se dibuja - g!=null
     * @throws Exception Cuando ocurre un error
     */
    public void actualizarPanel( Graphics g ) throws Exception
    {
        if( bodega.darIniciado( ) ) // Si la bodega no est� iniciada no se pinta
        {
            limpiar( g );
            dibujarBodega( g );
            dibujarCubos( g );

            if( brazo.tieneCubo( ) )
                dibujarBrazoConCubo( g );
            else
                dibujarBrazoSinCubo( g );

            // No se quieren movimientos demasiado r�pidos del brazo as� que se detiene un momento la ejecuci�n
            try
            {
                Thread.sleep( 100 );
            }
            catch( InterruptedException e )
            {
                e.printStackTrace( );
            }
        }
    }

    /**
     * Dibuja la cuadr�cula de la bodega
     * @param g - La superficie del panel sobre la que se dibuja - g!=null
     */
    private void dibujarBodega( Graphics g )
    {
        int maxX = bodega.darMaxX( ) + 1;
        int maxY = bodega.darMaxY( ) + 1;
        int alturaTablero = getHeight( );
        int anchoTablero = getWidth( );

        // Calcular el ancho de cada casilla
        int alturaCasilla = alturaTablero / ( maxY + 1 );
        int anchoCasilla = anchoTablero / ( maxX + 1 );

        g.setColor( PanelBodega.COLOR_LINEAS );
        // Dibujar las l�neas horizontales
        for( int i = 1; i <= maxY; i++ )
        {
            int posY = i * alturaCasilla;
            g.drawLine( 0, posY, anchoTablero, posY );
        }

        // Dibujar las l�neas verticales
        for( int i = 0; i < maxX; i++ )
        {
            int posX = ( i + 1 ) * anchoCasilla;
            g.drawLine( posX, 0, posX, alturaTablero );
        }
        g.setColor( PanelBodega.COLOR_TABLERO );
        g.fillRect( 0, alturaTablero - alturaCasilla / 2, anchoTablero, alturaCasilla / 2 );
        g.setColor( Color.BLACK );
        g.drawRect( 0, alturaTablero - alturaCasilla / 2, anchoTablero, alturaCasilla / 2 );
    }

    /**
     * Dibuja los cubos de la bodega
     * @param g - La superficie del panel sobre la que se dibuja - g!=null
     * @throws Exception Cuando ocurre un error
     */
    private void dibujarCubos( Graphics g ) throws Exception
    {
        int maxX = bodega.darMaxX( ) + 1;
        int maxY = bodega.darMaxY( ) + 1;
        int alturaTablero = getHeight( );
        int anchoTablero = getWidth( );

        // Calcular el ancho de cada casilla
        int alturaCasilla = alturaTablero / ( maxY + 1 );
        int anchoCasilla = anchoTablero / ( maxX + 1 );

        // Calcular el tama�o de los cubos
        int alturaCubo = alturaCasilla;
        int anchoCubo = anchoCasilla * 2 / 3;

        for( int i = 0; i < maxX; i++ )
        {
            for( int j = 0; j < maxY; j++ )
            {
                Cubo cubo = null;
                try
                {
                    cubo = bodega.darCubo( i, j );
                }
                catch( Exception e )
                {
                    System.out.println( i + " " + j );
                    e.printStackTrace( );
                    System.exit( 0 );
                }
                if( cubo != null )
                {
                    // Calcular el centro del cubo
                    int posX = ( i + 1 ) * ( anchoCasilla );
                    int posY = ( j + 1 ) * ( alturaCasilla );
                    g.setColor( Color.BLACK );
                    g.setColor( cubo.darColor( ) );

                    // Dibujar el cubo
                    g.fillRect( posX - anchoCubo / 2, alturaTablero - posY - alturaCubo / 2, anchoCubo, alturaCubo );
                    g.setColor( Color.BLACK );
                    g.drawRect( posX - anchoCubo / 2, alturaTablero - posY - alturaCubo / 2, anchoCubo, alturaCubo );
                }
            }
        }
    }

    /**
     * Dibuja al brazo dentro de la bodega
     * @param g - La superficie del panel sobre la que se dibuja - g!=null
     */
    private void dibujarBrazoSinCubo( Graphics g )
    {
        int maxX = bodega.darMaxX( ) + 1;
        int maxY = bodega.darMaxY( ) + 1;
        int alturaTablero = getHeight( );
        int anchoTablero = getWidth( );

        // Calcular el ancho de cada casilla
        int alturaCasilla = alturaTablero / ( maxY + 1 );
        int anchoCasilla = anchoTablero / ( maxX + 1 );

        // Calcular el tama�o del brazo
        int alturaBrazo = alturaCasilla;
        int anchoBrazo = anchoCasilla;

        // Calcular el centro del brazo
        int posX = ( brazo.darPosX( ) + 1 ) * ( anchoCasilla );
        int posY = ( brazo.darPosY( ) + 1 ) * ( alturaCasilla );
        g.setColor( PanelBodega.COLOR_BRAZO );

        // Dibujar el brazo
        int puntosX[] = null;
        int puntosY[] = null;

        puntosX = new int[]{ -anchoBrazo * 5 / 12, -anchoBrazo / 2, -anchoBrazo / 3, anchoBrazo / 3, anchoBrazo / 2, anchoBrazo * 5 / 12 };
        puntosY = new int[]{ -alturaBrazo / 4, alturaBrazo / 3, ( int ) ( alturaBrazo * 0.75 ), ( int ) ( alturaBrazo * 0.75 ), alturaBrazo / 3, -alturaBrazo / 4 };

        for( int i = 0; i < 6; i++ )
        {
            puntosX[ i ] += posX;
            puntosY[ i ] += posY;
            puntosY[ i ] = alturaTablero - puntosY[ i ];
        }

        g.drawPolyline( puntosX, puntosY, 6 );

        // Dibujar el cable
        puntosX = new int[]{ posX - 2, posX + 2, posX + 2, posX - 2 };
        puntosY = new int[]{ alturaTablero - posY - ( int ) ( alturaBrazo * 0.75 ), alturaTablero - posY - ( int ) ( alturaBrazo * 0.75 ), 0, 0 };
        g.fillPolygon( puntosX, puntosY, 4 );
    }

    /**
     * Dibuja al brazo dentro de la bodega cargando un cubo
     * @param g Es la superficie de la bodega
     */
    private void dibujarBrazoConCubo( Graphics g )
    {
        int maxX = bodega.darMaxX( ) + 1;
        int maxY = bodega.darMaxY( ) + 1;
        int alturaTablero = getHeight( );
        int anchoTablero = getWidth( );

        // Calcular el ancho de cada casilla
        int alturaCasilla = alturaTablero / ( maxY + 1 );
        int anchoCasilla = anchoTablero / ( maxX + 1 );

        // Calcular el tama�o del brazo
        int alturaBrazo = alturaCasilla;
        int anchoBrazo = anchoCasilla;

        // Calcular el centro del brazo
        int posX = ( brazo.darPosX( ) + 1 ) * ( anchoCasilla );
        int posY = ( brazo.darPosY( ) + 1 ) * ( alturaCasilla );
        g.setColor( PanelBodega.COLOR_BRAZO );

        // Dibujar el brazo
        int puntosX[] = null;
        int puntosY[] = null;

        puntosX = new int[]{ -anchoBrazo / 3, -anchoBrazo / 2, -anchoBrazo / 3, anchoBrazo / 3, anchoBrazo / 2, anchoBrazo / 3 };
        puntosY = new int[]{ -alturaBrazo / 4, alturaBrazo / 3, ( int ) ( alturaBrazo * 0.75 ), ( int ) ( alturaBrazo * 0.75 ), alturaBrazo / 3, -alturaBrazo / 4 };

        for( int i = 0; i < 6; i++ )
        {
            puntosX[ i ] += posX;
            puntosY[ i ] += posY;
            puntosY[ i ] = alturaTablero - puntosY[ i ];
        }
        g.drawPolyline( puntosX, puntosY, 6 );

        // Dibujar el cable
        puntosX = new int[]{ posX - 2, posX + 2, posX + 2, posX - 2 };
        puntosY = new int[]{ alturaTablero - posY - ( int ) ( alturaBrazo * 0.75 ), alturaTablero - posY - ( int ) ( alturaBrazo * 0.75 ), 0, 0 };
        g.fillPolygon( puntosX, puntosY, 4 );

        // Calcular el tama�o del cubo
        int alturaCubo = alturaCasilla;
        int anchoCubo = anchoCasilla * 2 / 3;

        // Dibujar el cubo
        Cubo cubo = brazo.darCuboCargado( );
        g.setColor( cubo.darColor( ) );
        g.fillRect( posX - anchoCubo / 2, alturaTablero - posY - alturaCubo * 2 / 3, anchoCubo, alturaCubo );
        g.setColor( Color.BLACK );
        g.drawRect( posX - anchoCubo / 2, alturaTablero - posY - alturaCubo * 2 / 3, anchoCubo, alturaCubo );
    }

    /**
     * Este m�todo sirve para limpiar la superficie
     * @param g - La superficie del panel sobre la que se dibuja - g!=null
     */
    private void limpiar( Graphics g )
    {
        int alturaTablero = getHeight( );
        int anchoTablero = getWidth( );
        g.setColor( PanelBodega.COLOR_TABLERO );
        g.fillRect( 0, 0, anchoTablero, alturaTablero );
    }

    /**
     * Dibuja la bodega
     * @param g - La superficie del panel sobre la que se dibuja - g!=null
     */
    public void paint( Graphics g )
    {
        super.paint( g );
        try
        {
            actualizarPanel( g );
        }
        catch( Exception e )
        {
            JOptionPane.showMessageDialog( this, e.getMessage( ) );
        }
    }
}