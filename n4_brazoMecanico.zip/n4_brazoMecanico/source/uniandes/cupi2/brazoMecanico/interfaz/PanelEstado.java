/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico
 * Autor: Mario S�nchez - 22/06/2005 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

package uniandes.cupi2.brazoMecanico.interfaz;

import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;

/**
 * Este panel sirve para mostrar el estado del brazo mec�nico
 */
public class PanelEstado extends JPanel
{
    //-----------------------------------------------------------------
    // Atributos de la Interfaz
    //-----------------------------------------------------------------

    /**
     * Etiqueta para mostrar el mensaje
     */
    private JLabel labMensaje;

    /**
     * Etiqueta para mostrar la posici�n del brazo
     */
    private JLabel labPosicion;

    /**
     * Etiqueta para mostrar si en la posici�n del brazo hay un cubo o no
     */
    private JLabel labHayCubo;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Construye el panel
     */
    public PanelEstado( )
    {
        // Inicializar los elementos de la barra
        labMensaje = new JLabel( " " );
        labMensaje.setBorder( new LineBorder( Color.DARK_GRAY ) );

        labPosicion = new JLabel( " " );
        labPosicion.setHorizontalTextPosition( JLabel.CENTER );
        labPosicion.setBorder( new LineBorder( Color.DARK_GRAY ) );

        labHayCubo = new JLabel( " " );
        labHayCubo.setHorizontalTextPosition( JLabel.CENTER );
        labHayCubo.setBorder( new LineBorder( Color.DARK_GRAY ) );

        // Armar la barra
        setLayout( new GridBagLayout( ) );

        GridBagConstraints gridBagConstraints1 = new GridBagConstraints( 0, 0, 1, 1, 1.0, 0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets( 2, 2, 2, 2 ), 5, 0 );
        add( labMensaje, gridBagConstraints1 );

        GridBagConstraints gridBagConstraints2 = new GridBagConstraints( 1, 0, 1, 1, 0.2, 0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets( 2, 2, 2, 2 ), 5, 0 );
        add( labPosicion, gridBagConstraints2 );

        GridBagConstraints gridBagConstraints3 = new GridBagConstraints( 2, 0, 1, 1, 0.1, 0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets( 2, 2, 2, 2 ), 5, 0 );
        add( labHayCubo, gridBagConstraints3 );
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Actualiza la barra de estado con el mensaje y los valore indicados <br>
     * <b>post: </b>Se actualiz� la informaci�n mostrada en la barra
     * @param mensaje - El mensaje que debe mostrarse en la barra - mensaje!=null
     * @param posX- La coordenada X del brazo mec�nico
     * @param posY - La coordenada Y del brazo mec�nico
     * @param hayCubo - Indica si en la posici�n actual hay cubo o no
     */
    public void actualizarBarraDeEstado( String mensaje, int posX, int posY, boolean hayCubo )
    {
        labMensaje.setText( mensaje );
        labPosicion.setText( posX + "," + posY );
        if( hayCubo )
            labHayCubo.setText( "Hay cubo" );
        else
            labHayCubo.setText( "No hay cubo" );
    }
}
