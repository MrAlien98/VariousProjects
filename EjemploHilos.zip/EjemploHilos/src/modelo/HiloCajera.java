package modelo;

public class HiloCajera extends Thread {
	
	private Cajera cajera;
	private Cliente cliente;
	long time;

	public HiloCajera(Cajera cajera, Cliente cliente, long timeStamp) {
		super();
		this.cajera = cajera;
		this.cliente = cliente;
		this.time = timeStamp;
	}
	
	public void run() {
		cajera.procesarCompra(this.cliente, this.time);
	}

}
