package interfaz;

import mundo.*;

public class Menu{

	private FeriaCali feria;

	public Menu(){
		feria = new FeriaCali;
		Desfile[] d= feria.darDesfiles();
		d[0]= new Desfile('S',"28.12.2017","07:30", true);

		ArrayList<Artista> ad0 = d[0].darArtistas();
		ad0.add(new Artista(1, "Camilo Gomez", 20, 5, 15000.0, 5.0));
		
		}















public static void main(String [] args){
	Menu menu = new Menu();
}

}
