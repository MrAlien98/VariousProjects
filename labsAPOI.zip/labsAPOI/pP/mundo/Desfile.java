package mundo;

import java.util.*;

public class Desfile{
	
	public final static char SALSODROMO='S';
	public final static char CALI_VIEJO='C';
	public final static char CLASICOS='A';

	private char evento;
	private String fecha;
	private String horaInicio;
	private boolean graderiaGratuita;

	private ArrayList<Artista> artistas;

	public Desfile(char e, String f, String hi, boolean gG){
		evento=e;
		fecha=f;
		horaInicio=hi;
		graderiaGratuita=gG;

		artistas = new ArrayList();
	}


	public ArrayList<Artista> darArtistas(){
		return artistas;
	}

	
	public char darEvento(){
		return evento;
	}


	public void cambiarEvento(char eV){
		evento=eV;
	}


	public String darFecha(){
		return fecha;
	}


	public void cambiarFecha(String fC){
		fecha=fC;
	}


	public String darHoraInicio(){
		return horaInicio;
	}


	public void cambiarHoraInicio(String nHI){
		horaInicio=nHI;
	}


	public boolean darGraderiaGratuita(){
		return graderiaGratuita;
	}


	public void cambiarGraderiaGratuita(boolean nGG){
		graderiaGratuita=nGG;
	}


}