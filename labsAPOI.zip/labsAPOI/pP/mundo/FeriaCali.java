package mundo;

import java.util.*;

public class FeriaCali{
	
	public final static int CANTIDAD_DESFILE=3;

	private int numeroEdicion;
	private String discoFeria;

	private Desfile [] desfiles;

	public FeriaCali(int nE,String dF){
		numeroEdicion=nE;
		discoFeria=dF;

		desfiles = new Desfile[CANTIDAD_DESFILE];
	}

	public Desfile[] darDesfiles(){
		return desfiles;
	}

	
	public int darNumeroEdicion(){
		return numeroEdicion;
	}


	public void cambiarNumeroEdicion(int nNE){
		numeroEdicion=nNE;
	}

	public String darDiscoFeria(){
		return discoFeria;
	}

	public void cambiarDiscoFeria(String nDF){
		discoFeria=nDF;
	}


	public int contarBailarinesMenoresDe15(){
		int mens=0;
		for(int i=0;i<desfiles.length;i++){
			for(int j=0;j<artistas.size();j++){
				if(artistas.(Artista)get(j).darEdad()<15){
					mens++;
				}
			}
		}
		return mens;
	}	


	public ArrayList<Artista> listarArtistas(char ev, int esp){
		ArrayList<Artista>
	}

}