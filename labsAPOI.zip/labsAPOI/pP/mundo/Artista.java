package mundo;

public class Artista{

	public final static int MUSICO=1;
	public final static int BAILARIN=2;
	public final static int ACTOR=3;
	public final static int ACROBATA=4;

	private int especialidad;
	private String nombre;
	private int edad;
	private int anhosParticipa;
	private double valorHora;
	private double horasTrabajadas;

	public Artista(int e, String n, int eD, int aP, double vH, double hT){
		especialidad=e;
		edad=eD;
		anhosParticipa=aP;
		valorHora=vH;
		horasTrabajadas=hT;
	}

	public int darEspecialidad(){
		return especialidad;
	}


	public void cambiarEspecialidad(int x){
		especialidad=x;
	}


	public String darNombre(){
		return nombre;
	}


	public void cambiarNombre(String nN){
		nombre=nN;
	}


	public int darEdad(){
		return edad;
	}


	public void cambiarEdad(int y){
		edad=y;
	}


	public int darAnhosParticipa(){
		return anhosParticipa;
	}


	public void cambiarAnhosParticipa(int nA){
		anhosParticipa=nA;
	}


	public double darValorHora(){
		return valorHora;
	}


	public void cambiarValorHora(double wea){
		valorHora=wea;
	}


	public double darHorasTrabajadas(){
		return horasTrabajadas;
	}


	public void cambiarHorasTrabajadas(double nHT){
		horasTrabajadas=nHT;
	}

}