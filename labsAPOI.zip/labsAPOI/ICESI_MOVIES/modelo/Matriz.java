package modelo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * Implementa la clase Matriz
 * @author prof. x Victor Mora.
 * @version 2.0 28/10/2017
 * 
*/
public class Matriz {

	private String[] peliculas;
	private String[] usuarios;

	private int[][] calificaciones;
	
	/**
	 * Clase Matriz, la cual encapsula la colección de usuarios y de peliculas. También incluye la matriz con 
	 * con las calificaciones de los usuarios sobre las peliculas <br>
	*/

	public Matriz(String[] pelis, String[] users) {
		this.peliculas = pelis;
		this.usuarios = users;
		calificaciones = new int[users.length][pelis.length];
	}

	/**
	 * Este método permite cargar la matriz de calificaciones apartir del archivo de texto userItem.txt. <br>
	 */
	public void cargarCalificaciones() {
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader("data/userItem.txt"));

			String linea = "";
			int fila = 0;
			while ((linea = br.readLine()) != null) {

				String[] data = linea.split("\t");
				int col = 0;
				for (String strRatig : data) {
					calificaciones[fila][col] = Integer.parseInt(strRatig);
					col++;
				}

				fila++;
			}

			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {

		}

	}
	
	/**
	 * Este método permite mostrar por consola la matriz de calificaciones. <br>
	 */
	public String mostrarMatriz(){
		
		String mensaje = "";
		for(int i = 0; i<calificaciones.length; i++){
			for(int j = 0; j < calificaciones[0].length; j++){
				mensaje += " " + calificaciones[i][j];
			}
			mensaje += "\n";
		}
		
		return (mensaje);
	}

	/**
	 * Este método permite obtener la colección de películas <br>
	 * @return arreglo de tipo String, con el conjunto de peliculas de la clase Matriz
	 */
	public String[] obtenerPeliculas() {
		return peliculas;
	}

	/**
	 * Este método permite obtener la colección de usuarios <br>
	 * @return arreglo de tipo String, con el conjunto de usuarios de la clase Matriz
	 */
	public String[] obtenerUsuarios() {
		return usuarios;
	}


	/**
	 * Este método permite obtener la calificación promedio de películas vistas por un usuario.
	 * @param usuario int 
	 *					- El usuario en la posicion usuario.
	 * @return el promedio de las calificaciones de las peliculas vistas.
	 */
	public double promedioCPV(int usuario){
		usuario-=1;
		int cal = 0; 
		double c = 0.0; 
		for (int i=0;i<calificaciones[0].length;i++){
			if (calificaciones[usuario][i]!=0){
				cal+=calificaciones[usuario][i];
				c++;
			}
		}
		return cal/c;
	}

	/**
	 * Este método permite, Para una película dada, obtener su calificación promedio.
	 * @param pelicula int 	
	 *					- La pelicula en la posicion pelicula
	 * @return el promedio de las calificaciones de la pelicula.
	 */
	public double calificacionPP(int pelicula){
		pelicula-=1;
		int cal = 0; 
		double c = 0.0; 
		for (int i=0;i<calificaciones.length;i++){
			if (calificaciones[i][pelicula]!=0){
				cal+=calificaciones[i][pelicula];
				c++;
			}
		}
		return cal/c;
	}	


	/**
	 * Este método obtiene la calificación promedio de una pelicula.
	 * @return el nombre y la calificacion de la pelicula con la calificacion promedio mas alta.
	 */
	public String peliculaPMA(){
		double p=calificacionPP(1); 
		String nom=""; 
		for (int i=1;i<calificaciones[0].length;i++){
			if (calificacionPP(i)>p){
				p=calificacionPP(i);
				nom=peliculas[i-1];
			}
		}
		return nom+"  con una calificacion promedio de: "+p;
	}

	/**
	 * Este método obtiene la calificación promedio de una pelicula.
	 * @return el nombre y la calificacion de la pelicula con la calificacion promedio mas baja.
	 */
	public String peliculaPMB(){
		double p=calificacionPP(1); 
		String nom=""; 
		for (int i=1;i<calificaciones[0].length;i++){
			if (calificacionPP(i)<p){
				p=calificacionPP(i);
				nom=peliculas [i-1];
			}
		}
		return nom+"  con una calificacion promedio de: "+p;
	}


	/**
	* Este metodo revisa que peliculas no ha visto el usuario y las muestra como recomendacion.
	* @param usuario int
	*					-Numero que corresponde a un usuario.
	*					-usuario >0.
	*					-usuario!=null.
	* @return un string que contiene las peliculas que el, usuario no ha visto
	*/
	public String recom(int usuario){
	usuario-=1;
	String r=""; 
	for (int i=0;i<calificaciones[0].length;i++){
		if (calificaciones[usuario][i]==0){
			r+=peliculas[i];
			r+="\n";
		}
	}
	return r;
	}
}