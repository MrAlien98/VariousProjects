package interfaz;

import modelo.Matriz;
import java.util.Scanner;

public class MenuConsola {
	
	private Matriz userItem;
	
	public MenuConsola(){
		
		String[] peliculas =  { "Toy story2", "Jumanji", "Amelie", "Wolverine", "Spider Man", "Yes Men", "Sabrina",
				"Tom and Huck", "Sudden Death", "GoldenEye" };
		String[] usuarios = { "Jhon", "Michael", "Jimmy", "Janis", "Carla", "Angie" };
		userItem = new Matriz(peliculas, usuarios);
		cargarMatriz();
		mostrarBanner();

		mostrarUsuarios();
		mostrarPeliculas();
		opciones();
		//System.out.println(mostrarMatriz());
	}
	
	public void cargarMatriz(){
		userItem.cargarCalificaciones();
	}
	
	public String mostrarMatriz(){
		return userItem.mostrarMatriz();
	}
	
	/**
	 * Este m�todo permite concatenar los caracteres para el banner. <br>
	 */
	static void appendChars(StringBuilder sb, char c, int count) {
		for (int i = 0; i < count; i++) {
			sb.append(c);
		}
	}
	
	/**
	 * Este m�todo permite mostrar un banner en el Menu. <br>
	 */
	public void mostrarBanner() {
		StringBuilder all = new StringBuilder();
		all.append("\n");
		int ancho = 17;
		for (int a = 1; a <= 4; a++) {
			int cantidadAsteriscos = ancho - a;
			int cantidadEspacios = ancho - cantidadAsteriscos;
			int cantidadSlashes = (ancho - a) * 2;
			int cantidadDeBackSlashes = (a - 1) * 2;
			appendChars(all, '*', cantidadAsteriscos);
			appendChars(all, ' ', cantidadEspacios);
			appendChars(all, '/', cantidadSlashes);
			appendChars(all, '\\', cantidadDeBackSlashes);
			appendChars(all, ' ', cantidadEspacios);
			appendChars(all, '*', cantidadAsteriscos);
			all.append("\n");
		}

		all.append("*****************************************************************\n");
		all.append("************************** Icesi-Movie ***************************\n");
		all.append("*****************************************************************\n");

		for (int a = 4; a >= 1; a--) {
			int cantidadAsteriscos = ancho - a;
			int cantidadEspacios = ancho - cantidadAsteriscos;
			int cantidadDeBackSlashes = (ancho - a) * 2;
			int cantidadSlashes = (a - 1) * 2;
			appendChars(all, '*', cantidadAsteriscos);
			appendChars(all, ' ', cantidadEspacios);
			appendChars(all, '/', cantidadSlashes);
			appendChars(all, '\\', cantidadDeBackSlashes);
			appendChars(all, ' ', cantidadEspacios);
			appendChars(all, '*', cantidadAsteriscos);
			all.append("\n");
		}
		all.append("\n");
		System.out.println(all.toString());
	}
	
	/**
	 * Este m�todo permite mostrar por consola los usuarios <br>
	 */
	public void mostrarUsuarios(){
		System.out.println("Usuarios:");
		
		String[] usuarios = userItem.obtenerUsuarios();
		int c = 1;
		for(String us : usuarios){
			System.out.println(c + ". " + us + "\t");
			c++;
		}
	}
	
	/**
	 * Este m�todo permite mostrar por consola las peliculas <br>
	 */	
	public void mostrarPeliculas(){
		System.out.println("Peliculas:");
		
		String[] pelis = userItem.obtenerPeliculas();
		int c = 1;
		for(String pel : pelis){
			System.out.println(c + ". " + pel + "\t");
			c++;
		}
	}


	public void opciones(){
		Scanner leer = new Scanner (System.in);
		int op;
		String m = "1. Calificaciones promedio de las peliculas de un usuario\n2. Calificacion promedio de ua pelicula\n3. Pelicula con calificacion promedio mas alto \n4. Pelicula con calificacion promedio mas bajo \n5. Recomendaciones para un usuario \n6. Salir \nDigite su opci�n: ";
		do{
			System.out.print("===============================\n"+m);
			op = leer.nextInt();
			switch(op){
				case 1:requerimiento1();
					break;
				case 2:requerimiento2();
					break;
				case 3:requerimiento3();
					break;
				case 4:requerimiento4();
					break;
				case 5:requerimiento5();
					break;
				case 6:System.out.println("\nS A L I O");
					break;
				default:System.out.println("Error en la opcion");
			}
		}
		while (op != 6);
	}

	
	public void requerimiento1(){
		Scanner leer = new Scanner(System.in);
		int u;
		System.out.println("Digite el numero de usuario que desea consultar : ");
		u=leer.nextInt();
		System.out.println("El promedio de calificaciones de este usuario es de: "+userItem.promedioCPV(u));
	}


	public void requerimiento2(){
		Scanner leer = new Scanner(System.in);
		int p;
		System.out.println("Digite el numero de la pelicula que desea consultar : ");
		p=leer.nextInt();
		System.out.println("El promedio de la pelicula es: "+userItem.calificacionPP(p));

	}


	public void requerimiento3(){
		System.out.println("La pelicula con el promedio de calificacion mas alto es: "+userItem.peliculaPMA());
	}


	public void requerimiento4(){
		System.out.println("La pelicula con el promedio de calificaion mas bajo es: "+userItem.peliculaPMB());
	}


	public void requerimiento5(){
		Scanner leer = new Scanner(System.in);
		int u;
		System.out.println("Digite el numero que corresponde al usuario del que quiere obtener recomendaciones : ");
		u=leer.nextInt();
		System.out.println("El usuario deberia ver: "+userItem.recom(u));

	}


	public static void main(String[] args) {
	
		MenuConsola menu = new MenuConsola();

	}

}
