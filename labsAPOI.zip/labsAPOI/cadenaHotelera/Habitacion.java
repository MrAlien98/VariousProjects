package cadenaHotelera;

public class Habitacion {

private int numeroHabitacion;
private String tipoCama;
private int piso; 
private double tarifa;

	public Habitacion ( String nTipoCama, int nPiso, int nNum)
	{
	numeroHabitacion = nNum;
	tipoCama = nTipoCama;
	piso = nPiso;

	}


	
	
}