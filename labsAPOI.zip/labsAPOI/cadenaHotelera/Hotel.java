package cadenaHotelera;

public class Hotel {

	/* Atributos */
	private int capacidadAlojamiento;
	private String nombre;
	private double ventas;
	
	/*Relaciones*/
	private Empleado recepcionista;
	private Empleado botones;
	private Empleado aseador;	
	

	
	
	public Hotel (int nCapacidadAlojamiento, String nNombre){
		
		nombre = nNombre;
		capacidadAlojamiento = nCapacidadAlojamiento;
		ventas=0;	
		recepcionista=null;
		botones=null;
		aseador=null;
	}
	
	public void crearRecepcionista (String pNom,int pID, double pSal){ 
		recepcionista= new Empleado(pNom,pID, pSal);
		
	}
	
	public void crearBotones (String pNom,int pID, double pSal){ 
		botones= new Empleado(pNom,pID, pSal);
		
	}
	
	public void crearAseador (String pNom,int pID, double pSal){ 
		aseador= new Empleado(pNom,pID, pSal);
		
	}
	
	public double darVentas(){
		return ventas;
	}
	
	public Empleado darRecepcionista(){
		return recepcionista;
	}
	
}	