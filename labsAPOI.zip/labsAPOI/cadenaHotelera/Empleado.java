package cadenaHotelera;

public class Empleado {


	private String nombre;
	private int id;
	private double salarioDev;
	private double descuentos;
	private double salarioNeto;
	
	public Empleado(String nNombre,int nID, double nSalarioDev){ //constructor 
		
       nombre = nNombre;
       id = nID;
       salarioDev = nSalarioDev;
       descuentos= nSalarioDev*0.04;
       salarioNeto=nSalarioDev-descuentos;
	
	}
	
	public String darNombre(){
		return nombre;
	}
	
	
}