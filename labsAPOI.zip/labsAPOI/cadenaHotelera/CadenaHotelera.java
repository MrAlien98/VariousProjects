package cadenaHotelera;


public class CadenaHotelera {
	
	/*Atributos*/
	private String nombre;
	

	/*  Relaciones */
	private Hotel uno;
	private Hotel dos;
	private Hotel tres;
	
	public CadenaHotelera (){
		
	}
	
	public double totalVendido(){
	     double total;
	     total= uno.darVentas() + dos.darVentas()+ tres.darVentas();
	     return total;
	}

	public String darPremioMejorRecepcionista(){
		String nombreRecepcionista= tres.darRecepcionista().darNombre();
		return nombreRecepcionista;
	}
	
	public void crearRecepcionista(int numHotel, String pn, double psal, int cedula){
		if (numHotel==1)
			uno.crearRecepcionista(pn, cedula, psal);
		if (numHotel==2)
			dos.crearRecepcionista(pn, cedula, psal);
	}
	
	
	}
