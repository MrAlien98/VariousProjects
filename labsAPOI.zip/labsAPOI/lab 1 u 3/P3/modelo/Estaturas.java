package modelo;

public class Estaturas
{

	public final static int EST = 16;
	
	private double [] estaturas;
	double promedio = 0.0;
	
	public Estaturas()
	{
		estaturas = new double [EST];
		estaturas[0] = 1.75;
		estaturas[1] = 1.7;
		estaturas[2] = 1.58;
		estaturas[3] = 1.54;
		estaturas[4] = 1.6;
		estaturas[5] = 1.8;
		estaturas[6] = 1.78;
		estaturas[7] = 1.82;
		estaturas[8] = 1.7;
		estaturas[9] = 1.79;
		estaturas[10] = 1.7;
		estaturas[11] = 1.67;
		estaturas[12] = 1.79;
		estaturas[13] = 1.65;
		estaturas[14] = 1.76;
		estaturas[15] = 1.82;
	}
	
	public void calcularPromedio()
	{
		double promedio = 0.0;
		double suma = 0.0;
		int indice = 0;
		while (indice < EST)
		{
			suma += estaturas[indice]; 
			indice++;
		}
		promedio = suma/EST;
		System.out.println(promedio);
	}
	
	public void arAbPro()
	{

		int contadorB = 0;
		int contadorA = 0;
		for (int i = 0; i <=15; i++)
		{
			
			if (estaturas[i] >= promedio)
			{
				 contadorA++;
			}
			else
			{
				contadorB++;
			}
			
		}
		
		System.out.println("El numero de estudiantes que son mas altos que el promedio es de " + contadorA);
		System.out.println("El numero de estudiantes que son mas bajos que el promedio es de " + contadorB);
	}
	
			
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}