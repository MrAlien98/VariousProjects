package interfaz;

import modelo.Estaturas;
import java.util.Scanner;

public class Menu
{
	private Estaturas esta;
	
	public Menu()
	{
		Scanner leer = new Scanner (System.in);
		prom();
		bajal();
	}
	
	
	public void prom(){
		System.out.println("\n");
		System.out.println("GREATINGS WORLD");
		System.out.println("\n");
	
		System.out.println("EL PROMEDIO DE ESTATURA DE LOS ESTUDIANTES DEL GRUPO 9 DE APO I ES DE");
		esta = new Estaturas();
		esta.calcularPromedio();
		System.out.println("\n");
	}
	
	public void bajal(){
		esta = new Estaturas();
		esta.arAbPro();
	}

public static void main (String [] args){
		Menu menu = new Menu ();
		}

}
	