package interfaz;

import modelo.Fibonacci; 
import java.util.Scanner;

public class Menu
{
	private Fibonacci fibo;
	
	public Menu()
	{
		Scanner leer = new Scanner(System.in);
		fibonacci();
		sumar();
		
	}
	
	public void fibonacci(){
		
	System.out.println("\n");
	System.out.println("GREATINGS WORLD");
	System.out.println("\n");
	
	System.out.println("SERIE DE FIBONACCI");
	System.out.println("\n");
	fibo = new Fibonacci();
	fibo.sacarFibonacci();
	System.out.println("\n");
	}
	
	public void sumar(){
	Scanner leer = new Scanner(System.in);
	
	System.out.println("SUMAR");
	System.out.println("\n");
	
	System.out.println("Ingrese un numero entre : ");
	int x = leer.nextInt();
	System.out.println("\n");
	
	System.out.println("La suma de numeros pares entre su numero y 100 es de : ");
	fibo = new Fibonacci();
	fibo.sumarPares(x);
	System.out.println("\n");
	
	}

	
	public static void main (String [] args){
		Menu menu = new Menu ();
		}
		

}