package modelo;

public class Fibonacci
{
	
	public Fibonacci (){
	}
	
	
	public void sacarFibonacci(){
	
	int num1 = 0;
	int num2 = 1;
	int tope = 50;
	int counter;
	
		System.out.println(num1);
		System.out.println(num2);
		
	while (num2 + num1 <= tope)
	{
		counter = num1;
		num1 = num2;
		num2 = counter + num2;
		
		if (num2 % 2 == 0)
		{
			System.out.println(num2 + "*");
		}
		else 
		{
			System.out.println(num2);
		}
	}
	
}

	public void sumarPares(int x){
		int y = 0;
		if (x < 100 && x%2 ==0)
		{
			while(x <= 100)
			{
				y += x;
				x+=2;
			}
		
		}
		else if (x < 100 && x%2 != 0)
		{
			while(x <= 100)
			{
				x++;
				y += x;
				x+=2;
			}
			
	}	
	
	System.out.println(y);
	
	
	
	
	}
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}