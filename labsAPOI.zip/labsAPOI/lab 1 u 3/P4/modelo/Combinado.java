package modelo;

public class Combinado
{
	public Combinado(){
	}
	
	
	public void combinator(int nC1, int nC2) {
		int f1 = 1;
		int f2 = 1;
		int f3 = 1;
		int rC= (nC1 - nC2);
		int combi;
		String combinatoria = "";
		
		if (nC1 >= nC2) {
			
			for (int i = 1; i <= nC1; i++) {
				f1 = f1*i;
			}
			
			for (int j = 1; j <= nC2; j++) {
				f2 = f2*j;
			}
			
			for (int k = 1; k <= rC; k++) {
				f3 = f3*k;
			}
			
			combi = (f1/((f3)*f2));
			
			combinatoria = ("El "+nC1+"Cn"+nC2+" = "+combi);
			
		}else if (nC1 < nC2) {
			combinatoria = ("Math ERROR");
		}
		System.out.println(combinatoria);
	}
	

}	