package interfaz;

import java.util.Scanner;
import modelo.Combinado;

public class Menu
{
	private Combinado combin;
	
	public Menu()
	{
		Scanner leer = new Scanner(System.in);
		comb();	
	}
	
public void comb(){
	Scanner leer = new Scanner(System.in);
	
	System.out.println("\n");
		System.out.println("GREATINGS WORLD");
		System.out.println("\n");
	
		System.out.println("INGRESE UN NUMERO NATURAL : ");
		int x = leer.nextInt();
		System.out.println("INGRESE OTRO NUMERO NATURAL : ");
		int y = leer.nextInt();
		System.out.println("\n");
		System.out.println("EL COMBINADO DE SUS DOS NUMERO ES");
		combin = new Combinado();
		combin.combinator(x, y);
		System.out.println("\n");
}
	public static void main (String [] args){
		Menu menu = new Menu ();
		}

	
}