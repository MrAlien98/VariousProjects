package modelo;

	public class CadenaHotel{


		private double ingresoTotal;
		private String nombreCadena;
		private double nomina;
		
	//relaciones*/ 
	
		private Hotel hotel1;
		private Hotel hotel2;
		private Hotel hotel3;
	
			public CadenaHotel(){
	
				nomina = 0;
				modificarNombreCadena("Caliwood");
			
				hotel1 = new Hotel(8, 2, 0, 0, "frozono");
				hotel2 = new Hotel(8, 2, 0, 0, "Dash");
				hotel3 = new Hotel(8, 2, 0, 0, "Apo");
			
				hotel1.modificarAseador(new Empleado("Carlos", "Planton", "1515432467", 800000));
				hotel2.modificarAseador(new Empleado("julian", "Britto", "9000878667", 8000000));
				hotel3.modificarAseador(new Empleado("Carolina", "Armero", "6665478765", 8000000));
			
				hotel1.modificarRecepcionista(new Empleado("Camilo", "Torres", "2050755049", 2000000));
				hotel2.modificarRecepcionista(new Empleado("Juliana", "Zamorano", "9440127896", 2000000));
				hotel3.modificarRecepcionista(new Empleado("Andres", "Torres", "2234156387", 2000000));
			
				hotel1.modificarBotones(new Empleado("Sofia", "Londono", "0999877809", 200000));
				hotel2.modificarBotones(new Empleado("William", "soprano", "9887060064", 200000));
				hotel3.modificarBotones(new Empleado("Camila", "Saavedra", "7765658909", 200000));
			
	}
	
	
	
	public double darNomina(){
		return nomina;
	}
	
	public void modificarNomina(double nomina){
		this.nomina = nomina;
	}
	
	public double darIngresoTotal(){
		return ingresoTotal;
	}
	
	public void modificarIngresoTotal(double ingresoTotal){
		this.ingresoTotal = ingresoTotal;
	}
	
	public String darNombreCadena(){
		return nombreCadena;
	}
	
	public void modificarNombreCadena(String nombreCadena){
		this.nombreCadena = nombreCadena;
	}
	
	public Hotel darHotel1(){
		return hotel1;
	}
	
	public void modificarHotel1(Hotel hotel1){
		this.hotel1 = hotel1;
	}
	
	public Hotel darHotel2(){
		return hotel2;
	}
	
	public void modificarHotel2(Hotel hotel2){
		this.hotel2 = hotel2;
	}
	
	public Hotel darHotel3(){
		return hotel3;
	}
	
	public void modificarHotel3(Hotel hotel3){
		this.hotel3 = hotel3;
	}
	
	public double generarInformeFinanciero(){
		
		double total = hotel1.dineroRecib() + hotel2.dineroRecib() + hotel3.dineroRecib();
		ingresoTotal = total;
	
	}
	
	
}