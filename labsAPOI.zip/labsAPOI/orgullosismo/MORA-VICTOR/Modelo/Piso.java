package modelo;

public class Piso{
	
	private double numPiso;
	
		/** aqui comienzan las asociaciones*/

	private Habitacion habi1;
	private Habitacion habi2;
	private Habitacion habi3;
	private Habitacion habi4;
	
	public Piso(double nupi){
		numPiso = nupi;
		
	}
	
	private double darNumPiso(){
		return numPiso;
	}
	
	public void modificarNumPiso(double numPiso){
		this.numPiso = numPiso;
	}
	
	public Habitacion darHabi1(){
		return habi1;
	}
	
	public void modificarHabi1(Habitacion habi1){
		this.habi1 = habi1;
	}
	
	public Habitacion darHAbi2(){
		return habi2;
	}
	
	public void modificarHabi2(Habitacion habi2){
		this.habi2 = habi2;
	}
	
	public Habitacion darHabi3(){
		return habi3;
	}
	
	public void modificarHabi3(Habitacion habi3){
		this.habi3 = habi3;
	}
	
	public Habitacion darHabi4(){
		return habi4;
	}
	
	public void modificarHabi4(Habitacion habi4){
		this.habi4 = habi4;
	}
	
	
	
	
	
}