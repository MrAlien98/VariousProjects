package modelo;

public class Habitacion{
	
	private double numPiso;
	private double tipoCama;
	private double precioHabi;
	
		/**asociaciones*/

	private Cama cama1;
	
	public Habitacion(){
		
	}
	
	public double darNumPiso(){
		return numPiso;
	}
	
	public void modificarNumPiso(double numPiso){
		this.numPiso = numPiso;
	}
	
	public double darTipoCama(){
		return tipoCama;
	}
	
	public void modificarTipoCama(double tipoCama){
		this.tipoCama = tipoCama;
	}
	
	public double draPrecioHabi(){
		return precioHabi;
	}
	
	public void modificarPrecioHabi(double precioHabi){
		this.precioHabi = precioHabi;
	}
	
	public Cama darCama2(){
		return cama1;
	}
	
	public void modificarCama1(Cama cama1){
		this.cama1 = cama1;
	}
	

	
}