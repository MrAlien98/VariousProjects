package mundo;

public class InformeFinanciero;

{
	privaterivate int ingresoHotel;
	privaterivate int ingresoTotal;
	
}