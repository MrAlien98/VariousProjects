package modelo;

public class Empleado;

{
	private String nombre;
	private String apellido;
	private String documentoIdentidad;
	private int salarioDevengado;
	private double descuento;
	private double salarioNeto;
	
	//asociaciones*/
	
		public Empleado(String nom, String ape, String cc, 
		int salaD) {
			
			nombre = nom;
			apellido = ape;
			documentoIdentidad = cc;
			salarioDevengado = salaD;
			descuento = salaD * 0.04;
			salarioNeto = salaD - descuento;
			
		}
		
		//metodos*/
		
		public String darNombre(){
			return nombre;
		}
		
		public void modificarNombre(String nuevoNombre){
			this.nombre = nombre;
		}
		
		public String darApellido(){
			return apellido;
		}
		
		public void modificarApellido(String nuevoApellido){
			this.apellido = apellido;
		}
		
		public String darDocumentoIdentidad(){
			return documentoIdentidad;
		}
		
		public void modificarDocumentoIdentidad(String nuevoDocumentoIdentidad){
			this.documentoIdentidad = documentoIdentidad;
		}
		
		public int darSalarioDevengado(){
			return salarioDevengado;
		}
		
		public void modificarSalarioDevengado(int nuevoSalarioDevengado){
			this.salarioDevengado = salarioDevengado;
		}
		
		public double darDescuento(){
			return descuento;
		}
		
		public void modificarDescuento(double nuevoDescuento){
			this.descuento = descuento;
		}
		
		public double darSalarioNeto(){
			return salarioNeto;
		}
		
		public void modoficarSalarioNeto(double nuevoSalarioNeto){
			this.salarioNeto = salarioNeto;
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}