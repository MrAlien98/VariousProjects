package mundo;

public class Paleognato extends Neornithe{

	private int huesosPaladar;

	public Paleognato(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPaladar){
		super(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso);

		this.huesosPaladar=huesosPaladar;
	}

	public int darHuesosPaladar(){
		return huesosPaladar;
	}

	public void modificarHuesosPaladar(int huesosPaladar){
		this.huesosPaladar=huesosPaladar;
	}
	
}