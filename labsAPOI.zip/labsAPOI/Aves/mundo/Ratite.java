package mundo;

public class Ratite extends Paleognato{
	
	public static final int SI_QUILLA=1;
	public static final int NO_QUILLA=2;

	private int quilla;

	public Ratite(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPaladar, int quilla){
		super(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPaladar);

		this.quilla=quilla;
	}

	public int darQuilla(){
		return quilla;
	}

	public void modificarQuilla(int quilla){
		this.quilla=quilla;
	}

}