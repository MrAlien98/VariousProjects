package mundo;

public class Passeriforme extends Neoave
							implements InterfaceCantor{
	
	public Passeriforme(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo, double longPatas, int dedosPatas){
		super(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, longPatas, dedosPatas);
	}


	public String consultarAcordes(){
		String acorde="";
		if(darLongPatas()>5){
			acorde="Acorde musical para canto y apareamiento";
		}else if(darDedosPatas()>3){
			acorde="acorde musical de acto comunicativo y reclamo";
		}
		return acorde;	
	}

}