package mundo;

public interface InterfaceVuelo{
	
	public double calcularAlturaMaxima();
	
	public double velVuelo();

	public boolean esMigratoria();
}