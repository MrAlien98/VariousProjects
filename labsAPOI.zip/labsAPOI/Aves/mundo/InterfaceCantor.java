package mundo;

public interface InterfaceCantor{
	
	public String consultarAcordes();
}