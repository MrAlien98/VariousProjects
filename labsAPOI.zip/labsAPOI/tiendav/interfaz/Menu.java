package interfaz;

import modelo.Tienda;
import java.util.Scanner;

/**
 * Implementa la clase menu
 * @author Victor Mora
 * @version 1.0 11/10/2017
 *
*/

public class Menu{
	private Tienda store;

	public Menu (){
		store = new Tienda();

		opciones();
	}

	
	public void opciones(){
			Scanner leer = new Scanner(System.in);
			int op;
			String salida = "1. Adicionar producto al catalogo.\n"+
						"2. Agregar un producto al carro de compras.\n"+
						"3. Retirar un producto del carro de compras.\n"+
						"4. Lista del pedido.\n"+
						"5. Lista del catalogo de productos.\n"+
						"6. Modificar pedido.\n"+
						"7. Finalizar compra.\n"+
						"\nDigite su opcion [1 - 7]: ";
						
			do{
				System.out.print(salida);
				op = leer.nextInt();
				
				switch(op){
					case 1:	System.out.print("\n=========================Adicionar producto al catalogo.=========================\n");
							requerimiento1();
							break;
					case 2: System.out.print("\n=========================Agregar un producto pedido.=========================\n");
							requerimiento2();
							break;
					case 3: System.out.print("\n=========================Retirar un producto del carro de compras.=========================\n");
							requerimiento3();
							break;
					case 4: System.out.print("\n=========================Listar el pedido.=========================\nNombre/Unidades/Precio Unitario/Subtotal.\n");
							requerimiento4();
							break;
					case 5: System.out.print("\n=========================Listar el catalogo de productos.=========================\n");
							requerimiento5();
							break;
					case 6: System.out.print("\n=========================Modificar Pedido=========================\n");
							requerimiento6();
							break;
					case 7: System.out.print("\n=========================Finalizar compra=========================\n");
							requerimiento7();
							break;
					default: System.out.print("\n=========================Error en la opcion.=========================\n");
				}
				System.out.print("\n\n========================================================================================================================\n\n");
				
			}while(op != 7);
		}

	public void requerimiento1(){
		Scanner leer = new Scanner (System.in);
		String codigo;
		do{		
			System.out.print("Escriba el codigo de el producto : ");
			codigo = leer.nextLine();
			if(store.verificarCodigo(codigo)){

			System.out.println("El codigo ya existe, ingrese un codigo diferente");
		}
		
		}while(store.verificarCodigo(codigo));

		System.out.print("Escriba el nombre del producto : ");
		String nombre = leer.nextLine();
		System.out.print("Escriba el precio del producto : ");
		int precio = leer.nextInt();
		store.agregarProducto(codigo, nombre, precio);
		System.out.print(store.darProductos().size());
	}

	public void requerimiento2(){

		if(store.darPedido().darItemsPedido() != null){

			Scanner leer = new Scanner(System.in);
			System.out.print(store.listarProductos());
			int pProd;
			do{
				System.out.print("Digite el numero del producto que desea comprar : ");
				pProd = leer.nextInt();
			}while(pProd<1 || pProd > store.darProductos().size());

			int unidades;
			do{
				System.out.print("Digite el numero de unidades a comprar : ");
				unidades = leer.nextInt();
			}while(unidades<5);

			store.agregarAPedido(pProd, unidades);
			System.out.print("Productos en el pedido = "+store.darPedido().darItemsPedido().size());
		}


	}

	public void requerimiento3(){
		if(store.darPedido().darItemsPedido().isEmpty())
			System.out.print("El pedido esta vacio, no hay items para eliminar.");
		else{
			Scanner leer = new Scanner(System.in);
			System.out.print(store.darPedido().listarPedido());
			System.out.print("Digite el numero del item que desea eliminar del pedido : ");
			int eItem = leer.nextInt();

			store.eliminarElementoPedido(eItem);
			System.out.print(store.darPedido().darItemsPedido().size());
		}
	}

	public void requerimiento4(){
		if(store.darPedido().darItemsPedido().isEmpty())
			System.out.print("\nEl pedido esta vacio.");
		else{
			System.out.print("\n"+store.darPedido().listarPedido());
		}
	}

	public void requerimiento5(){
		System.out.print("\n"+store.listarProductos());
	}

	public void requerimiento6(){
		Scanner leer = new Scanner(System.in);
		int o;
		if(store.darPedido().darItemsPedido().isEmpty())
			System.out.print("\nEl pedido esta vacio.");
		else{
			do{
				System.out.print("\nSeleccione el elemento del pedido del que desea modificar las unidades.\n"+store.darPedido().listarPedido());
				o = leer.nextInt();
			}while(o<1 || o>store.darPedido().darItemsPedido().size());

			int unidades;
			do{
				System.out.print("\nDigite el nuevo numero de unidades para el producto :");
				unidades = leer.nextInt();
			}while(unidades<5);

			store.darPedido().modificarPedido(o, unidades);

		}
	}

	public void requerimiento7(){
		System.out.print("Su pedido tiene un valor de: "+store.darPedido().precioTotal());
	}

	public static void main (String [] args){
		Menu menu = new Menu();
	}


}