package mundo;

public class InformeFinanciero

{
	private int ingresoHotel;
	private int ingresoTotal;
	
	public InformeFinanciero(){
	}
	
}