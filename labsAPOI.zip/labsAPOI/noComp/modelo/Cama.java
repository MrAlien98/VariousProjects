package modelo;

	public class Cama;

	{
	
		private double tipo;
		private double precio;

			public Cama(double tip, double preci){
				tipo = tip;
				precio = preci;
		
			}
		
		private double darTipo(){
			return tipo;
		}
		
		private void modificarTipo(double nuevoTipo){
			this.tipo = tipo;
		}
		
		private double darPrecio(){
			return precio;
		}
		
		private void modificarPrecio(double nuevoPrecio){
			this.precio = precio;
		}
		
		
	}	
}