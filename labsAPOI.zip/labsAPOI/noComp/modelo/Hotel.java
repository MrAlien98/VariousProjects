package modelo;

public class Hotel 

{
	private int cantidadHab;
	private int piso;
	private int capacidadAloj;
	private double dineroRecib;
	private String codHotel;
	
	/**asociaciones*/
	
	private Piso piso1;
	private Piso piso2;
	
	private InformeFinanciero informeF1;
	private InformeFinanciero informeF2;
	private InformeFinanciero informeF3;
	
	private Empleado aseador;
	private Empleado recepcionista;
	private Empleado botones;
		
		//constructor*/
		
		public Hotel(int cantHab, int pis, int capAloj, 
		double dinRec, string codHot) {
			
			cantidadHab = cantHab;
			piso = pis;
			capacidadAloj = capAloj;
			dineroRecib = dinRec;
			codHotel = codHot;
			
		}	
		
		//metodos*/
		
		public int darCantidadHab()	{
			return cantidadHab;
		}
		
		public void modificarCantidadHab(int cantidadHab) {
			this.cantHab = cantHab;
		}
		
		public int darPiso() {
			return piso;
		}
		
		public void modificarPiso(int piso) {
			this.piso = piso;
		}
		
		public int darCapacidadAloj(){
			return capacidadAloj;
		}
		
		public void modificarCapacidadAloj(int capacidadAloj){
			this.capacidadAloj = capacidadAloj;
		}
		
		public double darDineroRecib(){
			return dineroRecib;
		}
		
		public void modificarDineroRecib(double dineroRecib){
			this.dineroRecib = dineroRecib;
		}
		
		public String darCodHotel(){
			return codHotel;
		}
		
		public void modificarCodHotel(String nuevoCodHotel){
			this.codHotel = codHotel;
		}
		
		public Piso darPiso1(){
			return pisp1;
		}
		
		public void modificarPiso1(Piso nuevoPiso1){
			this.piso1 = piso1;
		}
		
		public Piso darPiso2(){
			return piso2;
		}
		
		public void modificarPiso2(Piso nuevoPiso2){
			this.piso2 = piso2;
		}
		
		public Empleado darAseador(){
			return aseador;
		}
		
		public void modificarAseador(Empleado nuevoAseador){
			this.aseador = aseador;
		}
		
		public Empleado darRecepcionista(){
			return recepcionista;
		}
		
		public void modificarRecepcionista(Empleado nuevoRecepcionista){
			this.recepcionista = recepcionista;
		}
		
		public Empleado darBotones(){
			return botones;
		}
		
		public void modificarBotones(Empleado nuevoBotones){
			this.botones = botones;
		}		
			
}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			