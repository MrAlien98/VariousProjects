package mundo; 

public class InformeMinisterio;

{
	private int HabsHotelHotel;
	private double CamasHab;
	private int capacidadHab;
	
}