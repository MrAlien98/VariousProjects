package interfaz;

import modelo.CadenaHotel;

public class MenuConsola{

	private CadenaHotel laCadena;

	
	public MenuConsola(){
		
		
		laCadena = new CadenaHotel();
		
		requerimiento1();
		
	}	
	
	public void requerimiento1(){
	
		laCadena.generarInformeFinanciero();		
		System.out.println("El total de nomina mensual de la cadena de hoteles es: "+ laCadena.darNomina() +" USD");
		
	}
	
	
	
	public static void main(String[] args){
		MenuConsola menu = new MenuConsola();
	}

}