package modelo;

public class Persona
{

	//--------------------------------------------------------
	//Atributos
	//--------------------------------------------------------
	
	private String nombre;
	private String apellido;
	private String cedula;
	
	//*Asociaciones*/
	
	private Vehiculo v1;
	private Vehiculo v2;
	
		public Persona(String nom, String ape, String cc, Vehiculo v1, Vehiculo v2){
			nombre = nom;
			apellido = ape;
			cedula = cc;
			this.v1 = v1;
			this.v2 = v2;
		}
		
		public String darNombre(){
			return nombre;
		}
		
		public String darApellido(){
			return apellido;
		}
		
		public String darCedula(){
			return cedula;
		}
		
		public Vehiculo darV1(){
			return v1;
		}
		
		public void modificarNombre(String nombre){
			this.nombre = nombre;
		}
		
		public void modificarApellido(String apellido){
			this.apellido = apellido;	
		}
		
		public void modificarCedula(String cedula){
			this.cedula = cedula;
		}
		
		
		
	
	
}