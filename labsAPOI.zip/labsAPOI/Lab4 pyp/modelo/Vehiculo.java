package modelo;

public class Vehiculo

{	
	public final static int MOTO = 1;
	public final static int CARRO = 2;
	public final static int ANIOACTUAL = 2017;
	
	//--------------------------------------------------------
	// Atributos
	//--------------------------------------------------------
	
	private String placa;
	private int modelo;
	private int kilometraje;
	private int tipo;
	private int cilindraje;
	private double soat;		
		
		public Vehiculo(String pl, int mod, int kilo, int tipo, int cili){
			
			placa = pl;
			modelo = mod;
			kilometraje = kilo;
			this.tipo = tipo;
			cilindraje = cili;
			
			calcularSoat();
		}
		
		 //----------------------------------------------------------------------------------
		 // Metodos
		 //----------------------------------------------------------------------------------
		
		public String darPlaca(){
			return placa;
		}
		
		public int darModelo(){
			return modelo;
		}
		
		public int darKilometraje(){
			return kilometraje;
		}
		
		public int darTipoVehiculo(){
			return tipo;
		}
		
		public int darCilindraje(){
			return cilindraje;
		}
		
		public double darSoat(){
			return soat;
		}
		
		public void modificarPlaca(String placa){
			this.placa = placa;
		}
		
		public void modificarModelo(int modelo){
			this.modelo = modelo;
		}
		
		public void modificarKilometraje(int kilometraje){
			this.kilometraje = kilometraje;
		}
		
		public void modificarTipoVehiculo(int tipoVehiculo){
			tipo = tipoVehiculo;
		}
			
		public void modificarCilindraje(int cilindraje){
			this.cilindraje = cilindraje;
			
		}
		
		public void modificarSoat(double soat){
			this.soat = soat;
			
		}
		
		public void calcularSoat(){
			double vs = (kilometraje * 0.25 ) * 1600;
			vs += (tipo == MOTO) ? 50000 : 70000;
			soat = vs;
			vs += (modelo <= 2010) ? 10000 : 0 ;
			vs -= esBajoCilindraje() ? vs * 0.10 : 0 ;
			
		}
	
		public boolean esBajoCilindraje(){
			//boolean cilin = (cilindraje == 1) ? true : false;
			return ((cilindraje == 2) ? true : false);
		}
		
		public String saberPicoyPlaca(){
		
		String mensaje;
		char ultNum = (darPlaca().charAt(5));
		mensaje = (ultNum == '2') ? "tiene pico y placa los lunes y miercoles" : (ultNum == '4') ? "tiene pico y placa los lunes y miercoles" : (ultNum == '6') ? "tiene pico y placa los lunes y miercoles" : (ultNum == '8') ? "tiene pico y placa los lunes y miercoles" : "tiene pico y placa los lunes y miercoles";
		return mensaje;	

		}	
			


		public String saberTecnoMec(){
		String tecnoM;
		tecnoM = (2017 - modelo > 5) ? "necesita revision tecnico macanica" : (kilometraje > 99999) ? "necesita revision tecnico mecanica" : "aun no necesita revision tecnico mecanica";
		
		return tecnoM;
		
		}
		

		
		
		
		
		
		
		
		
		
		
}