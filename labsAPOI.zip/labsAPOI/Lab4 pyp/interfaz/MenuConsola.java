package interfaz;

import java.util.Scanner;
import modelo.Persona;
import modelo.Vehiculo;

public class MenuConsola{
	
	private Persona firstPersona;
	
	public MenuConsola(){
		Scanner leer = new Scanner(System.in);
		
		int cantidadVehiculos;
		String dia;
		
		System.out.println("BIENVENIDO AL SISTEMA DE LA SECRETARIA DE TRANSITO");
		
		//System.out.println("Ingrese el dia actual : ");
		//dia = leer.nextLine();
		
		String cedulaP;
		String nombreP;
		String apellidoP;
		
		
		System.out.println("DATOS DE LA PERSONA");
		
		System.out.println("Ingrese la cedula de la persona : ");
		cedulaP = leer.nextLine();
		System.out.println("Ingrese el nombre de la persona : ");
		nombreP = leer.nextLine();
		System.out.print("Ingrese el apellido de la persona : ");
		apellidoP = leer.nextLine();
	
    	String placa;
		int modelo;
		int tipo;
		int kilometraje;
		int cilindraje;
		
		System.out.println("DATOS DEL VEHICULO");
		
		System.out.println("Ingrese la placa del vehiculo : ");
		placa = leer.nextLine();
		System.out.println("Defina el tipo de vehiculo : (1) CARRO (2) MOTO ");
		tipo = leer.nextInt();
        System.out.println("Ingrese el modelo del vehiculo (anio) : "); 
		modelo = leer.nextInt();
		System.out.print("Ingrese el kilometraje del vehiculo : ");
		kilometraje = leer.nextInt();
		System.out.println("Defina el cilindraje del vehiculo (1) alto (2) normal ");
		cilindraje = leer.nextInt();
		
		Vehiculo v1 = new Vehiculo (placa, modelo, kilometraje, tipo, cilindraje);

		firstPersona = new Persona(cedulaP, nombreP, apellidoP,v1,null);

		requerimiento1();
	}
	
	public void requerimiento1(){
				
		System.out.println("El valor del SOAT es : " + firstPersona.darV1().darSoat());
		
		System.out.println("Su vehiculo : " + firstPersona.darV1().saberTecnoMec());
		
		System.out.println("Su vehiculo : " + firstPersona.darV1().saberPicoyPlaca());
		
	}
	
	public static void main (String args []){
		
		MenuConsola	m = new MenuConsola();
	
	}

	
	
	
}