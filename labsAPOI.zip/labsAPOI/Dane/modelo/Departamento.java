package modelo;

public class Departamento
{
	public static final int MUNICIPIOS = 5;
	
	private String nombre;
	private int poblacionT;
	private int totalM;
	private int totalH;
	private int totalAM;
	private double edadP;
	private int ingrP;
	
	private Municipio [] mun;
	

	public Departamento(String x){
		nombre = x;
		mun = new Municipio[MUNICIPIOS];

	}
	
public String darMunicipios(){
	String mensaje = "";
	for(int i = 0; i<MUNICIPIOS; i++)
	{
		if(mun[i] != null)
		{
			mensaje = (""+mun[i]);
		}
	}
	return mensaje;
}

	
public void modificarMunicipio(Municipio [] mun){
	this.mun = mun;
}
	
public String darNombre(){
	return nombre;
}
	
public int darPoblacionT(){
	return poblacionT;
}
	
public int darTotalM(){
	return totalM;
}
	
public int darTotalH(){
	return totalH;
}
public int darTotalAM(){
	return totalAM;
}
	
public double darEdadP(){
	return edadP;
}
	
public int darIngrP(){
	return ingrP;
}
	
public void modificarNombre(String nombre){
	this.nombre = nombre;
}
	
public void modificarPoblacionT(int poblacionT){
	this.poblacionT = poblacionT;
}
	
public void modificarTotalM(int totalM){
	this.totalM = totalM;
}
	
public void modificarTotalH(int totalH){
	this.totalH = totalH;
}
	
public void modificarTotalAM(int totalAM){
	this.totalAM = totalAM;
}
	
public void modificarEdadP(double edadP){
	this.edadP = edadP;
}
	
public void modificarIngrP(int ingrP){
	this.ingrP = ingrP;
}
	
public boolean verd(){
	
	for(int i=0;i<MUNICIPIOS ;i++)
	{
		if (mun[i]==null)
		{
			return true;
		}
	}
	return false;
}


public boolean registrarMunicipios(String dp, int p, int cH, int cM, int aM, double eP, double iP)
{
	boolean registro = false;
	for (int i = 0; i<MUNICIPIOS && !registro; i++)
	{
		if (mun[i] == null)
		{
			mun[i] = new Municipio (dp, p, cH, cM, aM, eP, iP);
			registro = true;
		}
	}
	return registro;
}


}