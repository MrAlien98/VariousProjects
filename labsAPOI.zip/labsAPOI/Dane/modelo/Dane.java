package modelo;

public class Dane
{
	public static final int NUMERO_DPTOS = 32;
	
	private Departamento [] deptos;
	
	public Dane(){
	
	deptos = new Departamento[NUMERO_DPTOS];
	
		deptos [0] = new Departamento ("Amazonas");
		deptos [1] = new Departamento ("Antioqui");
		deptos [2] = new Departamento ("Arauca");
		deptos [3] = new Departamento ("Atlantico");
		deptos [4] = new Departamento ("Bolivar");
		deptos [5] = new Departamento ("Boyaca");
		deptos [6] = new Departamento ("Caldas");
		deptos [7] = new Departamento ("Caqueta");
		deptos [8] = new Departamento ("Casanare");
		deptos [9] = new Departamento ("Cauca");
		deptos [10] = new Departamento ("Cesar");
		deptos [11] = new Departamento ("Choco");
		deptos [12] = new Departamento ("Cordoba");
		deptos [13] = new Departamento ("Cundinamarca");
		deptos [14] = new Departamento ("Guainia");
		deptos [15] = new Departamento ("Guajira");
		deptos [16] = new Departamento ("Guaviare");
		deptos [17] = new Departamento ("Huila");
		deptos [18] = new Departamento ("Magdalena");
		deptos [19] = new Departamento ("Meta");
		deptos [20] = new Departamento ("Narinio");
		deptos [21] = new Departamento ("Norte de Santander");
		deptos [22] = new Departamento ("Putumayo");
		deptos [23] = new Departamento ("Quindio");
		deptos [24] = new Departamento ("Risaralda");
		deptos [25] = new Departamento ("San andres y providencia");
		deptos [26] = new Departamento ("Santander");
		deptos [27] = new Departamento ("Sucre");
		deptos [28] = new Departamento ("Tolima");
		deptos [29] = new Departamento ("Valle del cauca");
		deptos [30] = new Departamento ("Vaupes");
		deptos [31] = new Departamento ("Vichada");
	
	}

	
public void registrarMunicipio(int x, String dp, int p, int cH, int cM, int aM, double eP, double iP)
{
	x -= 1;
	deptos[x].registrarMunicipios(dp,p,cH,cM,aM,eP,iP);
}

public void modificarDepartamento(Departamento [] deptos) {
	this.deptos = deptos; 
}
	
public void mostrarMun(int x){
	x -= 1;
	deptos[x].darMunicipios();
}

public Departamento[] darDepartamento() {
	return deptos; 
}
public String hayMIM(double valorIngresado) {
	
	double prom1 = 0;
	int cont = 0;
	String hay;
	
	for (int i = 0; i < deptos[NUMERO_DPTOS]; i++) {
		
		for (int j = 0; j < deptos[MUNICIPIOS]; j++) {
			if(deptos[i].darMunicipios()[j] != null) {
			prom1 += deptos[i].darMunicipios()[j].darIngresoPromedio();
				if(prom1>valorIngresado) {
					cont++;
				}
			}			
		}	
	}
		hay = "Existen "+cont+" municipios con un ingreso mayor a "+valorIngresado;
		return hay;
}
	
	
	
	

}