package modelo;

public class Municipio
{
	
	private String nombre;
	private int pobT;
	private int cantH;
	private int cantM;
	private int adultM;
	private double edadP;
	private double ingP;
	
	public Municipio(String dp, int p, int cH, int cM, int aM, double eP, double iP){
		nombre = dp;
		pobT = p;
		cantH = cH;
		cantM = cM;
		adultM = aM;
		edadP = eP;
		ingP = iP;
	}
	
	public String darNombre(){
		return nombre;
	}
	
		public int darPobT(){
		return pobT;
	}
	
	public int darCantH(){
		return cantH;
	}
	
	public int darCantM(){
		return cantM;
	}
	public int darAdultM(){
		return adultM;
	}
	
	public double darEdadP(){
		return edadP;
	}
	
	public double darIngrP(){
		return ingP;
	}
}