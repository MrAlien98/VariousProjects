package interfaz;

import java.util.Scanner;
import modelo.Dane;

public class Menu{
	
	private Dane dan;

public Menu(){

	dan = new Dane();
	opciones();

}

public void opciones(){
	Scanner leer = new Scanner (System.in);
	int op;
	String m = "1. Registrar municipio\n2. Mostrar municipio\n3. Consultar si un departamento tiene un ingreso superior a.... \n4. Consultar si un departamento tiene una poblacion igual a...\n5. Consultar censo nacional \n6. Consultar censo departamental \n7. Listar municipios \n8. Salir \n. Digite su opción: ";
	do{
		System.out.print("===============================\n"+m);
		op = leer.nextInt();
		switch(op){
			case 1:requerimiento1();
				break;
			case 2:requerimiento2();
				break;
			case 3:requerimiento3();
				break;
			case 4:requerimiento4();
				break;
			case 5:requerimiento5();
				break;
			case 6:requerimiento6();
				break;
			case 7:requerimiento7();
				break;
			case 8:System.out.println("\nS A L I O");
				break;
			default:System.out.println("Error en la opcion");
		}
	}
	while (op != 8);
}

//.equalsignorecase\\


public void requerimiento1(){
	Scanner leer = new Scanner (System.in);
	
	String m = "ingrese el departamento a el cual quiere usted asignarle municipios : \n1. Amazonas \t2. Antioquia \t3. Arauca \t4. Atlantico\t5. Bolivar\t6. Boyaca\n7. Caldas\t8. Caqueta\t9. Casanare\t10. Cauca\t11. Cesar\t12. Choco\t13. Cordoba\n14. Cundinamarca\t15. Guainia\t16. Guajira\t17.Guaviare\t18. Huila\t19. Magdalena\n20. Meta\t21. Nariño\t22. Norte de Santander\t23. Putumayo\t24. Quindio\t25. Risaralda\n26. San Andres y Providencia\t27. Santander\t28. Sucre\t29. Tolima\t30. Valle Del Cauca\n31. Vaupes\t32 Vichada : ";
	int dpt;
	
	do
	{
		System.out.print("===============================\n"+m);		
		dpt = leer.nextInt();
	}
	while(dpt > 32 || dpt <= 0);
	

	System.out.println("=================================\n DATOS DEL MUNICIPIO\n");
	System.out.println("INGRESE EL NOMBRE DEL MUNICIPIO : ");
	String nM = leer.nextLine();
	nM = leer.nextLine();
	System.out.println("INGRESE LA POBLACION TOTAL DEL MUNICIPIO : ");
	int pT = leer.nextInt();
	System.out.println("INGRESE LA CANTIDAD DE HOMBRES EN EL MUNICIPIO : ");
	int cH = leer.nextInt();
	System.out.println("INGRESE LA CANTIDAD DE MUJERES EN EL MUNICIPIO : ");
	int cM = leer.nextInt();
	System.out.println("INGRESE LA CANTIDAD DE ADULTOS MAYORES EN EL MUNICIPIO : ");
	int aM = leer.nextInt();
	System.out.println("INGRESE LA EDAD PROMEDIO DE EL MUNICIPIO : ");
	int eP = leer.nextInt();
	System.out.println("INGRESE EL INGRESO PROMEDIO DEL MUNICIPIO : ");
	double iP = leer.nextInt();
	System.out.println("\n");	
	
	dan.registrarMunicipio(dpt,nM,pT,cH,cM,aM,eP,iP);
}

public void requerimiento2(){
	Scanner leer = new Scanner (System.in);
	System.out.println("\n MOSTRAR MUNICIPIO\n");
	
	String m = "ingrese el departamento de el cual desea ver algun(os) municipio(os) : \n1. Amazonas \t2. Antioquia \t3. Arauca \t4. Atlantico\t5. Bolivar\t6. Boyaca\n7. Caldas\t8. Caqueta\t9. Casanare\t10. Cauca\t11. Cesar\t12. Choco\t13. Cordoba\n14. Cundinamarca\t15. Guainia\t16. Guajira\t17.Guaviare\t18. Huila\t19. Magdalena\n20. Meta\t21. Nariño\t22. Norte de Santander\t23. Putumayo\t24. Quindio\t25. Risaralda\n26. San Andres y Providencia\t27. Santander\t28. Sucre\t29. Tolima\t30. Valle Del Cauca\n31. Vaupes\t32 Vichada : ";
	int dpt;
	do
	{
		System.out.print("===============================\n"+m);		
		dpt = leer.nextInt();
	}
	while(dpt > 32 || dpt <= 0);
	
	dan.mostrarMun(dpt);
	System.out.println("\n");
	
	
}

public void requerimiento3(){
	Scanner leer = new Scanner (System.in);
	System.out.println("\n ");
	
	System.out.println("Ingrese un valor: ");
	double comp = leer.nextDouble();
	
	dan.hayMIM(comp);
	String hay = dan.hayMunicipioIngresoMayor(comp);
	
	System.out.println(hay);
	
}

public void requerimiento4(){
	System.out.println("\n Poblacion igual dpto");
}

public void requerimiento5(){
	System.out.println("\n Censo nacional");
}

public void requerimiento6(){
	System.out.println("\n Censo dptal");
}

public void requerimiento7(){
	System.out.println("\n Listar municipios");
}

public static void main(String [] args){
	Menu m = new Menu();
}












}