package mundo;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Entidad que representa la sección de recursos humanos encargado de hacer la selección de personal
 * @author Profesor Que Hizo El Lab x Victor Mora
 * @version 1.1 15/10/2017
 */
public class SeleccionDePersonal {
	/**
	* Esta constante representa el numero de zonas de reclutamiento que es el mismo que el numero de paises en la clase ZonaReclutamiento.
	*/
	public final static int MAX_ZONAS = ZonaReclutamiento.PAISES.length;
	
	public final static double PESO_COMUNICACION=0.30;
	public final static double PESO_LABORAL=0.15;
	public final static double PESO_TECNICA=0.35;
	public final static double PESO_ACTITUD=0.2;
	

	/**
	* Esta constante representa el umbral minimo que deben tener los candidatos para no ser rechazdos.
	*/
	public final static double UMBRAL = 3.5;
	
	private ZonaReclutamiento[] zonasRecluta;
	

/**
* Este metodo inicializa los valores de la clase SeleccionDePersonal.
* post: Se inicializa el arreglo zonasReluta.
*/
	public SeleccionDePersonal(){
		zonasRecluta = new ZonaReclutamiento[MAX_ZONAS]; 
	}
	

	/**
	* Este metodo agrega un nuevo objeto a el arreglo zonasRecluta.
	* @param k Posicion de la nueva zona en el arreglo. k!=null. k>0.
	* @param nombrePais Nombre de la nueva zona. nombrePais!=null. nombrePais!="".
	* post: Se agrega un nuevo objeto al arreglo zonasRecluta.
	*/
	public void agregarNuevaZona(int k, String nombrePais){
		zonasRecluta[k] = new ZonaReclutamiento(nombrePais);
	}
	

	/**
	* Este metodo envia los parametros de un nuevo candidato a el metodo AgregarCandidato en la clase ZonaReclutamiento
	* @param ident Identificacion del nuevo candidato. ident!=null. ident!=¨¨.
	* @param nom Nombre del nuevo candidato. no!=null. nom!=¨¨.
	* @param ape Apellido del nuevo candidato. ape!=null. ape!=¨¨.
	* @param sx Sexo del nuevo candidato. sx=F ó sx=M. sx!=null.
	* @param hc Habilidades de comunicacion del nuevo candidato. hc!=null. hc>=0.
	* @param hl Historial laboral del nuevo candidato. hl!=null. hl>=0.
	* @param ct Competencia tecnica del nuevo candidato. ct!=null. ct>=0.
	* @param a Actitud del nuevo candidato. a!=null. a>=0.
	* post 
	*/
	public void agregarCandidato(int k, String ident, String nom, String ape, char sx, double hc, double hl, double ct, double a){
		zonasRecluta[k].agregarCandidato(ident, nom, ape, sx, hc, hl, ct, a);
	}
	
	public double calcularCalificacionCandidato(Candidato cand){
		double caliCandi = 0;
		caliCandi = PESO_COMUNICACION*cand.darHabilidadesComunicacion()
				  + PESO_LABORAL*cand.darHabilidadesComunicacion()
				  + PESO_TECNICA*cand.darCompetenciaTecnica()
				  + PESO_ACTITUD*cand.darActitud();
		return caliCandi;
	}
	

	/**
	* Este metodo cuenta los candidatos cuya calificacion supera el umbral y los retorna.
	* @param zr Zona de reclutamiento a evaluar. zr!=null.
	* @return cantidad de candidatos cuya puntuacion supera el umbral. 
	*/
	public int contarCandidatosSuperanUmbral(ZonaReclutamiento zr){
	int cantidad = 0;
	
	ArrayList<Candidato> cands = zr.darCandidatos();
		for (int i = 0; i < cands.size(); i++) {
			if(calcularCalificacionCandidato(cands.get(i))>=UMBRAL){
				cantidad++;
			}
		}
		
		return cantidad;
	}
	
	public String encontrarZonaConMasCandidatosSuperanUmbral(){
		ZonaReclutamiento zonaR = null;
		int masCandidatos = -1;
		for (int i = 0; i < zonasRecluta.length; i++) {
			ZonaReclutamiento zore = zonasRecluta[i];
			int cantidadSuperan = contarCandidatosSuperanUmbral(zore);
			if(masCandidatos<cantidadSuperan){
				zonaR = zore;
				masCandidatos = cantidadSuperan;
			}
		}
		
		return zonaR.darPais()+" con "+masCandidatos+" de un total de "+zonaR.darCandidatos().size();
	}
	

	/**
	* Este metodo calcula el porcentaje de mujeres en las zonas de reclutamiento.
	* pre: El arreglo zonasRecluta debe haberse inicializado y tener al menos un elemento.
	* pre: el arreglo misCandidatos debe haberse inicializado y tener al menos un elemento.
	* @return promedio de mujeres en las zonas de reclutamiento.
	*/
	public double calcularPorcentajeTotalMujeres(){
		int totalCandidatos = 0;
		int totalMujeres = 0;
		for (int i = 0; i < zonasRecluta.length; i++) {
			ZonaReclutamiento zonrec = zonasRecluta[i];
			ArrayList<Candidato> misCandidatos = zonrec.darCandidatos();
			totalCandidatos += misCandidatos.size();
			for (int j = 0; j < misCandidatos.size(); j++) {
				if(misCandidatos.get(j).darSexo()==ZonaReclutamiento.FEMENINO){
					totalMujeres += 1;
				}
			}
		}
		
		double porcentaje= (totalMujeres*100.0)/totalCandidatos;
		return porcentaje;
	}
	

	/**
	* Este metodo calcula el total de candidatos en las zonas de reclutamiento.
	* pre: El arreglo zonasRecluta debe haberse inicializado y tener al menos un elemento.
	* @return La el total de candidatos en el arreglo zonasRecluta.
	*/
	public int calcularTotalCandidatos(){
		int totalCand = 0;
		for (int i = 0; i < zonasRecluta.length; i++) {
			totalCand += zonasRecluta[i].darCandidatos().size();
		}
		return totalCand;
	}
	

	/**
	* Este metodo calcula el promedio total de candidatos en las zonas de reclutamiento
	* pre: El arreglo zonasRecluta debe haberse inicializado y tener al menos un elemento.
	* @return 
	*/
	public double calcularPromedioTotalCandidatos(){
		double prom = 0;
		for (int i = 0; i < zonasRecluta.length; i++) {
			prom += zonasRecluta[i].calcularPromedioCandidatos();
		}
		prom = prom / zonasRecluta.length;
		return prom;
	}
	
	public String hacerFiltradoEspecial(){
		
		String reporte = "";
		reporte += "["+calcularTotalCandidatos()+"]";
		
		for (int i = 0; i < zonasRecluta.length; i++) {
			zonasRecluta[i].filtrarPorActitud();
		}
		
		reporte += " [" + calcularTotalCandidatos()+"]";
		
		for (int i = 0; i < zonasRecluta.length; i++) {
			zonasRecluta[i].aplicarBonificacion();
		}
		
		double promTotal = calcularPromedioTotalCandidatos();
		
		for (int i = 0; i < zonasRecluta.length; i++) {
			zonasRecluta[i].filtrarMenoresAValor(promTotal);
		}
		
		reporte += " [" + calcularTotalCandidatos()+"]";
		
		DecimalFormat df = new DecimalFormat("0.0#");
		reporte += " ("+df.format(promTotal)+")";
		
		return reporte;
	}
	
	public ZonaReclutamiento[] darZonaReclutamientos(){
		return zonasRecluta;
		
	}
}
