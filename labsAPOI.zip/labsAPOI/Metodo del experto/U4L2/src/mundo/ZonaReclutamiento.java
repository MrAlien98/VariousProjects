package mundo;

import java.util.ArrayList;

/**
 * Entidad que representa una zona geográfica de reclutamiento de personal
 * @author Profesor Que Hizo El Lab x Victor Mora
 * @version 1.1 15/10/2017
 */
public class ZonaReclutamiento {
	public final static String[] PAISES = {"COLOMBIA","VENEZUELA","ARGENTINA","BRASIL","MÉXICO","CHILE"};
	
	private String pais;
	
	private ArrayList<Candidato> candidatos;


/**
* Este metodo inicializa los valores de la clase ZonaReclutamiento.
* post: Se inicializa el arreglo de candidatos.
* @param p != null. p != ¨¨.
*/
	public ZonaReclutamiento(String p) {
		pais = p;
		candidatos = new ArrayList<>();
	}

	/**
	* Agrega un candidato al arreglo candidatos.
	* pre: el arreglo candidatos debe haberse inicializado.
	* @param ident Identificacion del nuevo candidato. ident!=null. ident!=¨¨.
	* @param nom Nombre del nuevo candidato. no!=null. nom!=¨¨.
	* @param ape Apellido del nuevo candidato. ape!=null. ape!=¨¨.
	* @param sx Sexo del nuevo candidato. sx=F ó sx=M. sx!=null.
	* @param hc Habilidades de comunicacion del nuevo candidato. hc!=null. hc>=0.
	* @param hl Historial laboral del nuevo candidato. hl!=null. hl>=0.
	* @param ct Competencia tecnica del nuevo candidato. ct!=null. ct>=0.
	* @param a Actitud del nuevo candidato. a!=null. a>=0.
	* post: Se agrega un nuevo objeto al arreglo candidato.
	*/
	public void agregarCandidato(String ident, String nom, String ape, char sx, double hc, double hl, double ct, double a){
		Candidato nuevo = new Candidato(ident, nom, ape, sx, hc, hl, ct, a);
		candidatos.add(nuevo);
	}
	


	/**
	* Calcula el promedio de candidatos.
	* pre: el arreglo candidatos debe haberse inicializado y tener al menos un elemento.
	* post: se calcula el promedio de candidatos.
	* @return el promedio de los candidatos.
	*/
	public double calcularPromedioCandidatos(){
		double prom = 0;
		SeleccionDePersonal sdp = new SeleccionDePersonal();
		for (int i = 0; i < candidatos.size(); i++) {
			prom += sdp.calcularCalificacionCandidato(candidatos.get(i));
		}
		if(candidatos.size()>0){
			prom = prom / candidatos.size(); 
		}
		return prom;
	}
	

	/**
	* Este metodo elimina a los candidatos cuya actitud no supero o iguala el umbral
	* 
	*/
	public void filtrarPorActitud(){	
		int i=0;
		while(i < candidatos.size()){
			if(candidatos.get(i).darActitud()<SeleccionDePersonal.UMBRAL){
				candidatos.remove(i);
			}else{
				i++;
			}
		}
	}
	
	public void aplicarBonificacion(){
		for (int i = 0; i < candidatos.size(); i++) {
			Candidato c = candidatos.get(i);
			c.cambiarHabilidadesComunicacion(c.darHabilidadesComunicacion()+0.5);
			c.cambiarHistoriaLaboral(c.darHistoriaLaboral()+0.5);
			c.cambiarCompetenciaTecnica(c.darCompetenciaTecnica()+0.5);
			c.cambiarActitud(c.darActitud()+0.5);
		}
	}
	

	/**
	* Devuelve el arreglo candidatos.
	* pre: El arreglo candidatos debe haberse inicializado y tener al menos un elemento.
	* @return el arreglo candidatos
	*/
	public ArrayList<Candidato> darCandidatos(){
		return candidatos;
	}
	

	/**
	* Devuelve el arreglo paises.
	* pre: El arreglo paises debe haberse inicializado y tener al menos un objeto.
	* @return el arreglo paises
	*/
	public String darPais(){
		return pais;
	}


	/**
	*
	*/
	public void filtrarMenoresAValor(double valor) {
		int i=0;
		SeleccionDePersonal sdp = new SeleccionDePersonal();
		while(i < candidatos.size()){
			Candidato c = candidatos.get(i);
			double promCandidatoActual = sdp.calcularCalificacionCandidato(c);
			if(promCandidatoActual<valor){
				candidatos.remove(i);
			}else{
				i++;
			}
		}		
	}
}
