package mundo;

/**
 * Entidad que representa a una persona que aspira a ser contratada por una empresa a través de un proceso de selección
 * @author Profesor Que Hizo El Lab x Victor Mora
 * @version 1.1 15/10/2017
 */
public class Candidato {
	/**
	* Esta constante representa el el genero femenino que puede o no tener un candidato
	*/
	public final static char FEMENINO = 'F';

	/**
	* Esta constante representa el el genero masculino que puede o no tener un candidato
	*/
	public final static char MASCULINO = 'M';


	/**
	* Este atributo representa la identificacion del candidato.
	*/
	private String id;

	/**
	* Este atributo representa el/los nombre/s del candidato.
	*/
	private String nombres;

	/**
	* Este atributo representa los apellidos del cancidato
	*/
	private String apellidos;

	/**
	* Este atributo representa el sexo del candidato.
	*/
	private char sexo;

	/**
	* Este atributo representa las habilidades de comunicacion del candidato.
	*/
	private double habilidadesComunicacion;

	/**
	* Este atributo representa el historial laboral del candidato.
	*/
	private double historiaLaboral;

	/**
	* Este atributo representa la competencia tecnica del candidato.
	*/
	private double competenciaTecnica;

	/**
	* Este atributo representa la actitud del candidato.
	*/
	private double actitud;
	

/**
* Este metodo inicializa los valores de la clase Candidato.
* @param ident Identificacion del nuevo candidato. ident!=null. ident!=¨¨.
* @param nom Nombre del nuevo candidato. no!=null. nom!=¨¨.
* @param ape Apellido del nuevo candidato. ape!=null. ape!=¨¨.
* @param sx Sexo del nuevo candidato. sx=F ó sx=M. sx!=null.
* @param hc Habilidades de comunicacion del nuevo candidato. hc!=null. hc>=0.
* @param hl Historial laboral del nuevo candidato. hl!=null. hl>=0.
* @param ct Competencia tecnica del nuevo candidato. ct!=null. ct>=0.
* @param a Actitud del nuevo candidato. a!=null. a>=0.
*/
	public Candidato(String ident, String nom, String ape, char sx, double hc, double hl, double ct, double a){
		id = ident;
		nombres = nom;
		apellidos = ape;
		sexo = sx;
		habilidadesComunicacion = hc;
		historiaLaboral = hl;
		competenciaTecnica = ct;
		actitud = a;
	}
	

	/**
	* Este metodo devuelve la identificacion de un candidato.
	* pre: la identificacion debe haberse inicializado.
	* @return identificacion del candidato.
	*/
	public String darId() {
		return id;
	}
	

	/**
	* Este metodo devuelve los nombres de un candidato.
	* pre: los nombres deben haberse inicializado.
	* @return nombres del candidato.
	*/
	public String darNombres() {
		return nombres;
	}
	

	/**
	* Este metodo devuelve los apellidos de un candidato.
	* pre: los apellidos debe haberse inicializado.
	* @return apellidos del candidato.
	*/
	public String darApellidos() {
		return apellidos;
	}
	

	/**
	* Este metodo devuelve el sexo de un candidato.
	* pre: el sexo debe haberse inicializado.
	* @return sexo del candidato.
	*/
	public char darSexo(){
		return sexo;
	}
	

	/**
	* Este metodo devuelve las habilidades de comunicacion de un candidato.
	* pre: las habilidades de comunicacion debe haberse inicializado.
	* @return habilidades de comunicacion del candidato.
	*/
	public double darHabilidadesComunicacion() {
		return habilidadesComunicacion;
	}
	

	/**
	* Este metodo devuelve el historial laboral de un candidato.
	* pre: el historial laboral debe haberse inicializado.
	* @return el historial laboral del candidato.
	*/
	public double darHistoriaLaboral() {
		return historiaLaboral;
	}
	

	/**
	* Este metodo devuelve la competencia tecnica de un candidato.
	* pre: la competencia tecnica debe haberse inicializado.
	* @return la competencia tecnica del candidato.
	*/
	public double darCompetenciaTecnica() {
		return competenciaTecnica;
	}
	

	/**
	* Este metodo devuelve la actitud de un candidato.
	* pre: la actitud debe haberse inicializado.
	* @return actitud del candidato.
	*/
	public double darActitud() {
		return actitud;
	}
	

	/**
	* Este metodo modifica las habilidades de comunicacion de un candidato.
	* @param hc Nuevas habilidades de comunicacion del candidato. hc!=null. hc>=0.
	* post: las habilidades de comunicacion del candidato se modifican.
	*/
	public void cambiarHabilidadesComunicacion(double hc){
		habilidadesComunicacion = hc;
		if(habilidadesComunicacion>5){
			habilidadesComunicacion = 5;
		}
	}
	

	/**
	* Este metodo modifica el historial laboral de un candidato.
	* @param hl Nuevo historial laboral de un candidato. hl!=null. hl>=0.
	* post: el historial laboral del candidato se modifica.
	*/
	public void cambiarHistoriaLaboral(double hl){
		historiaLaboral = hl;
		if(historiaLaboral>5){
			historiaLaboral = 5;
		}
	}
	

	/**
	* Este metodo modifica la competencia tecnica de un candidato.
	* @param ct Nueva competencia tecnica de un candidato. ct!=null. ct>=0.
	* post: la competencia tecnica del candidato se modifica.
	*/
	public void cambiarCompetenciaTecnica(double ct){
		competenciaTecnica = ct;
		if(competenciaTecnica>5){
			competenciaTecnica = 5;
		}
	}
	

	/**
	* Este metodo modifica la actitud de un candidato.
	* @param a Nueva actitud de un candidato. a!=null. a>=0.
	* post: La actitud del candidato se modifican.
	*/
	public void cambiarActitud(double a){
		actitud = a;
		if(actitud>5){
			actitud = 5;
		}
	}
}
