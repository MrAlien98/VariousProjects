package mundo;

/**
 * Implementa la clase Letra
 * @author Prof. Jojoa
 * @version 1.0 20/10/2017
 *
*/
public class Letra {

	// Atributos
	private char caracter;
	
	/**
	 * Construye una Letra <br>
	 * <b>post: </b> Se construye una letra con un caracter dado
	 * @param caracter - caracter representado por la Letra
	 */
	public Letra(char caracter){
		this.caracter = caracter;
	}

	//m�todos dar y cambiar
	public char darCaracter() {
		return caracter;
	}

	public void cambiarCaracter(char caracter) {
		this.caracter = caracter;
	}

	
}
