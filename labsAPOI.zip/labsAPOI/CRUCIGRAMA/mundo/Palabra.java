package mundo;

/**
 * Implementa la clase Palabra
 * @author Prof. Jojoa 
 * @version 1.0 20/10/2017
 * 
*/

public class Palabra {

	// Atributos
	private Letra[] letras;

	/**
	 * Construye una palabra <br>
	 * <b>post: </b> Se construyó la palabra, inicializando el arreglo de letras
	 * y llenandolo, con los caracteres de la palabra
	 * @param palabra - Cadena con la palabra
	 */
	public Palabra(String palabra) {
		letras = new Letra[palabra.length()];
		char[] letricas = palabra.toCharArray();
		for (int i = 0; i < letricas.length; i++) {
			letras[i] = new Letra(letricas[i]);
		}
	}

	// Método dar
	public Letra[] darLetras() {
		return letras;
	}

}
