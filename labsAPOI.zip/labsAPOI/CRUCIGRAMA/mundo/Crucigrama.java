package mundo;

import java.util.ArrayList;

/**
 * Implementa la clase Crucigrama.
 * @author prof. Jojoa x Victor Mora.
 * @version 2.0 25/10/2017
 * 
*/
public class Crucigrama {

	// Atributos
	// Matriz de caracteres que componen el crucigrama
	private Letra[][] caracteres;

	// Lista de respuestas del crucigrama
	private ArrayList<Palabra> respuestas;

	// Lista de respuestas correctas del crucigrama
	private ArrayList<Palabra> encontradas;

	// Lista de preguntas verticales del crucigrama
	private ArrayList<String> preguntasV;

	// Lista de preguntas horizontales del crucigrama
	private ArrayList<String> preguntasH;

	// -----------------------------------------------------------------
	// Constructores
	// -----------------------------------------------------------------

	/**
	 * Construye un crucigrama <br>
	 * <b>post: </b> Se construyó un crucigrama, inicializando las listas y la
	 * matriz de Letras
	 */
	public Crucigrama() {

		caracteres = new Letra[10][23];
		respuestas = new ArrayList<Palabra>();
		encontradas = new ArrayList<Palabra>();
		preguntasH = new ArrayList<String>();
		preguntasV = new ArrayList<String>();

	}

	// Métodos dar
	public Letra[][] darCaracteres() {
		return caracteres;
	}

	public ArrayList<Palabra> darRespuestas() {
		return respuestas;
	}

	public ArrayList<String> darPreguntasV() {
		return preguntasV;
	}

	public ArrayList<String> darPreguntasH() {
		return preguntasH;
	}

	/**
	 * Este método permite cargar la matriz de letras con los caracteres leídos
	 * del archivo, en una fila y columna especifica <br>
	 * <b>post: </b> La matriz de caracteres ha sido llenada
	 * 
	 * @param fila
	 *            - Es un entero que indica la fila
	 * @param col
	 *            - Es un entero que incida la columna
	 * @param caracter
	 *            - Es una char con el caracter leido del crucigrama
	 * 
	 */
	public void cargarMatriz(int fila, int col, char caracter) {
		caracteres[fila][col] = new Letra(caracter);
	}

	/**
	 * Este método permite cargar la lista de las preguntas horizontales y
	 * verticales. <br>
	 * <b>post: </b> La lista de preguntas verticales y horizontales han sido
	 * actualizadas
	 * 
	 * @param tipo
	 *            - Es un entero que indica si la pregunta es horizontal o
	 *            vertical
	 * @param pregunta
	 *            - cadena con la pregunta
	 */
	public void cargarPreguntas(int tipo, String pregunta) {
		switch (tipo) {
		case 'H':
			preguntasH.add(pregunta);
			break;
		case 'V':
			preguntasV.add(pregunta);
			break;
		}
	}

	/**
	 * Este método permite cargar la lista con las respuestas correctas del
	 * crucigrama. <br>
	 * <b>post: </b> La lista de respuestas ha sido actualizada
	 * 
	 * @param palabra
	 *            - cadena con la respuesta a guardar
	 */
	public void cargarRespuestas(String palabra) {
		respuestas.add(new Palabra(palabra));
	}

	/**
	 * Este método permite validar si el juego esta terminado. El juego se
	 * termina cuando se han encontrado la totalidad de las respuestas, que son
	 * almacenadas en la lista de encontradas. <br>
	 * 
	 * @return Retorna un boolean indicando si el juego se terminó
	 */
	public boolean estaTerminado(){
		if(encontradas.size() == respuestas.size())
		{
			return true;
		}else{
			return false;
		}
	}

	/**
	 * Este método sirve para buscar en la pregunta especificada por el usuario,
	 * si la respuesta dada es correcta. <br>
	 * <b>post: </b> La lista de palabras encontradas se actualizó con la
	 * respuesta correcta
	 * 
	 * @param pregunta
	 *            - Es un entero con la pregunta seleccionada por el usuario y
	 *            la cual va a buscar la respuesta
	 * @param respuesta
	 *            - Es una cadena con la respuesta digitada por el usuario
	 * @return Retorna un mensaje indicando si la respuesta es incorrecta o
	 *         correcta
	 */
	public String buscarRespuesta(int pregunta, String respuesta){
		pregunta-=1;
		String x="";
		String palabra="";
		for(int i=0;i<respuestas.get(pregunta).darLetras().length;i++){
			palabra+=respuestas.get(pregunta).darLetras()[i].darCaracter();
		}
		if(palabra.equalsIgnoreCase(respuesta)){
			encontradas.add(new Palabra(respuesta));
			x="Correcta";
		}else{
			x="Incorrecta";
		}
		return x;
	}

	/**
	 * Este método permite actualizar la matriz de caracteres del crucigrama,
	 * con las respuestas correctas dadas por el usuario. debe tener en cuenta
	 * si la pregunta es vertical u horizontal <br>
	 * <b>post: </b> La matriz de caracteres ha sido actualizada
	 * 
	 * @param pregunta
	 *            - Es un entero con la pregunta seleccionada por el usuario,
	 *            para buscarla en la matriz y actualizarla con la respuesta
	 * 
	 * @param respuesta
	 *            - Es una cadena con la respuesta correcta
	 * @param tipo
	 *            - Es un entero con el tipo de la pregunta, 1 si es horizontal,
	 *            2 si es vertical
	 * 
	 */
	public void actualizarCrucigrama(int pregunta, String respuesta, int tipo){
		char pp='0';
		if(pregunta>=10 && pregunta<=14){
			switch(pregunta){
				case 10: pp = 'A';
						 break;
				case 11:pp = 'B';
						 break;
				case 12:pp = 'C';
						 break;
				case 13:pp = 'D';
						 break;
				case 14:pp = 'E';
						 break;
				default: System.out.print("\n=========================Error en la opcion.=========================\n");
			}
		}
		else{
			String p = String.valueOf(pregunta);
			pp = p.charAt(0);
		}
		int x = -1;
		int y = -1;
		for(int f=0;f<caracteres.length;f++){
			for(int c=0;c<caracteres[0].length;c++){
				if(caracteres[f][c].darCaracter() == pp){
					x = f;
					y = c;
				}
			}
		}

		//System.out.println(""+x+y);
		if(x!=-1){
			int i;
			if(tipo == 1){
				i=x;
			}else{
				i=y;
			}
			for(int cont =0;cont<respuesta.length();i++,cont++){
				Letra obj = new Letra(respuesta.charAt(cont));
				if(tipo == 1){
					caracteres[i][y] = obj;
				}else{
					caracteres[x][i] = obj;
				}
			}
		}	
	}
	

/**
* Este metodo hace una lista de los elementos en la matriz
* caracteres y lo muestra a el usuario
* pre: la matriz caracteres debe haberse inicializado 
* post: Se crea el listado de los elemento y se lo muestra a el usuario
* @return listado de elementos en la matriz caracteres ordenado en columnas y filas
*/
	public String mostrarCrucigrama(){
		String c ="";

		for(int l=0;l<caracteres.length;l++){
			for(int j=0;j<caracteres[l].length;j++){
				c+=caracteres[l][j].darCaracter();
			}
			c+="\n";
		}
		return c;
	}


}