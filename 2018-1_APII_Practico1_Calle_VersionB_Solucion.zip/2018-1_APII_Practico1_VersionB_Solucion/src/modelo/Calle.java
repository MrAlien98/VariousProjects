package modelo;

public class Calle {
	private Vehiculo[][] vehiculos;
	
	public Calle() {
		vehiculos = new Vehiculo[][] {
			new Vehiculo[] {
					null,
					new Vehiculo(Vehiculo.MOTO),
					null,
					new Vehiculo(Vehiculo.AUTOMOVIL),
					null,
					null,
					new Vehiculo(Vehiculo.MOTO),
					null,
					null					
			},
			new Vehiculo[] {
					new Vehiculo(Vehiculo.AUTOMOVIL),
					null,
					new Vehiculo(Vehiculo.AUTOMOVIL),
					null,
					new Vehiculo(Vehiculo.MOTO),
					null,
					null,
					new Vehiculo(Vehiculo.AUTOMOVIL),
					new Vehiculo(Vehiculo.AUTOMOVIL)					
			}
		};
		
	}
	
	public int[][] darVehiculos(){
		int[][] vs = new int[vehiculos.length][vehiculos[0].length];
		for (int i = 0; i < vs.length; i++) {
			for (int j = 0; j < vs[i].length; j++) {
				if(vehiculos[i][j]!=null) {
					vs[i][j] = vehiculos[i][j].darTipo();
				}
			}
		}
		return vs;
	}
	
	public void moverVehiculos() throws MovimientoSinVehiculoException {
		boolean hayVehiculos = false;
		for (int i = 0; i < vehiculos.length; i++) {
			for (int j = 0; j < vehiculos[i].length-1; j++) {
				if(vehiculos[i][j]!=null) {
					hayVehiculos = true;
				}
				vehiculos[i][j] = vehiculos[i][j+1];
			}
			if(vehiculos[i][vehiculos[i].length-1]!=null) {
				hayVehiculos = true;
			}
			vehiculos[i][vehiculos[i].length-1] = null;
		}
		if(!hayVehiculos) {
			throw new MovimientoSinVehiculoException("La calle no tiene vehiculos", vehiculos.length, vehiculos[0].length);
		}
	}
}
