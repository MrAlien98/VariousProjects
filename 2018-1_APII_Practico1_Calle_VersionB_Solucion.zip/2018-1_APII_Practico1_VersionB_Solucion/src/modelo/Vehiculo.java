package modelo;

public class Vehiculo {
	public final static int AUTOMOVIL = 1;
	public final static int MOTO = 2;
	
	private int tipo;
	
	public Vehiculo(int t) {
		tipo = t;
	}
	
	public int darTipo() {
		return tipo;
	}
}
