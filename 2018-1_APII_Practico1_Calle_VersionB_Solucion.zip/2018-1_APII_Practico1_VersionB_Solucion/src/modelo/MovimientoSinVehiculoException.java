package modelo;

@SuppressWarnings("serial")
public class MovimientoSinVehiculoException extends Exception{
	private int cantidadCarriles;
	private int longitudVia;
	
	public MovimientoSinVehiculoException(String msg, int carriles, int longitud) {
		super(msg);
		cantidadCarriles = carriles;
		longitudVia = longitud;
	}
	
	public int darCantidadCarriles() {
		return cantidadCarriles;
	}
	
	public int darLongitudVia() {
		return longitudVia;
	}
}
