package interfaz;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import modelo.Calle;
import modelo.MovimientoSinVehiculoException;

@SuppressWarnings("serial")
public class VentanaCalle extends JFrame{
	private Calle miCalle;
	private PanelVehiculos panelVehiculos;
	private PanelOpciones panelOpciones;
	
	public VentanaCalle() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Calle :: Secretaria de Transito Municipal");
		setLayout(new BorderLayout());
		
		miCalle = new Calle();
		
		panelVehiculos = new PanelVehiculos();
		panelOpciones = new PanelOpciones(this);
		
		add(panelVehiculos, BorderLayout.CENTER);
		add(panelOpciones, BorderLayout.SOUTH);
		
		int[][] vs = miCalle.darVehiculos();
		panelVehiculos.refrescar(vs);
		pack();
	}
	
	public void moverVehiculos() {
		try {
			
			miCalle.moverVehiculos();
			int[][] vs = miCalle.darVehiculos();
			panelVehiculos.refrescar(vs);
			revalidate();
			//JOptionPane.showMessageDialog(this, "El nuevo vehiculo fue agregado exitosamente!");
			
		} catch (MovimientoSinVehiculoException e) {
			
			JOptionPane.showMessageDialog(this, "No se pudieron mover los vehiculos.\n"+e.getMessage()+"\n#Carriles:"+e.darCantidadCarriles()+", Longitud:"+e.darLongitudVia());
			
		}
	}
	
	public static void main(String[] args) {
		VentanaCalle vc = new VentanaCalle();
		vc.setVisible(true);
	}
}
