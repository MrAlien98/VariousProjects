package interfaz;

import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class PanelVehiculos extends JPanel{
	private JLabel[][] labsVehiculos;
	public PanelVehiculos() {
		setBorder(new TitledBorder("Vehiculos"));		
	}
	
	public void refrescar(int[][] vehiculos) {
		removeAll();
		setLayout(new GridLayout(vehiculos.length, vehiculos[0].length));
		labsVehiculos = new JLabel[vehiculos.length][vehiculos[0].length];
		for (int i = 0; i < vehiculos.length; i++) {
			for (int j = 0; j < vehiculos[i].length; j++) {
				if(vehiculos[i][j]==1) {
					labsVehiculos[i][j] = new JLabel(new ImageIcon("imgs/CARRO.png"));
				}else if(vehiculos[i][j]==2) {
					labsVehiculos[i][j] = new JLabel(new ImageIcon("imgs/MOTO.png"));
				}else {
					labsVehiculos[i][j] = new JLabel(new ImageIcon("imgs/SIN_VEHICULO.png"));
				}
				
				add(labsVehiculos[i][j]);
			}
		}
		revalidate();
	}
}
