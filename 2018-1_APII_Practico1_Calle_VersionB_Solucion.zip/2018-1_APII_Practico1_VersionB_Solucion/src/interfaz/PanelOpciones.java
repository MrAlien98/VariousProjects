package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class PanelOpciones extends JPanel implements ActionListener{
	private JButton butMover;
	private VentanaCalle principal;
	public final static String MOVER = "MOVER"; 
	
	public PanelOpciones(VentanaCalle ventana) {
		principal = ventana;
		setBorder(new TitledBorder("Opciones"));
		setLayout(new GridLayout(1,1));
		butMover = new JButton("Mover Vehiculos");
		add(butMover);
		
		butMover.addActionListener(this);
		butMover.setActionCommand(MOVER);
	}

	@Override
	public void actionPerformed(ActionEvent evt) {
		String comando = evt.getActionCommand();
		if(comando.equals(MOVER)) {
			principal.moverVehiculos();
		}
	}
}
