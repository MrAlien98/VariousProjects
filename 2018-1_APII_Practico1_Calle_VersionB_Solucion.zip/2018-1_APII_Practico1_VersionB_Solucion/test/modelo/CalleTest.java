package modelo;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalleTest {
	private Calle c;
	public void configurarEscenario() {
		c = new Calle();
	}
	
	@Test
	public void testMoverVehiculosCorrectamente() {
		configurarEscenario();
		try {
			int[][] vsAntes = c.darVehiculos();
			c.moverVehiculos();
			int[][] vsDespues = c.darVehiculos();
			boolean coinciden = true;
			for (int i = 0; i < vsDespues.length; i++) {
				for (int j = 0; j < vsDespues[i].length-1; j++) {
					if(vsDespues[i][j]!=vsAntes[i][j+1]) {
						System.out.println("i:"+i+", j:"+j+"\n");
						coinciden = false;
					}
				}
				if(vsDespues[i][vsDespues[i].length-1]!=0) {
					System.out.println("*i:"+i+", j:"+(vsDespues.length-1)+"\n");
					coinciden = false;
				}
			}
			assertTrue("El nuevo estado de la calle debe ser el mismo que antes de mover pero corrido una columna a la izquierda", coinciden);
		}catch (MovimientoSinVehiculoException exc) {
			fail("No deberia generar excepcion ya que los datos son validos");
		}
	}

	@Test
	public void testMoverCalleSinVehiculos() {
		configurarEscenario();
		int[][] vs = c.darVehiculos();
		try {
			for (int i = 0; i < vs[0].length; i++) {
				c.moverVehiculos(); //estas no deben generar excepcion
			}
			assertTrue("No se genera una excepcion cuando se mueven todos los vehiculos de la calle con al menos un vehiculo", true);
			
			c.moverVehiculos(); //en este llamado si SE DEBE GENERAR UNA EXCEPCION
			
			fail("Debe generar excepcion ya que se intenta mover los vehiculos de una calle sin carros");
		}catch (MovimientoSinVehiculoException exc) {
			assertTrue("Se genera una excepcion cuando se intenta mover los vehiculos de una calle sin carros", true);
		}
	}

}
