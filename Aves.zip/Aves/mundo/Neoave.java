package mundo;

public class Neoave extends Neognato implements InterfaceVuelo{

	private double longPatas;
	private int dedosPatas;

	public Neoave(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo, double longPatas, int dedosPatas){
		super(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo);

		this.longPatas=longPatas;
		this.dedosPatas=dedosPatas;
	}

	public double darLongPatas(){
		return longPatas;
	}

	public void modificarLongPatas(double longPatas){
		this.longPatas=longPatas;
	}

	public int darDedosPatas(){
		return dedosPatas;
	}

	public void modificarDedosPatas(int dedosPatas){
		this.dedosPatas=dedosPatas;
	}
	
	public double calcularAlturaMaxima() {
		double alturaMaxima=(darAltura()*(super.darHuesosPatas()/100));
		return alturaMaxima;
	}
	
	public double velVuelo() {
		double velocidadV= (super.darDensOsea()*(super.darLongDedo()/100));
		return velocidadV;
	}
	
	public boolean esMigratoria() {
		if(super.darRangoMetabolico()==2 && velVuelo()<100) {
			return true;
		}
		return false;
	}
}