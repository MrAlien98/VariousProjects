package mundo;
import java.util.*;

public class Estudio{
	
	private ArrayList<Neornithe> aves;

	public Estudio(){
		aves=new ArrayList<Neornithe>();
		
		agregarAve("kiwi", "negro", 15.0, 50.5, 60.8, 3, 30.0,10,15.0);
		agregarAve("avestruz", "azul", 20.0, 10.5, 20.6, 2, 7.0, 1, 2);
		
	}

	public ArrayList<Neornithe> darAves(){
		return aves;
	}

	//Tinamu
	public void agregarAve(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPaladar, double velTierra){
		aves.add(new Tinamu(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPaladar, velTierra));
	}

	//Ratite
	public void agregarAve(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPaladar, int quilla){
		aves.add(new Ratite(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPaladar, quilla));
	}
	//Galloanserae
	public void agregarAve(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo, int tipo, int repro){
		aves.add(new Galloanserae(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, tipo, repro));
	}
	
	//Neonaves
	public void agregarAveN(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo, double longPatas, int dedosPatas){
		aves.add(new Neoave(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, longPatas, dedosPatas));
	}

	public void agregarAveP(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo, double longPatas, int dedosPatas){
		aves.add(new Passeriforme(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, longPatas, dedosPatas));
	}

	public String listarAves(){
		String listaAves="Lista de Aves registrados\n";
		for(int i=0;i<aves.size();i++){
			Neornithe save=aves.get(i);
			listaAves+=(i+1)+". "+save.darNombre()+"\n";
		}
		return listaAves;
	}


	public boolean consultarAveMigratoria(int a){
		a-=1;
		if(aves.get(a) instanceof Tinamu){
			Tinamu save=(Tinamu)aves.get(a);
			if(save.esMigratoria()==true){
				return true;
			}
		}else if(aves.get(a) instanceof Neoave){
			Neoave save=(Neoave)aves.get(a);
			if(save.esMigratoria()==true){
				return true;
			}
		}
		return false;
	}


	public double alturaMaxima(int a){
		double altura=0.0;
		a-=1;
		if(aves.get(a) instanceof Tinamu){
			Tinamu saveT=(Tinamu)aves.get(a);
			altura+=saveT.calcularAlturaMaxima();
		}else if(aves.get(a) instanceof Neoave){
			Neoave saveN=(Neoave)aves.get(a);
			altura+=saveN.calcularAlturaMaxima();
		}
		return altura;
	}


	public double velocidadPromedio(int a){
		double velocidad=0.0;
		a-=1;
		if(aves.get(a) instanceof Tinamu){
			Tinamu saveT=(Tinamu)aves.get(a);
			velocidad+=saveT.velVuelo();
		}else if(aves.get(a) instanceof Neoave){
			Neoave saveN=(Neoave)aves.get(a);
			velocidad+=saveN.velVuelo();
		}
		return velocidad;
	}


	public double sumaAlturas(){
		double alturas=0.0;
		for(int i=0;i<aves.size();i++){
			Neornithe saveN=(Neornithe)aves.get(i);
			alturas+=saveN.darAltura();
		}
		return alturas;
	}


	public String acordes(int a){
		String response="";
		a-=1;
		if(aves.get(a) instanceof Neoave){
			Passeriforme save=(Passeriforme)aves.get(a);
			response+=save.consultarAcordes();
		}else{
			response+="Este ave no es cantora";
		}
		return response;
	}


	public double pesoPromedio(){
		double pp=0.0;
		for(int i=0;i<aves.size();i++){
			if(aves.get(i) instanceof Galloanserae){
				Galloanserae save=(Galloanserae)aves.get(i);
				pp+=save.calcularPeso();
			}else{
				Neornithe save=(Neornithe)aves.get(i);
				pp+=save.calcularPeso();
			}
		}
		return pp;
	}
	
	public String porcentajesRango(){
		String mensaje="";
		double pR=0.0;
		int contadorA=0;
		int contadorM=0;
		int contadorB=0;
		for(int i=0;i<aves.size();i++){
			Neornithe save=(Neornithe)aves.get(i);
			int x=save.darRangoMetabolico();
			switch(x){
				case 1: contadorA++;
					break;
				case 2: contadorM++;
					break;
				case 3: contadorB++;
					break;
				default: break;
			}
		}
		mensaje+=("El porcentaje de aves con rango  metabolico alto es:"+((contadorA*100)/(double)aves.size())+"\nEl porcentaje de aves con  rango metabolico medio es:"+((contadorM*100)/(double)aves.size())+"\nEl porcentaje de aves con rango metabolico bajo es:"+((contadorB*100)/(double)aves.size()));
		return mensaje;
	}


}