package mundo;

public class Neognato extends Neornithe{
	
	private int huesosPatas;
	private double longDedo;

	public Neognato(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo){
		super (nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso);

		this.huesosPatas=huesosPatas;
		this.longDedo=longDedo;
	}

	public int darHuesosPatas(){
		return huesosPatas;
	}

	public void modificarHuesosPatas(int huesosPatas){
		this.huesosPatas=huesosPatas;
	}

	public double darLongDedo(){
		return longDedo;
	}

	public void modificarLongDedo(double longDedo){
		this.longDedo=longDedo;
	}
	
}