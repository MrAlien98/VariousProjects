package mundo;

public class Tinamu extends Paleognato implements InterfaceVuelo{

	private double velTierra;
	private double altura;

	public Tinamu(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPaladar, double velTierra){
		super(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPaladar);

		this.velTierra=velTierra;
		this.altura=altura;
	}

	public double darVelTierra(){
		return velTierra;
	}

	public void modificarVelTierra(double velTierra){
		this.velTierra=velTierra;
	}
	
	public double darAltura(){
		return altura;
	}
	
	public void modificarAltura(double altura){
		this.altura=altura;
	}
	
	public double calcularAlturaMaxima() {
		double alturaMaxima=(darAltura()*(super.darHuesosPaladar()/100));
		return alturaMaxima;
	}
	
	public double velVuelo() {
		double velocidadV= (super.darLongCola()*(darVelTierra()/100));
		return velocidadV;
	}
	
	public boolean esMigratoria() {
		if(super.darRangoMetabolico()==3 && velVuelo()>100) {
			return true;
		}
		return false;
	}
}