package mundo;
import java.util.*;

public class Neornithe{

	public static final int ALTO=1;
	public static final int MEDIO=2;
	public static final int BAJO=3;

	String nombre;
	String color;
	double altura;
	private double longCola;
	private double densOsea;
	private int rangoMetabolico;
	private double factorPeso;

	public Neornithe(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso){
		this.nombre=nombre;
		this.color=color;
		this.altura=altura;
		this.longCola=longCola;
		this.densOsea=densOsea;
		this.rangoMetabolico=rangoMetabolico;
		this.factorPeso=factorPeso;
	}
	
	public double darLongCola(){
		return longCola;
	}

	public double darDensOsea(){
		return densOsea;
	}

	public int darRangoMetabolico(){
		return rangoMetabolico;
	}

	public String darColor(){
		return color;
	}

	public double darAltura(){
		return altura;
	}

	public double darFactorPeso(){
		return factorPeso;
	}

	public double calcularPeso(){
		double pesoA;
		pesoA = darFactorPeso() * darAltura();
		return pesoA;
	}

	public String darNombre(){
		return nombre;
	}
	
}	