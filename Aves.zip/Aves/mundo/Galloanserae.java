package mundo;

public class Galloanserae extends Neognato{

	public static final int DOMESTICA=1;
	public static final int CAZA=2;
	public static final int MONOGAMA=1;
	public static final int POLIGAMA3=2;

	private int tipo;
	private int repro;

	public Galloanserae(String nombre, String color, double altura, double longCola, double densOsea, int rangoMetabolico, double factorPeso, int huesosPatas, double longDedo, int tipo, int repro){
		super(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo);
		
		this.tipo=tipo;
		this.repro=repro;
	}
	

	public int darTipo(){
		return tipo;
	}

	public void modificarTipo(int tipo){
		this.tipo=tipo;
	}

	public int darRepro(){
		return repro;
	}

	public void modificarRepro(int repro){
		this.repro=repro;
	}


	@Override
	public double calcularPeso(){
		double pesoAve = 0;
		
		if (darTipo() == DOMESTICA){
			pesoAve = (super.calcularPeso() *  0.183) + super.calcularPeso();
		}else if(darTipo() == CAZA){
			pesoAve = (super.calcularPeso() *  0.529) + super.calcularPeso();
		}
		return pesoAve;
	}
}