	package interfaz;

import mundo.Estudio;
import java.util.Scanner;

public class Menu{
	
	private Estudio estu;

	public Menu(){
		estu=new Estudio();

		welcome();
		opciones();
	}

	public void welcome(){
		System.out.println("\n");
		System.out.println("**           **  ******  **       *****    *****        *    *       ******");
		System.out.println(" **   ***   **   **      **      **      **     **     **    **      **    ");
		System.out.println("  ** ** ** **    ******  **      **      **     **    ** ** ** **    ******");
		System.out.println("   **     **     **      **      **      **     **   **   ***   **   **    ");
		System.out.println("    *      *     ******  *******  *****    *****    **           **  ******");
		System.out.println("\n");
	}


	public void opciones(){

		Scanner leer = new Scanner (System.in);
		int op;
		String m = "1. Registrar ave\n2. Consultar si un ave es migratoria.\n3. Consultar la altura maxima de vuelo de un ave.\n4. Consultar velocidad promedio de vuelo de un ave.\n5. Consultar acordes musicales.\nINFORMACION ESTADISTICA DE LAS AVES\n6. Promedio de peso de las aves. \n7. Suma de las alturas de todas las aves.\n8. Porcentaje de aves con rango alto, medio, bajo.\n9. SALIR\nDigite su opcion: ";
		do{
			System.out.print("=============================================================\n"+m);
			op = leer.nextInt();
			switch(op){
				case 1:requerimiento1();
					break;
				case 2:requerimiento2();
					break;
				case 3:requerimiento3();
					break;
				case 4:requerimiento4();
					break;
				case 5:requerimiento5();
					break;
				case 6: requerimiento6();
					break;
				case 7: requerimiento7();
					break;
				case 8: requerimiento8();
					break;
				case 9: requerimiento9();
					break;
				default:System.out.println("Error en la opcion");
			}
		}
		while (op != 9);
	}	

	public void requerimiento1(){
		Scanner leer = new Scanner(System.in);
		System.out.println("*********************");
		System.out.println("*   REGISTRAR AVE   *");
		System.out.println("*********************");
		System.out.println("Ingrese el nombre del ave que desea registrar: ");
		String nombre=leer.nextLine();
		System.out.println("A que especie pertenece el ave que desea registrar? (1)Tinamu (2)Ratite (3)Galloanserae (4)Neoave (5)Passeriforme: ");
		int tipo = leer.nextInt();
		System.out.println("Ingrese el color del ave: ");
		String color=leer.nextLine();
		color=leer.nextLine();
		System.out.println("Ingrese la altura del ave(cm): ");
		double altura=leer.nextDouble();
		System.out.println("Ingrese la longitud de la cola(cm): ");
		double longCola=leer.nextDouble();
		System.out.println("Ingrese la densidad osea del ave: ");
		double densOsea=leer.nextDouble();
		System.out.println("Seleccione el rango metabolico del ave (1)Alto (2)Medio (3)Bajo:");
		int rangoMetabolico=leer.nextInt();
		System.out.println("Ingrese el factor peso del ave: ");
		double factorPeso=leer.nextDouble();
		if(tipo ==1 || tipo==2){
			System.out.println("Ingrese el numero de huesos en el paladar del ave: ");
			int huesosPaladar=leer.nextInt();
			if(tipo==1){
				System.out.println("Ingrese la velocidad en tierra del ave(km/h): ");
				double velTierra=leer.nextDouble();
				estu.agregarAve(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPaladar, velTierra);
			}else{
				System.out.println("Diga si el ave tiene quilla (1)Tiene quilla (2)No iene quilla: ");
				int quilla=leer.nextInt();
				estu.agregarAve(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPaladar, quilla);
			}
		}else if(tipo==3 || tipo==4 || tipo==5){
			System.out.println("Ingrese el numero de huesos que tiene el ave en sus patas: ");
			int huesosPatas=leer.nextInt();
			System.out.println("Ingrese la longitud del tercer dedo del ave(cm): ");
			double longDedo=leer.nextDouble();
			if(tipo==3){
				System.out.println("El ave es (1)Domestica (2)De caza: ");
				int where=leer.nextInt();
				System.out.println("La reproduccion de el ve es (1)Monogama (2)Poliama: ");
				int repro=leer.nextInt();
				estu.agregarAve(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, where, repro);
			}else{
				System.out.println("Ingrese el largo de las patas del ave(cm): ");
				double longPatas=leer.nextDouble();
				System.out.println("Ingrese el numero de dedos en las patas del ave: ");
				int dedosPatas=leer.nextInt();
				if(tipo==4){
					estu.agregarAveN(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, longPatas, dedosPatas);
				}else{
					estu.agregarAveP(nombre, color, altura, longCola, densOsea, rangoMetabolico, factorPeso, huesosPatas, longDedo, longPatas, dedosPatas);
				}
			}
		}
	}


	public void requerimiento2(){
		Scanner leer = new Scanner(System.in);
		System.out.println("********************************");
		System.out.println("*   Consultar Ave Migratoria   *");
		System.out.println("********************************");
		System.out.print("\n"+estu.listarAves());
		
		System.out.println("Seleccione el ave que desea consultar: ");
		int ave=leer.nextInt();
			if(estu.consultarAveMigratoria(ave)==true){
				System.out.println("El ave es migratoria.");
			}else{
				System.out.println("El ave no es migratoria.");
			}
	}


	public void requerimiento3(){
		Scanner leer = new Scanner(System.in);
		System.out.println("*************************************");
		System.out.println("*   Consultar Altura Maxima De Vuelo*");
		System.out.println("*************************************");
		
		System.out.print("\n"+estu.listarAves());

		System.out.println("Seleccione el ave que desea consultar: ");
		int ave=leer.nextInt();
		System.out.println("\nLa altura maxima de vuelo de este ave es: "+estu.alturaMaxima(ave));
	}
	

	public void requerimiento4(){
		Scanner leer = new Scanner(System.in);
		System.out.println("************************************");
		System.out.println("*   Consultar Velocidad Promedio   *");
		System.out.println("************************************");
		System.out.print("\n"+estu.listarAves());

		System.out.println("Seleccione el ave que desea consultar: ");
		int ave=leer.nextInt();
		System.out.println("\nLa velocidad promedio de vuelo de este ave es: "+estu.velocidadPromedio(ave));

	}

		public void requerimiento5(){
		Scanner leer = new Scanner(System.in);
		System.out.println("***********************************");
		System.out.println("*   Consultar Acordes musicales   *");
		System.out.println("***********************************");
		System.out.print("\nNo hay Aves registrados.");
		
		System.out.println("Seleccione el ave que desea consultar: ");
		int ave=leer.nextInt();
		System.out.println("\nEl ave tiene: "+estu.acordes(ave));
		
	}

	public void requerimiento6(){
		System.out.println("************************************");
		System.out.println("*   Promedio De Peso De Las Aves   *");
		System.out.println("************************************");
		
		System.out.println("El promedio de peso de las aves registradas es de: "+estu.pesoPromedio());
		
	}

	public void requerimiento7(){
		System.out.println("*********************************************");
		System.out.println("*   Suma De Las Alturas de Todas Las Aves   *");
		System.out.println("*********************************************");
		System.out.println("La suma de las alturas de las aves registradas es de: "+estu.sumaAlturas());
	}

	public void requerimiento8(){
		System.out.println("*****************************************************************");
		System.out.println("*   Porcentaje De aves Con Rango Metabolico Alto, Medio y Bajo  *");
		System.out.println("*****************************************************************");
		System.out.println(""+estu.porcentajesRango());
	}


	public void requerimiento9(){
		System.out.println("\n");
		System.out.println("******  **      **  ******  *****       ***      **   **");
		System.out.println("**      **      **  **      *    *     ** **      ** **");
		System.out.println("**      **      **  ******  *****     **   **      **");
		System.out.println("**      **      **      **  *    *   *********     **");
		System.out.println("******    *****     ******  *****   **       **    **");
		System.out.println("\n");
	}

	public static void main(String [] args){
		Menu menu=new Menu();
	}
}