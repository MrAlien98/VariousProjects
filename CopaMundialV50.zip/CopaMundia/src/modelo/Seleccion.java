package modelo;

import java.io.Serializable;
import java.util.ArrayList;

import Excepciones.ExceptionJugadorNoEncontrado;

public class Seleccion implements Serializable{
	
	private String nombre;
	private int puntos;
	private double proAltura;
	private double proEdad;
	private double proFifa;
	private String imagen;
	private Jugador primero;
	private Seleccion izq;
	private Seleccion dere;
	
	//atributos para pintar el arbol de selecciones
	private int posX;
	private int posY;
	private int distancia;
	
	public Seleccion(String nom, int pun, String ima) {
		nombre = nom;
		puntos = pun;
		imagen = ima;
		proAltura = 0;
		proEdad = 0;
		proFifa = 0;
		primero = null;
		izq = null;
		dere = null;
		posX = 0;
		posY = 0;
		distancia = 200;
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getPuntos() {
		return puntos;
	}

	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}

	public double getProAltura() {
		return proAltura;
	}

	public void setProAltura(double proAltura) {
		this.proAltura = proAltura;
	}

	public double getProEdad() {
		return proEdad;
	}

	public void setProEdad(double proEdad) {
		this.proEdad = proEdad;
	}

	public double getProFifa() {
		return proFifa;
	}

	public void setProFifa(double proFifa) {
		this.proFifa = proFifa;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public Jugador getPrimero() {
		return primero;
	}

	public void setPrimero(Jugador primero) {
		this.primero = primero;
	}

	public Seleccion getIzq() {
		return izq;
	}

	public void setIzq(Seleccion siguiente) {
		this.izq = siguiente;
	}
	
	public Seleccion getDere() {
		return dere;
	}

	public void setDere(Seleccion siguiente) {
		this.dere = siguiente;
	}
	
	
	
	public void agregarSeleccion(Seleccion nueva){
		if(puntos > nueva.puntos) {
			if(izq == null) {
				izq = nueva;
				izq.setPosX(this.posX - distancia);
				izq.setPosY(this.posY + 100);
				disminuirTamanoI();
			}else {
				izq.distancia += 50;
				izq.posX -= distancia;
				izq.agregarSeleccion(nueva);
			}
		}else {
			if(dere == null) {
				dere = nueva;
				dere.setPosX(this.posX + distancia);
				dere.setPosY(this.posY + 100);
				disminuirTamanoD();
			}else {
				dere.distancia += 50;
				dere.posX += distancia;
				dere.agregarSeleccion(nueva);
			}
		}
	}
	
	
	public void agregarJugador(Jugador nuevo, Jugador actual) {
		if(primero == null) {
			primero = nuevo;	
			primero.setAnterior(primero);
			primero.setSiguiente(primero);
		}
		else {
			if(actual.getSiguiente() == primero) {
				actual.setSiguiente(nuevo);
				nuevo.setAnterior(actual);
				nuevo.setSiguiente(primero);
				primero.setAnterior(nuevo);
			}else {
				agregarJugador(nuevo, actual.getSiguiente());
			}
		}
	}
	
	public void disminuirTamanoI() {
		izq.distancia = distancia-100;
	}

	public void disminuirTamanoD() {
		dere.distancia = distancia-100;
	}
	
	
	public ArrayList<String> nombresJugadores(){
		Jugador actual = primero;
		ArrayList<String> nombre = new ArrayList<String>();
		if(primero !=null) {
			if(actual.getSiguiente() == primero) {
				nombre.add(actual.getNombre());
			}else {
				do {
					nombre.add(actual.getNombre());
					actual = actual.getSiguiente();
					
				}while(actual != primero);
			}
		}
		return nombre;
	}
	
	public Jugador buscarJugador(Jugador actual, String nomb)throws ExceptionJugadorNoEncontrado {
		if(primero != null) {
			if(primero.getNombre().equals(nomb))
				return primero;
			
			if(actual == primero) {
				String message = "El jugador no se encuentra en la lista";
				throw new ExceptionJugadorNoEncontrado(message);
			}else {
				if(actual.getNombre().equals(nomb)) {
					return actual;
				}else {
					return buscarJugador(actual.getSiguiente(), nomb);
				}
			}
		}else {
			String message = "El jugador no se encuentra en la lista";
			throw new ExceptionJugadorNoEncontrado(message);
		}
	}
	
	
	public void eliminarJugador(Jugador actual, String jugador) throws ExceptionJugadorNoEncontrado {
		Jugador eliminar = buscarJugador(actual, jugador);
		if(eliminar == primero) {
			primero = null;
		}else {
			Jugador anterior = eliminar.getAnterior();
			anterior.setSiguiente(eliminar.getSiguiente());
			eliminar.getSiguiente().setAnterior(anterior);
		}
		
	}
	
	
	
//	public void eliminarJugador(String jugador) {
//		Jugador actual = primero;
//		Jugador anterior = primero.getAnterior();
//		if(primero.getNombre().equals(jugador)) {
//			if(primero.getSiguiente() == primero) {
//				primero = null;
//			}else {
//			primero = primero.getSiguiente();
//			primero.setAnterior(anterior);
//			anterior.setSiguiente(primero);
//			
//			}
//		}else {
//			while(actual.getNombre() != jugador) {
//				anterior = actual;
//				actual = actual.getSiguiente();
//			}
//			anterior.setSiguiente(actual.getSiguiente());
//			actual.getSiguiente().setAnterior(anterior);
//		}
//		
//	}
	
	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}
	


	public Seleccion eliminar(int punt) {
		if(esHoja()) {
			return null;
		}
		if(puntos == punt) {
			if(izq == null)
				return dere;
			
			if(dere == null)
				return izq;
			
			Seleccion suce = dere.darMenor();
			dere = dere.eliminar(suce.getPuntos());
			suce.izq = izq;
			suce.dere = dere;
			return suce;
		}
		else if(puntos > punt) {
			izq = izq.eliminar(punt);
		}else {
			dere = dere.eliminar(punt);
		}
		return this;
	}
	
	public Seleccion darMenor() {
		return (izq == null)? this : izq.darMenor();
	}
	
	public boolean esHoja() {
		return dere == null && izq == null;
	}
	
	
	public double sumaAltura(Jugador actual) {
		if(actual == primero) {
			return actual.getAltura();
		}else {
			return actual.getAltura() + sumaAltura(actual.getSiguiente());
		}
	}
	
	public int sumaPuntaje(Jugador actual) {
		if(actual == primero) {
			return actual.getPuntaje();
		}else {
			return actual.getPuntaje() + sumaPuntaje(actual.getSiguiente());
		}
	}
	
	public double sumaEdad(Jugador actual) {
		if(actual == primero) {
			return actual.calcularEdad();
		}else {
			return actual.calcularEdad() + sumaEdad(actual.getSiguiente());
		}
	}
	
	public int cantidad(Jugador actual) {
		if(actual == primero) {
			return 1;
		}else {
			return 1 + cantidad(actual.getSiguiente());
		}
	}
	public void calcularPromedioAltura() {
		double promedio = 0;
		double suma = sumaAltura(primero.getSiguiente());
		int cantidad = cantidad(primero.getSiguiente());
		promedio = suma/cantidad;
		proAltura = promedio;
	}
	
	public void calcularPromedioFIFA() {
		double promedio = 0;
		double suma = sumaPuntaje(primero.getSiguiente());
		int cantidad = cantidad(primero.getSiguiente());
		promedio = suma/cantidad;
		proAltura = promedio;
	}
	
	public void calcularPromedioEdad() {
		double promedio = 0;
		double suma = sumaEdad(primero.getSiguiente());
		int cantidad = cantidad(primero.getSiguiente());
		promedio = suma/cantidad;
		proAltura = promedio;
	}
}