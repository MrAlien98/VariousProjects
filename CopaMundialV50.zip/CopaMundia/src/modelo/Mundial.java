package modelo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import Excepciones.ExceptionJugadorNoEncontrado;
import Excepciones.ExceptionSeleccionNoEncontrada;


public class Mundial {
	
	private Seleccion raiz;
	
	public Mundial() {
		raiz = null;
	}
	
	public void agregarSeleccion(String nom, int pun, String ima) {
		Seleccion selec = new Seleccion(nom, pun, ima);
		if(raiz == null) {
			selec.setPosX(1000);
			selec.setPosY(50);
			raiz = selec;
		}else {
			raiz.agregarSeleccion(selec);
			raiz.setPosX(1000);
			raiz.setPosY(50);
		}
	}
	
	public void agregarJugadore(String pais, String ima, String nom, String pos, int pun, String fe, double alt) {
		Seleccion actual = buscarSeleccion(raiz, pais);
		Jugador juga = new Jugador(ima,nom,pos,pun,fe,alt);
		if(actual != null)
		actual.agregarJugador(juga, actual.getPrimero());
		
	}
	
	public Jugador buscarJuga(String nombPais, String nomb) throws ExceptionJugadorNoEncontrado{
		Seleccion actual = buscarSeleccion(raiz,nombPais);
		Jugador retornar = null;
		retornar = actual.buscarJugador(actual.getPrimero().getSiguiente(), nomb);
		return retornar;
	}
	

	
	public Seleccion buscarSeleccion(Seleccion actual, String selec) {
		Seleccion selec1 = null;
		if(actual != null) {
		    if(actual.getNombre().equals(selec)) {
			   selec1 = actual;
		    }else {
			   selec1 = (buscarSeleccion(actual.getIzq(),selec) != null)? buscarSeleccion(actual.getIzq(), selec): buscarSeleccion(actual.getDere(),selec);
			
		       }
		}
		return selec1;
	}
	
	
	public void eliminarSeleccion(String selecion) {
		Seleccion aEliminar = buscarSeleccion(raiz, selecion);
		raiz = raiz.eliminar(aEliminar.getPuntos());
	}
	
	public void eliminarJugador(String pais, String juga) throws ExceptionJugadorNoEncontrado {
		Seleccion actual = buscarSeleccion(raiz, pais);
		actual.eliminarJugador(actual.getPrimero().getSiguiente(), juga);
	}
	
	public void modificarSeleccion(String nomb, String nuevoNom, int puntos, String ruta) {
			Seleccion buscada = buscarSeleccion(raiz, nomb);
			buscada.setNombre(nuevoNom);
			buscada.setImagen(ruta);
			buscada.setPuntos(puntos);		
	}
	
	
	
	public void nombresSelecciones(Seleccion actual, ArrayList<String> nombres){
		if(actual != null ) {
			nombresSelecciones(actual.getIzq(), nombres);
			nombres.add(actual.getNombre());
			nombresSelecciones(actual.getDere(), nombres);
		}

	}
	
	public void rutasSelecciones(Seleccion actual, ArrayList<Seleccion> nombres){
		if(actual != null ) {
			nombres.add(actual);
			rutasSelecciones(actual.getIzq(), nombres);
			rutasSelecciones(actual.getDere(), nombres);
		}

	}
	
	public ArrayList<Seleccion> selecciones(){
		ArrayList<Seleccion> nombres = new ArrayList<Seleccion>();
		rutasSelecciones(raiz, nombres);
		return nombres;
	}
	
	public ArrayList<String> getNombres() {
		ArrayList<String> nombres = new ArrayList<String>();
		nombresSelecciones(raiz, nombres);
		return nombres;
	}


	public ArrayList<String> nombresJugadore(String pais){
		Seleccion actual = buscarSeleccion(raiz, pais);
		ArrayList<String> datos = new ArrayList<String>();
		if(actual != null)
		datos = actual.nombresJugadores();
		
		return datos;
	}
	
	public void guardarMundo() {
		FileOutputStream file = null;
		ObjectOutputStream ob = null;
		
		try {
			file = new FileOutputStream("./serializado/seleccion.dat");
			ob = new ObjectOutputStream(file);
			
			ob.writeObject(raiz);
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			file.close();
			ob.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	

	
	public void cargarMundo() {
		FileInputStream file = null;
		ObjectInputStream in = null;
		
		try {
			file = new FileInputStream("./serializado/seleccion.dat");
			in = new ObjectInputStream(file);
			
			raiz = (Seleccion) in.readObject();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			file.close();
			in.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		
	}

	public Seleccion getPrimero() {
		return raiz;
	}


	
	

}
