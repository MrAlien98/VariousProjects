package modelo;

import java.io.Serializable;

public class Jugador implements Serializable{
	
	private String imagen;
	private String nombre;
	private String posicion;
	private int puntaje;
	private String fecha;
	private double altura;
	private Jugador siguiente;
	private Jugador anterior;
	
	public Jugador(String ima, String nom, String pos, int pun, String fe, double alt) {
		imagen = ima;
		nombre = nom;
		posicion = pos;
		puntaje = pun;
		fecha = fe;
		altura = alt;
		siguiente = null;
		anterior = null;
	}

	public Jugador getAnterior() {
		return anterior;
	}

	public void setAnterior(Jugador anterior) {
		this.anterior = anterior;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPosicion() {
		return posicion;
	}

	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}

	public int getPuntaje() {
		return puntaje;
	}

	public void setPuntaje(int puntaje) {
		this.puntaje = puntaje;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public Jugador getSiguiente() {
		return siguiente;
	}

	public void setSiguiente(Jugador siguiente) {
		this.siguiente = siguiente;
	}
	
	public double calcularEdad() {
		double edad = 0;
		int anioActual = 2018;
		String[] fechas = fecha.split("/");
		int anio = Integer.parseInt(fechas[2]);
		edad = anioActual - anio;
		return edad;
		
	}
	
	
	

}
