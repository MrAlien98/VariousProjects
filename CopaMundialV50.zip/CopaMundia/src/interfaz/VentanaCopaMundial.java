package interfaz;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import Excepciones.ExceptionJugadorNoEncontrado;
import Excepciones.ExceptionSeleccionNoEncontrada;
import modelo.Jugador;
import modelo.Mundial;
import modelo.Seleccion;

public class VentanaCopaMundial extends JFrame implements ActionListener{
	
	public final static String CARGAR = "C";
	public final static String MOSTRAR = "M";
	public final static String GUARDAR = "G";
	
	private JMenuBar menuBar;
	private JMenu menuArchi;
	private JMenuItem itemCargar, serializar, mostrarArbol;
	private PanelSeleccion pSeleccion;
	private PanelJugador pJugador;
	private PanelInformacion pInformacion;
	private EmergenteSeleccion eSeleccion;
	private EmergenteArbol eArbol;
	private Mundial mundi;
	
	
	public VentanaCopaMundial() {
		menuBar = new JMenuBar();
		menuArchi = new JMenu("Archivo");
		itemCargar = new JMenuItem("Cargar");
		mostrarArbol = new JMenuItem("Mostrar Arbol");
		serializar = new JMenuItem("Serializar");
		pSeleccion = new PanelSeleccion(this);
		pJugador = new PanelJugador(this);
		pInformacion = new PanelInformacion(this);
		eArbol = new EmergenteArbol(this);
		mundi = new Mundial();
		setTitle("Copa Mundial de la FIFA");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		add(pSeleccion, BorderLayout.WEST);
		add(pJugador, BorderLayout.CENTER);
		add(pInformacion, BorderLayout.EAST);
		inicializarMenuBar();
		pack();
	}
	
	public void inicializarMenuBar() {
		menuBar.add(menuArchi);
		menuArchi.add(itemCargar);
		menuArchi.add(mostrarArbol);
		menuArchi.add(serializar);
		itemCargar.addActionListener(this);
		itemCargar.setActionCommand(CARGAR);
		mostrarArbol.addActionListener(this);
		mostrarArbol.setActionCommand(MOSTRAR);
		serializar.addActionListener(this);
		serializar.setActionCommand(GUARDAR);;
		setJMenuBar(menuBar);
	}
	
	public void abrirAgregarSeleccion() {
		eSeleccion = new EmergenteSeleccion(this);
		eSeleccion.setVisible(true);
	}
	
	public void agregarSeleccion() {
		String nombre = eSeleccion.getTxPais();
		int puntaje = Integer.parseInt(eSeleccion.getTxPuntos());
		String ruta = eSeleccion.getRuta();
		mundi.agregarSeleccion(nombre, puntaje, ruta);
		pSeleccion.agregarDatosALista(mundi.getNombres());
		
	}
	
	public void agregarJugador() {
		try {
		String pais = pSeleccion.seleccionado();
		String ima = pInformacion.getImagen();
		String nom = pInformacion.getTxNombre();
		String pos = pInformacion.getTxPosicion();
		int pun = Integer.parseInt(pInformacion.getTxPuntaje());
		String fe = pInformacion.getTxFecha();
		double alt = Double.parseDouble(pInformacion.getTxAltura());
		mundi.agregarJugadore(pais, ima, nom, pos, pun, fe, alt);
		pJugador.agregarDatosALista(mundi.nombresJugadore(pais));
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Seleccione una seleccion");
		}
		
	}
	
	
	public void limpiarCamposDeTexto() {
		pInformacion.setImagen(null);
		pInformacion.setTxNombre(null);
		pInformacion.setTxPosicion(null);
		pInformacion.setTxPuntaje(null);
		pInformacion.setTxFecha(null);
		pInformacion.setTxAltura(null);
		pInformacion.setLaIma(null);
	}
	
	public void mostrarDatosJugador() {
		String jugador = pJugador.darSeleccion();
		String pais = pSeleccion.seleccionado();
		if(jugador != null) {
			try {
			Jugador juga = mundi.buscarJuga(pais, jugador);
			pInformacion.setImagen(juga.getImagen());
			pInformacion.setLaIma(juga.getImagen());
			pInformacion.setTxNombre(juga.getNombre());
			pInformacion.setTxPosicion(juga.getPosicion());
			pInformacion.setTxPuntaje(String.valueOf(juga.getPuntaje()));
			pInformacion.setTxFecha(String.valueOf(juga.getFecha()));
			pInformacion.setTxAltura(String.valueOf(juga.getAltura()));
			}catch(ExceptionJugadorNoEncontrado e) {
				
			}
		}
		
	}
	
	public void mostrarJugadoresDeSelecciones() {
		String pais = pSeleccion.seleccionado();
		pJugador.agregarDatosALista(mundi.nombresJugadore(pais));
	}
	
	public void eliminarSeleccion() {
		
			String pais = pSeleccion.seleccionado();
			mundi.eliminarSeleccion(pais);
			pSeleccion.agregarDatosALista(mundi.getNombres());
			
	}
	
	public void eliminarJugador() {
		try {
			String pais = pSeleccion.seleccionado();
			String juga = pJugador.darSeleccion();
			mundi.eliminarJugador(pais, juga);
			pJugador.agregarDatosALista(mundi.nombresJugadore(pais));
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Seleccione el jugador a eliminar");
		}
		
	}
	
	public void buscarSeleccion() {
		String nomb = JOptionPane.showInputDialog("Escribe la seleccion que deseas buscar");
		Seleccion encontrada;
			encontrada = mundi.buscarSeleccion(mundi.getPrimero(), nomb);
			encontrada.calcularPromedioAltura();
			encontrada.calcularPromedioFIFA();
			encontrada.calcularPromedioEdad();
			eSeleccion = new EmergenteSeleccion(this);
			eSeleccion.setLaIma(encontrada.getImagen());
			eSeleccion.setTxPais(encontrada.getNombre());
			eSeleccion.setTxPuntos(String.valueOf(encontrada.getPuntos()));
			eSeleccion.setTxPromedioAl(String.valueOf(encontrada.getProAltura()));
			eSeleccion.setTxPromedioEd(String.valueOf(encontrada.getProEdad()));
			eSeleccion.setTxPromedioFI(String.valueOf(encontrada.getProFifa()));
			eSeleccion.volverNoEditables();
			eSeleccion.setVisible(true);		
	}
	
	public void buscarJugador() {
		String nomb = JOptionPane.showInputDialog("Escribe el jugador que deseas buscar");
		String pais = pSeleccion.seleccionado();
		try {
			Jugador juga = mundi.buscarJuga(pais, nomb);
			pInformacion.setImagen(juga.getImagen());
			pInformacion.setLaIma(juga.getImagen());
			pInformacion.setTxNombre(juga.getNombre());
			pInformacion.setTxPosicion(juga.getPosicion());
			pInformacion.setTxPuntaje(String.valueOf(juga.getPuntaje()));
			pInformacion.setTxFecha(String.valueOf(juga.getFecha()));
			pInformacion.setTxAltura(String.valueOf(juga.getAltura()));
			}catch(ExceptionJugadorNoEncontrado e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
			}
	}
	
	public void modificarSeleccion() {
		String pais = pSeleccion.seleccionado();
		Seleccion encontrada;
			encontrada = mundi.buscarSeleccion(mundi.getPrimero(),pais);
			encontrada.calcularPromedioAltura();
			encontrada.calcularPromedioFIFA();
			encontrada.calcularPromedioEdad();
			eSeleccion = new EmergenteSeleccion(this);
			eSeleccion.setLaIma(encontrada.getImagen());
			eSeleccion.setRuta(encontrada.getImagen());
			eSeleccion.setTxPais(encontrada.getNombre());
			eSeleccion.setTxPuntos(String.valueOf(encontrada.getPuntos()));
			eSeleccion.setTxPromedioAl(String.valueOf(encontrada.getProAltura()));
			eSeleccion.setTxPromedioEd(String.valueOf(encontrada.getProEdad()));
			eSeleccion.setTxPromedioFI(String.valueOf(encontrada.getProFifa()));
			eSeleccion.volverModifcar();
			eSeleccion.setVisible(true);	
	}
	
	public void modificar() {
		String pais = pSeleccion.seleccionado();
		String nombre = eSeleccion.getTxPais();
		int puntaje = Integer.parseInt(eSeleccion.getTxPuntos());
		String ruta = eSeleccion.getRuta();
		mundi.modificarSeleccion(pais, nombre, puntaje, ruta);;
		pSeleccion.agregarDatosALista(mundi.getNombres());
	}
	
	public void mostrarSiguinte() {
		String pais = pSeleccion.seleccionado();
		String jugador = pInformacion.getTxNombre();
		try {
			Jugador juga = mundi.buscarJuga(pais, jugador);
			Jugador mostrar = juga.getSiguiente();
			pInformacion.setImagen(mostrar.getImagen());
			pInformacion.setLaIma(mostrar.getImagen());
			pInformacion.setTxNombre(mostrar.getNombre());
			pInformacion.setTxPosicion(mostrar.getPosicion());
			pInformacion.setTxPuntaje(String.valueOf(mostrar.getPuntaje()));
			pInformacion.setTxFecha(String.valueOf(mostrar.getFecha()));
			pInformacion.setTxAltura(String.valueOf(mostrar.getAltura()));
			
		} catch (ExceptionJugadorNoEncontrado e) {
			
		}
		
	}
	
	public void mostrarAnterior() {
		String pais = pSeleccion.seleccionado();
		String jugador = pInformacion.getTxNombre();
		try {
			Jugador juga = mundi.buscarJuga(pais, jugador);
			Jugador mostrar = juga.getAnterior();
			pInformacion.setImagen(mostrar.getImagen());
			pInformacion.setLaIma(mostrar.getImagen());
			pInformacion.setTxNombre(mostrar.getNombre());
			pInformacion.setTxPosicion(mostrar.getPosicion());
			pInformacion.setTxPuntaje(String.valueOf(mostrar.getPuntaje()));
			pInformacion.setTxFecha(String.valueOf(mostrar.getFecha()));
			pInformacion.setTxAltura(String.valueOf(mostrar.getAltura()));
			
		} catch (ExceptionJugadorNoEncontrado e) {
			
		}
		
	}
	
	public void mostrarPrimero() {
		String nomb = pSeleccion.seleccionado();
			Seleccion encontrada = mundi.buscarSeleccion(mundi.getPrimero(), nomb);
			Jugador primero = encontrada.getPrimero();
			pInformacion.setImagen(primero.getImagen());
			pInformacion.setLaIma(primero.getImagen());
			pInformacion.setTxNombre(primero.getNombre());
			pInformacion.setTxPosicion(primero.getPosicion());
			pInformacion.setTxPuntaje(String.valueOf(primero.getPuntaje()));
			pInformacion.setTxFecha(String.valueOf(primero.getFecha()));
			pInformacion.setTxAltura(String.valueOf(primero.getAltura()));
	
	}
	
	public ArrayList<Seleccion> darRutasSelecciones(){
		return mundi.selecciones();
	}
	
	public void guardarDatos() {
		mundi.guardarMundo();
	}
	
	public void cargarDatos() {
		mundi.cargarMundo();
		pSeleccion.agregarDatosALista(mundi.getNombres());
	}
	
	
	
	
	public static void main(String[] args) {
		VentanaCopaMundial ven = new VentanaCopaMundial();
		ven.setVisible(true);
//		JOptionPane.showMessageDialog(null,"Carga los datos desde el JMenuBar en la pesta�a *Archivo*");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(CARGAR)) {
			cargarDatos();
		}else if(e.getActionCommand().equals(MOSTRAR)) {
			eArbol.repaint();
			eArbol.setVisible(true);
		}else if(e.getActionCommand().equals(GUARDAR)) {
			guardarDatos();
		}
		
	}

}
