package interfaz;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import modelo.Seleccion;

public class EmergenteArbol extends JDialog{
	
	private JScrollPane scroll;
	private VentanaCopaMundial ven;
	private PanelArbol panel;

	
	public EmergenteArbol(VentanaCopaMundial v) {
		panel = new PanelArbol(v);
		setTitle("Arbol de selecciones");
		setLayout(new BorderLayout());
		setPreferredSize(new Dimension(700, 500));
		scroll = new JScrollPane();
		scroll .setBounds(132, 155, 502, 311);
		scroll .setViewportView(panel);
		getContentPane().add(scroll);
		pack();
		repaint();
	}
	

}
