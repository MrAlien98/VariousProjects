package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class EmergenteSeleccion extends JDialog implements ActionListener{
	
	public final static String CARGAR = "C";
	public final static String GUARDAR = "G";
	public final static String MODIFICAR = "M";
	

	private JLabel laPais, laPuntos, laPromedioAl, laPromedioEd, laPromedioFI, laImagen, laIma, ruta;
	private JTextField txPais, txPuntos, txPromedioAl, txPromedioEd, txPromedioFI;
	private JButton buImagen, buGuardar, buModificar;
	private VentanaCopaMundial ven;
	
	public EmergenteSeleccion(VentanaCopaMundial v) {
		ven = v;
		setTitle("Selecciones Copa Mundial de la FIFA");
		setLayout(new BorderLayout());
		agregarComponentes();
		pack();
	}
	
	public void agregarComponentes() {
		JPanel epa = new JPanel(new GridLayout(8,2,0,6));
		epa.setPreferredSize(new Dimension(300, 250));
		laPais = new JLabel("Pais");
		laPuntos = new JLabel("Puntos");
		laPromedioAl = new JLabel("Promedio Altura");
		laPromedioEd = new JLabel("Promedio Edad");
		laPromedioFI = new JLabel("Promedio FIFA");
		laImagen = new JLabel("Imagen");
		laIma = new JLabel();
		txPais = new JTextField();
		txPais.setPreferredSize(new Dimension(155, 22));
		txPuntos = new JTextField();
		txPuntos.setPreferredSize(new Dimension(155, 22));
		txPromedioAl = new JTextField();
		txPromedioAl.setPreferredSize(new Dimension(155, 22));
		txPromedioAl.setEditable(false);
		txPromedioEd = new JTextField();
		txPromedioEd.setPreferredSize(new Dimension(155, 22));
		txPromedioEd.setEditable(false);
		txPromedioFI = new JTextField();
		txPromedioFI.setPreferredSize(new Dimension(155, 22));
		txPromedioFI.setEditable(false);
		buImagen = new JButton("Cargar");
		buImagen.setActionCommand(CARGAR);
		buImagen.addActionListener(this);
		buGuardar = new JButton("Guardar");
		buGuardar.setActionCommand(GUARDAR);
		buGuardar.addActionListener(this);
		buModificar = new JButton("Modificar");
		buModificar.setVisible(false);
		buModificar.setActionCommand(MODIFICAR);
		buModificar.addActionListener(this);
		epa.add(laPais);
		epa.add(txPais);
		epa.add(laPuntos);
		epa.add(txPuntos);
		epa.add(laPromedioAl);
		epa.add(txPromedioAl);
		epa.add(laPromedioEd);
		epa.add(txPromedioEd);
		epa.add(laPromedioFI);
		epa.add(txPromedioFI);
		epa.add(laImagen);
		epa.add(buImagen);
		epa.add(new JLabel());
		epa.add(buGuardar);
		epa.add(new JLabel());
		epa.add(buModificar);
		add(epa, BorderLayout.CENTER);
		JPanel epa2 = new JPanel(new GridLayout(0,1));
		epa2.setPreferredSize(new Dimension(300, 250));
		TitledBorder bor = BorderFactory.createTitledBorder("Seleccion del pais");
		epa2.setBorder(bor);
		epa2.add(laIma);
		add(epa2, BorderLayout.WEST);
	}
	
	
	 public void cargar()
	    {
	        JFileChooser fc = new JFileChooser( new File("./ima") );
	        fc.setDialogTitle( "Cargar Imagen" );

	        // Mostrar el dialogo para abrir
	        int resultado = fc.showOpenDialog( null );
	        if( resultado == JFileChooser.APPROVE_OPTION )
	        {
	            File archivo = fc.getSelectedFile();
	            ruta = new JLabel(archivo.getPath());
	            ImageIcon image = new ImageIcon(archivo.getPath());
	            laIma.setIcon(image);
	           
	           }
	    }
	 
	public void volverNoEditables() {
		txPais.setEditable(false);
		txPuntos.setEditable(false);
		txPromedioAl.setEditable(false); 
		txPromedioEd.setEditable(false); 
		txPromedioFI.setEditable(false);
		buImagen.setEnabled(false);
		buGuardar.setVisible(false);
	}
	
	public void volverModifcar() {
		buGuardar.setVisible(false);
		buModificar.setVisible(true);
	}
	 
	public String getRuta() {
		return ruta.getText();
	}

	public String getTxPais() {
		return txPais.getText();
	}

	public String getTxPuntos() {
		return txPuntos.getText();
	}
	
	public void setLaIma(String laIma) {
		ImageIcon ima = new ImageIcon(laIma);
		this.laIma.setIcon(ima);
	}

	public void setRuta(String ruta) {
		this.ruta = new JLabel(ruta);
	}

	public void setTxPais(String txPais) {
		this.txPais.setText(txPais);
	}

	public void setTxPuntos(String txPuntos) {
		this.txPuntos.setText(txPuntos);;
	}

	public void setTxPromedioAl(String txPromedioAl) {
		this.txPromedioAl.setText(txPromedioAl);;
	}

	public void setTxPromedioEd(String txPromedioEd) {
		this.txPromedioEd.setText(txPromedioEd);;
	}

	public void setTxPromedioFI(String txPromedioFI) {
		this.txPromedioFI.setText(txPromedioFI);;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(CARGAR)) {
			cargar();
		}else if(e.getActionCommand().equals(GUARDAR)){
			ven.agregarSeleccion();
			this.dispose();
		}else if(e.getActionCommand().equals(MODIFICAR)) {
			ven.modificar();
			this.dispose();
		}
	}
	
}
