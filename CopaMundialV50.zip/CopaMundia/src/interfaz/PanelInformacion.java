package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PanelInformacion extends JPanel implements ActionListener{
	
	public final static String ANTERIOR = "A";
	public final static String PRIMERO = "P";
	public final static String SIGUIENTE = "S";
	public final static String CARGAR = "C";
	
	private JLabel imagen, laNombre, laPosicion, laPuntaje, laFecha, laAltura, laIma;
	private JTextField txNombre, txPosicion, txPuntaje, txFecha, txAltura;
	private JButton bAnterior, bPrimero, bSiguiente, buCargar;
	private VentanaCopaMundial ven;
	
	
	public PanelInformacion(VentanaCopaMundial v) {
		ven = v;
		setLayout(new FlowLayout());	
		setPreferredSize(new Dimension(300, 400));
		agregarDatos();
		agregarBotones();
	}
	
	public void agregarDatos() {
		JPanel foto = new JPanel(new FlowLayout());
		laIma = new JLabel();
		laIma.setPreferredSize(new Dimension(150, 120));
		foto.add(laIma);
		foto.setPreferredSize(new Dimension(200,150));
		JPanel verti = new JPanel(new GridLayout(6,2,6,6));
		JPanel mayor = new JPanel(new BorderLayout());
		TitledBorder bor = BorderFactory.createTitledBorder("Jugador");
		mayor.setBorder(bor);
		imagen = new JLabel();
		laNombre = new JLabel("Nombre");
		laPosicion = new JLabel("Posicion");
		laPuntaje = new JLabel("Puntaje FIFA");
		laFecha = new JLabel("Fecha de Nac");
		laAltura = new JLabel("Altura");
		txNombre = new JTextField();
		txNombre.setPreferredSize(new Dimension(130, 23));
		txPosicion = new JTextField(); 
		txPosicion.setPreferredSize(new Dimension(130, 23));
		txPuntaje = new JTextField();
		txPuntaje.setPreferredSize(new Dimension(130, 23));
		txFecha = new JTextField();
		txFecha.setPreferredSize(new Dimension(130, 23));
		txAltura = new JTextField();
		txAltura.setPreferredSize(new Dimension(130, 23));
		buCargar = new JButton("Cargar imagen");
		buCargar.setActionCommand(CARGAR);
		buCargar.addActionListener(this);
		verti.add(laNombre);
		verti.add(txNombre);
		verti.add(laPosicion);
		verti.add(txPosicion);
		verti.add(laPuntaje);
		verti.add(txPuntaje);
		verti.add(laFecha);
		verti.add(txFecha);
		verti.add(laAltura);
		verti.add(txAltura);
		verti.add(new JLabel());
		verti.add(buCargar);
		mayor.add(foto, BorderLayout.NORTH);
		mayor.add(verti, BorderLayout.CENTER);
		add(mayor);
		
	}
	
	public void agregarBotones() {
		bAnterior = new JButton("Anterior");
		bAnterior.setActionCommand(ANTERIOR);
		bAnterior.addActionListener(this);
		bAnterior.setPreferredSize(new Dimension(80,30));
		bPrimero = new JButton("Primero");
		bPrimero.setActionCommand(PRIMERO);
		bPrimero.addActionListener(this);
		bPrimero.setPreferredSize(new Dimension(80,30));
		bSiguiente = new JButton("Siguiente");
		bSiguiente.setActionCommand(SIGUIENTE);
		bSiguiente.addActionListener(this);
		bSiguiente.setPreferredSize(new Dimension(90,30));
		add(bAnterior);
		add(bPrimero);
		add(bSiguiente);
		
		
	}
	
	
	
	
	
	 public JLabel getLaIma() {
		return laIma;
	}

	public void setLaIma(String ruta) {
		 ImageIcon image = new ImageIcon(ruta);
         Icon icono = new ImageIcon(image.getImage().getScaledInstance(laIma.getWidth(), laIma.getHeight(), Image.SCALE_DEFAULT));
         laIma.setIcon(icono);
	}

	public String getImagen() {
		return imagen.getText();
	}

	public void setImagen(String imagen) {
		this.imagen.setText(imagen);;
	}

	public String getTxNombre() {
		return txNombre.getText();
	}

	public void setTxNombre(String txNombre) {
		this.txNombre.setText(txNombre);
	}

	public String getTxPosicion() {
		return txPosicion.getText();
	}

	public void setTxPosicion(String txPosicion) {
		this.txPosicion.setText(txPosicion);
	}

	public String getTxPuntaje() {
		return txPuntaje.getText();
	}

	public void setTxPuntaje(String txPuntaje) {
		this.txPuntaje.setText(txPuntaje);;
	}

	public String getTxFecha() {
		return txFecha.getText();
	}

	public void setTxFecha(String txFecha) {
		this.txFecha.setText(txFecha);
	}

	public String getTxAltura() {
		return txAltura.getText();
	}

	public void setTxAltura(String txAltura) {
		this.txAltura.setText(txAltura);;
	}

	public void cargar()
	    {
	        JFileChooser fc = new JFileChooser( new File("./ima") );
	        fc.setDialogTitle( "Cargar Imagen" );

	        // Mostrar el dialogo para abrir
	        int resultado = fc.showOpenDialog( null );
	        if( resultado == JFileChooser.APPROVE_OPTION )
	        {
	            File archivo = fc.getSelectedFile();
	            imagen = new JLabel(archivo.getPath());
	            ImageIcon image = new ImageIcon(archivo.getPath());
	            Icon icono = new ImageIcon(image.getImage().getScaledInstance(laIma.getWidth(), laIma.getHeight(), Image.SCALE_DEFAULT));
	            laIma.setIcon(icono);
	           
	           
	           }
	    }


	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
	if(e.getActionCommand().equals(CARGAR)) {
		cargar();
	}else if(e.getActionCommand().equals(SIGUIENTE)) {
		ven.mostrarSiguinte();
	}else if(e.getActionCommand().equals(ANTERIOR)) {
		ven.mostrarAnterior();
	}else if(e.getActionCommand().equals(PRIMERO)) {
		ven.mostrarPrimero();
	}
		
	}

	
	
}
