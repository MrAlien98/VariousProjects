package interfaz;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import modelo.Seleccion;

public class PanelArbol extends JPanel{
	
	
	private VentanaCopaMundial ven;
	
	public PanelArbol(VentanaCopaMundial v) {
		ven = v;
		setPreferredSize(new Dimension(2000,2000));
	}
	
	public void paintComponent(Graphics g) {
		ArrayList<Seleccion> rutas = ven.darRutasSelecciones();
		for (Seleccion epa : rutas) {
			ImageIcon imag = new ImageIcon(epa.getImagen());
			Image ima = imag.getImage();
			g.drawImage(ima, epa.getPosX(), epa.getPosY(),60,40,this);
			pintarLineas(g);
			repaint();
		}
	}
	
	public void pintarLineas(Seleccion actual, Graphics g) {
		ArrayList<Seleccion> rutas = ven.darRutasSelecciones();
		for (int i = 0; i < rutas.size()-1; i++) {
			g.drawLine(rutas.get(i).getPosX()+30,rutas.get(i).getPosY()+40, rutas.get(i+1).getPosX(), rutas.get(i+1).getPosY());
		}
		
	}
	
	

}
