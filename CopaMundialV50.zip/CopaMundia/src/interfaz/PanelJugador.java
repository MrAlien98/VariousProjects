package interfaz;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class PanelJugador extends JPanel implements ActionListener, ListSelectionListener{
	
	public final static String AGREGAR = "A";
	public final static String ELIMINAR = "E";
	public final static String BUSCAR = "B";
	public final static String GUARDAR = "M";
	

	private JList<String> lisJuga;
	private JButton bAgregar, bEliminar, bBuscar, bModificar;
	private VentanaCopaMundial v;
	
	
	
	public PanelJugador(VentanaCopaMundial ven) {
		v = ven;
		setLayout(new BorderLayout());
		TitledBorder bor = BorderFactory.createTitledBorder("Jugadores");
		setBorder(bor);
		setPreferredSize(new Dimension(250, 400));
		agregarLista();
		agregarBotones();
		
		
	}
	
	public void agregarLista() {
		lisJuga = new JList<String>();
		lisJuga.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lisJuga.setLayoutOrientation(JList.VERTICAL);
		lisJuga.addListSelectionListener(this);
		JScrollPane barra = new JScrollPane(lisJuga);
		add(barra, BorderLayout.CENTER);
		
	}
	
	public void agregarDatosALista(ArrayList<String> datos) {
		DefaultListModel<String> listModel = new DefaultListModel<String>();
		for (String dat : datos) {
			listModel.addElement(dat);
		}
		lisJuga.setModel(listModel);
	}
	
	public void agregarBotones() {
		JPanel pan = new JPanel(new FlowLayout());
		pan.setPreferredSize(new Dimension(210, 70));
		bAgregar = new JButton("Agregar");
		bAgregar.setActionCommand(AGREGAR);
		bAgregar.addActionListener(this);
		bEliminar = new JButton("Eliminar");
		bEliminar.setActionCommand(ELIMINAR);
		bEliminar.addActionListener(this);
		bBuscar = new JButton("Buscar");
		bBuscar.setActionCommand(BUSCAR);
		bBuscar.addActionListener(this);
		bModificar = new JButton("Guardar");
		bModificar.setActionCommand(GUARDAR);
		bModificar.addActionListener(this);
		pan.add(bAgregar);
		pan.add(bEliminar);
		pan.add(bBuscar);
		pan.add(bModificar);
		add(pan, BorderLayout.SOUTH);
		
	}
	
	public String darSeleccion() {
		return lisJuga.getSelectedValue();
	}
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals(GUARDAR)) {
			v.agregarJugador();
		}else if(e.getActionCommand().equals(AGREGAR)) {
			v.limpiarCamposDeTexto();
		}else if(e.getActionCommand().equals(ELIMINAR)) {
			v.eliminarJugador();
		}else if(e.getActionCommand().equals(BUSCAR)) {
			v.buscarJugador();
		}
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {
		v.mostrarDatosJugador();
	}
	

}
