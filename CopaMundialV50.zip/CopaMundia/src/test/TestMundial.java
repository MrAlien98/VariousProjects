package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Excepciones.ExceptionJugadorNoEncontrado;
import Excepciones.ExceptionSeleccionNoEncontrada;
import modelo.Mundial;

class TestMundial {
	
	private Mundial rusia;
	
	private void escenario() {
		rusia = new Mundial();
	}

	@Test
	public void testAgregarSeleccion() {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		assertTrue(rusia.getPrimero().getNombre().equals("Colombia"));
	}
	
	@Test
	public void testEliminarSeleccion() {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		rusia.eliminarSeleccion(nomb);
		assertNull(rusia.getPrimero());
	}
	
	@Test
	public void testBuscarSeleccion() throws ExceptionSeleccionNoEncontrada {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		assertEquals(rusia.getPrimero(), rusia.buscarSeleccion(rusia.getPrimero(), nomb));
	}
	
	@Test
	public void testModificarSeleccion() {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		String nuevoNombre = "Argentina";
		rusia.modificarSeleccion(nomb, nuevoNombre, puntos, ruta);
		assertTrue(rusia.getPrimero().getNombre().equals(nuevoNombre));
	}
	
	@Test
	public void testAgregarJugador() {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		String ima = "james.jpg";
		String nom = "James Rodriguez";
		String pos = "Volante";
		int pun = 10;
		String fe = "11/10/1998";
		double alt = 1.86;
		rusia.agregarJugadore(nomb, ima, nom, pos, pun, fe, alt);
		assertEquals(nom, rusia.getPrimero().getPrimero().getNombre());
	}
	
	@Test
	public void testEliminarJugador() throws ExceptionJugadorNoEncontrado {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		String ima = "james.jpg";
		String nom = "James Rodriguez";
		String pos = "Volante";
		int pun = 10;
		String fe = "11/10/1998";
		double alt = 1.86;
		rusia.agregarJugadore(nomb, ima, nom, pos, pun, fe, alt);
		rusia.eliminarJugador(nomb, nom);
		assertNull(rusia.getPrimero().getPrimero());
	}
	
	@Test
	public void testBuscarJugador() throws ExceptionJugadorNoEncontrado {
		escenario();
		String nomb = "Colombia";
		int puntos = 50;
		String ruta = "colombia.jpg";
		rusia.agregarSeleccion(nomb, puntos, ruta);
		String ima = "james.jpg";
		String nom = "James Rodriguez";
		String pos = "Volante";
		int pun = 10;
		String fe = "11/10/1998";
		double alt = 1.86;
		rusia.agregarJugadore(nomb, ima, nom, pos, pun, fe, alt);
		assertEquals(rusia.getPrimero().getPrimero(), rusia.buscarJuga(nomb, nom));
	}

}
