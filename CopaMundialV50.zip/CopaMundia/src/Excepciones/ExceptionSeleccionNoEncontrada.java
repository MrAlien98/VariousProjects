package Excepciones;

public class ExceptionSeleccionNoEncontrada extends Exception {

	public ExceptionSeleccionNoEncontrada(String message) {
		super(message);
	}
	
}
