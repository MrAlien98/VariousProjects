package Excepciones;

public class ExceptionJugadorNoEncontrado extends Exception {

	public ExceptionJugadorNoEncontrado(String message) {
		super(message);
	}
	
}
