package hilos;

import interfaz.InterfazJuegoBalones;
import mundo.Balon;

public class HiloBalon extends Thread implements Runnable {
	
	private Balon balon;
	private InterfazJuegoBalones principal;
	
	
	public HiloBalon(Balon b, InterfazJuegoBalones ib) {
		
		balon = b;
		principal = ib;
		
	}
	
	
	
	@Override
	public void run() {
		
		while (!balon.haSidoAtrapado()) {
			balon.mover(principal.darAnchoActual(), principal.darAltoActual());
			principal.refrescarCancha();
			principal.darTotalRebotes();
			
			try {
				Thread.sleep(balon.darEspera());
			} catch (InterruptedException e) {
			
			}
		}
		
	}

	
	
}
