package interfaz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.annotation.Repeatable;
import java.util.ArrayList;

import javax.swing.JPanel;

import mundo.Balon;

@SuppressWarnings("serial")
public class PanelCancha extends JPanel implements MouseListener {
	private ArrayList<Balon> balones;
	private InterfazJuegoBalones principal;

	public PanelCancha(InterfazJuegoBalones ventana) {
		principal = ventana;
		balones = new ArrayList<>();
		addMouseListener(this);
	}

	public void cambiarBalones(ArrayList<Balon> bs) {
		balones = bs;
	}

	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.WHITE);
		g2.fillRect(0, 0, 500, 500);
		
		
		// Pintar Cantidad rebotes
		g2.setColor(Color.BLACK);
		g2.drawString("Rebotes : "+principal.darTotalRebotes(), 5, 12);

		// Pintar Balones
		for (int i = 0; i < balones.size(); i++) {
			g2.setColor(balones.get(i).darColor());
			g2.fillOval(balones.get(i).darPosX(), balones.get(i).darPosY(), balones.get(i).darDiametro() / 2,
					balones.get(i).darDiametro() / 2);
		
		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		principal.atrapar(e.getX(), e.getY());	
		principal.refrescarCancha();
		

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
