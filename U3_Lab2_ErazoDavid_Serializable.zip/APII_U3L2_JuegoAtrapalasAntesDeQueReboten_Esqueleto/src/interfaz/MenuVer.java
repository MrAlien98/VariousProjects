package interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class MenuVer extends JMenu implements ActionListener {

	
	public final static String PUNTAJES = "Puntajes";
	public final static String ACERCADE = "Acerca de";
	
	private JMenuItem meitPuntajes;
	private JMenuItem meitAcercaDe;
	
	private InterfazJuegoBalones principal;
	
	public MenuVer(InterfazJuegoBalones ventana) {
		super("Ver");
		principal = ventana;
		
		meitPuntajes = new JMenuItem("Mejores Puntajes");
		meitAcercaDe = new JMenuItem("Acerca del Juego");
		
		meitPuntajes.addActionListener(this);
		meitAcercaDe.addActionListener(this);
		
		meitPuntajes.setActionCommand(PUNTAJES);
		meitAcercaDe.setActionCommand(ACERCADE);
		
		add(meitPuntajes);
		add(meitAcercaDe);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String comando = e.getActionCommand();
		if(comando.equals(PUNTAJES)){
			
			principal.mostrarPuntajes();
			
		}else {
			principal.mostrarAcercaDelJuego();
		}
		
		
		
	}
	
	
}
