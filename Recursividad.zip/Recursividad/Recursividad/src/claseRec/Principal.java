package claseRec;

public class Principal {

	public Principal() {
		// TODO Auto-generated constructor stub
	}

}
