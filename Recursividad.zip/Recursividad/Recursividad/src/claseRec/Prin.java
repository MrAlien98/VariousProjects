package claseRec;

import javax.print.attribute.standard.PDLOverrideSupported;

public class Prin {

	public Prin() {
		// TODO Auto-generated constructor stub
	}

	public void cuentaReg(int n) {
		for (int i = n; i > 0; i--) {
			System.out.println(i);
		}
	}

	public void cuentaRegRec(int num) {

		if (num == 0) {
			System.out.println(num);
		} else {
			System.out.println(num);
			cuentaRegRec(num - 1);
		}
	}
	
	public int sum(int n) {
		
		if (n == 0) {
			return 0;
		}else {
			return n + sum(n-1);
		}
		
	}
	
	public boolean isPalindromo(String cadena) {
		
		if(cadena.length() == 1) {
			return true;
		}else {
			if(cadena.charAt(0) == cadena.charAt(cadena.length()-1)) {
				return isPalindromo(cadena.substring(1, cadena.length()-1));
			}else {
				return false;
			}
		}
		
	}
	
	public String invertir(String cad) {
		
		if(cad.length() == 1) {
			return cad;
		}else {
			return invertir(cad.substring(1)) + cad.charAt(0);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Prin pu = new Prin();
		//pu.cuentaRegRec(5);
		
		//Llamado recursiv sum
		System.out.println(pu.sum(5));
		
		System.out.println(pu.isPalindromo("somos"));
		String cad = "cadena";
		System.out.println(cad.substring(1));
		
		System.out.println(pu.invertir("somos uno"));
	}

}
