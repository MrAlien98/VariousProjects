package application;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.time.LocalDate;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javazoom.jl.player.Player;

public class SampleController {
	
	class Hilo extends Thread{
		File ruta;		
		public Hilo(File ruta) {this.ruta=ruta;}
		
		@Override
		public void run() {
			try {		
				BufferedInputStream bis=new BufferedInputStream(new FileInputStream(ruta));
				Player player=new Player(bis);
				player.play();
			}catch(Exception e) {
			
			}
		}
		
		public void setRuta(File ruta) {
			this.ruta=ruta;
		}
	}
	
	@FXML private DatePicker fecha;
	
	@FXML private Button dia;
	@FXML private Button mes;
	@FXML private Button anio;
	
	@FXML private Button guardar;
	
	@FXML private Button play;
	
	@FXML private TextField test;
	
	private LocalDate local;
	
	private int d, m, a;
	
	Hilo h=new Hilo(null);
	
	public SampleController() {
		
	}
	
	public void initialize() {
		play.setOnAction(e->{
			FileChooser fc=new FileChooser();
			fc.setInitialDirectory(new File("src/songs"));
			File f=fc.showOpenDialog(Main.getStage());
			reproducir(f);
		});
		guardar.setOnAction(e->{
//			local=new LocalDate(a, a, a);
			local=fecha.getValue();
			d=local.getDayOfMonth();
			m=local.getMonthValue();
			a=local.getYear();
		});
		dia.setOnAction(e->{
			System.out.println(d);
		});
		mes.setOnAction(e->{
			System.out.println(m);
		});
		anio.setOnAction(e->{
			System.out.println(a);
		});
	}
	
	@SuppressWarnings("deprecation")
	public void reproducir(File ruta) {
		h.stop();
		h.setRuta(ruta);
		h.run();
	}
	
}
